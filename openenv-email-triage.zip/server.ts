import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { createServer } from "http";
import { Server } from "socket.io";
import { EmailTriageEnvironment } from "./src/backend/environment";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });
  const PORT = 3000;

  app.use(express.json());

  // Health check
  app.get(["/health", "/api/health"], (req, res) => {
    res.json({ status: "ok" });
  });

  // Initialize Email Triage Environment
  const env = new EmailTriageEnvironment();

  // API Routes (OpenEnv Pattern)
  app.get(["/api/reset", "/reset"], (req, res) => {
    const taskId = (req.query.task_id as string) || "easy_cleanup";
    const observation = env.reset(taskId);
    res.json(observation);
  });

  app.post(["/api/step", "/step"], (req, res) => {
    const action = req.body;
    if (!action || !action.type || !action.email_id) {
      return res.status(400).json({ error: "Invalid action" });
    }
    const observation = env.step(action);
    res.json(observation);
  });

  app.get(["/api/state", "/state"], (req, res) => {
    const state = env.get_state();
    res.json(state);
  });

  app.get(["/api/grade", "/grade"], (req, res) => {
    const score = env.get_grader_score();
    res.json({ score });
  });

  app.post("/api/generate_email", (req, res) => {
    const emailData = req.body;
    const newEmail = env.generate_email(emailData);
    res.json(newEmail);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
