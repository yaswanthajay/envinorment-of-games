import React, { useState, useEffect, Suspense } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Gamepad2, 
  Cpu, 
  Zap, 
  Settings, 
  Info, 
  ChevronRight, 
  Activity, 
  Shield, 
  Terminal, 
  Brain, 
  Grid3X3, 
  User, 
  Menu, 
  X,
  HelpCircle,
  Target,
  Diamond,
  Route,
  Box,
  ShieldAlert,
  Hash,
  Mail
} from 'lucide-react';
import EmailTriage from './components/EmailTriage';
import NeonTicTacToe from './components/NeonTicTacToe';
import MindReader from './components/MindReader';
import NumberQuest from './components/NumberQuest';
import RiddleSphinx from './components/RiddleSphinx';
import PatternMimic from './components/PatternMimic';
import CardRealm from './components/CardRealm';
import WordGuessGame from './components/WordGuessGame';
import { ChessGame } from './components/ChessGame';
import TrafficSimulator from './components/TrafficSimulator';
import DisasterResponse from './components/DisasterResponse';
import CyberStrikeContainer from './components/CyberStrikeContainer';
import GameHub3D from './components/GameHub3D';
import GameListMobile from './components/GameListMobile';
import SplashScreen from './components/SplashScreen';
import NexusAuth from './components/NexusAuth';
import GameInstructions from './components/GameInstructions';
import AIAssistant from './components/AIAssistant';
import { SettingsModal, CreatorModal } from './components/NexusModals';
import { getHubGreeting } from './services/aiService';

const Vortex = () => (
  <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden opacity-60">
    <motion.div
      animate={{ rotate: 360 }}
      transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
      className="relative w-[600px] h-[600px]"
    >
      {/* Globe Grid */}
      {[...Array(18)].map((_, i) => (
        <div
          key={i}
          style={{ 
            transform: `rotate(${i * 10}deg)`,
            borderColor: i % 2 === 0 ? 'rgba(6, 182, 212, 0.2)' : 'rgba(217, 70, 239, 0.2)'
          }}
          className="absolute inset-0 border rounded-full"
        />
      ))}

      {/* Rotating Rings */}
      {[...Array(3)].map((_, i) => (
        <motion.div
          key={`ring-${i}`}
          animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
          transition={{ duration: 10 + i * 5, repeat: Infinity, ease: "linear" }}
          style={{ 
            width: `${80 + i * 10}%`,
            height: `${80 + i * 10}%`,
            left: `${10 - i * 5}%`,
            top: `${10 - i * 5}%`,
            border: '1px dashed rgba(6, 182, 212, 0.1)',
          }}
          className="absolute rounded-full"
        />
      ))}
      
      {/* Neural Nodes */}
      {[...Array(24)].map((_, i) => (
        <motion.div
          key={`node-${i}`}
          animate={{ 
            scale: [1, 1.5, 1],
            opacity: [0.2, 0.8, 0.2],
          }}
          transition={{ 
            duration: 2 + Math.random() * 3, 
            repeat: Infinity, 
            delay: Math.random() * 2 
          }}
          style={{ 
            top: `${Math.random() * 100}%`,
            left: `${Math.random() * 100}%`,
          }}
          className="absolute w-1 h-1 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(6,182,212,1)]"
        />
      ))}

      {/* Core Glow */}
      <div className="absolute inset-[20%] bg-cyan-500/20 blur-[100px] rounded-full animate-pulse" />
      <div className="absolute inset-[40%] bg-fuchsia-500/20 blur-[60px] rounded-full animate-pulse delay-700" />
    </motion.div>
  </div>
);

const FloatingData = () => {
  const [elements, setElements] = useState<{ id: number, x: number, y: number, text: string, speed: number }[]>([]);

  useEffect(() => {
    const newElements = [...Array(15)].map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      text: Math.random().toString(16).slice(2, 8).toUpperCase(),
      speed: 10 + Math.random() * 20
    }));
    setElements(newElements);
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
      {elements.map((el) => (
        <motion.div
          key={el.id}
          initial={{ y: "100%" }}
          animate={{ y: "-100%" }}
          transition={{ duration: el.speed, repeat: Infinity, ease: "linear" }}
          style={{ left: `${el.x}%` }}
          className="absolute text-[10px] font-mono text-cyan-400/40"
        >
          {el.text}
        </motion.div>
      ))}
    </div>
  );
};

const SystemLog = () => {
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      const newLog = `[${new Date().toLocaleTimeString()}] NODE_0X${Math.random().toString(16).slice(2, 6).toUpperCase()} ${
        ['SYNCED', 'ENCRYPTED', 'BYPASSED', 'INITIALIZED', 'OPTIMIZED'][Math.floor(Math.random() * 5)]
      }`;
      setLogs(prev => [newLog, ...prev].slice(0, 8));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4 bg-black/40 border border-white/5 rounded-xl font-mono text-[9px] text-cyan-400/60 space-y-1 overflow-hidden h-32">
      <div className="flex items-center gap-2 mb-2 border-b border-white/10 pb-1">
        <Terminal className="w-3 h-3" />
        <span className="uppercase tracking-widest">Live_System_Logs</span>
      </div>
      {logs.map((log, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="truncate"
        >
          {log}
        </motion.div>
      ))}
    </div>
  );
};

const HUDGauge = ({ label, value, color }: { label: string, value: number, color: string }) => (
  <div className="flex flex-col items-center gap-2">
    <div className="relative w-20 h-20">
      <svg className="w-full h-full -rotate-90">
        <circle
          cx="40"
          cy="40"
          r="36"
          fill="none"
          stroke="rgba(255,255,255,0.05)"
          strokeWidth="4"
        />
        <motion.circle
          cx="40"
          cy="40"
          r="36"
          fill="none"
          stroke={color}
          strokeWidth="4"
          strokeDasharray="226"
          initial={{ strokeDashoffset: 226 }}
          animate={{ strokeDashoffset: 226 - (226 * value) / 100 }}
          transition={{ duration: 2, ease: "easeOut" }}
          strokeLinecap="round"
          className="drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xs font-mono font-bold text-white/80">{value}%</span>
      </div>
    </div>
    <span className="text-[8px] font-mono uppercase tracking-[0.2em] text-white/40">{label}</span>
  </div>
);

const TechnicalCard = ({ game, onClick, index }: { game: Game, onClick: () => void, index: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: index * 0.05 }}
    whileHover={{ scale: 1.02, y: -5 }}
    onClick={onClick}
    className="group relative cursor-pointer overflow-hidden"
  >
    {/* Scanline effect */}
    <div className="absolute inset-0 scanline pointer-events-none opacity-5" />
    
    {/* Glow background */}
    <div className={`absolute inset-0 bg-gradient-to-br ${game.color} opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity blur-xl`} />
    
    <div className="relative p-6 bg-black/40 backdrop-blur-md border border-white/5 rounded-2xl group-hover:border-cyan-500/30 transition-all h-full flex flex-col tilt-card">
      {/* Corner accents */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t border-l border-white/20 group-hover:border-cyan-500/50 transition-colors" />
      <div className="absolute top-0 right-0 w-4 h-4 border-t border-r border-white/20 group-hover:border-cyan-500/50 transition-colors" />
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b border-l border-white/20 group-hover:border-cyan-500/50 transition-colors" />
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b border-r border-white/20 group-hover:border-cyan-500/50 transition-colors" />

      <div className="flex justify-between items-start mb-4 preserve-3d">
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${game.color} flex items-center justify-center shadow-lg group-hover:shadow-cyan-500/20 transition-all transform group-hover:translateZ(30px)`}>
          {game.icon}
        </div>
        <div className="text-right">
          <span className="text-[8px] font-mono text-white/20 block tracking-widest uppercase">Node_ID</span>
          <span className="text-[10px] font-mono text-cyan-400/60 block tracking-tighter">0x{index.toString(16).padStart(2, '0')}</span>
        </div>
      </div>

      <h3 className="text-lg font-black text-white mb-2 tracking-tight uppercase italic group-hover:text-cyan-400 transition-colors group-hover:translateZ(20px)">
        {game.title}
      </h3>
      <p className="text-white/40 text-xs leading-relaxed mb-6 flex-grow font-serif italic group-hover:translateZ(10px)">
        {game.description}
      </p>

      <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
        <div className="flex flex-col">
          <span className="text-[8px] font-bold tracking-widest text-white/20 uppercase">Threat_Level</span>
          <span className={`text-[10px] font-bold tracking-widest uppercase ${
            game.difficulty === 'EXPERT' ? 'text-red-500' : 
            game.difficulty === 'HARD' ? 'text-amber-500' : 
            'text-cyan-400'
          }`}>
            {game.difficulty}
          </span>
        </div>
        <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-cyan-500/20 group-hover:border-cyan-500/50 transition-all">
          <ChevronRight className="w-4 h-4 text-white/40 group-hover:text-cyan-400" />
        </div>
      </div>
    </div>
  </motion.div>
);

type GameType = 
  | 'HUB' 
  | 'HUB_3D'
  | 'TIC_TAC_TOE' 
  | 'MIND_READER' 
  | 'NUMBER_GUESS' 
  | 'RIDDLE_MASTER' 
  | 'GRID_BATTLE' 
  | 'MEMORY_MATCH' 
  | 'REFLEX_TEST' 
  | 'CARD_REALM' 
  | 'PATH_FINDER'
  | 'WORD_GUESS'
  | 'CHESS'
  | 'TRAFFIC_MANAGER'
  | 'EMERGENCY_HERO'
  | 'TACTICAL_SHOOTER'
  | 'EMAIL_TRIAGE';

interface Game {
  id: GameType;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'EXPERT';
}

const games: Game[] = [
  {
    id: 'TIC_TAC_TOE',
    title: 'Tic-Tac-Toe',
    description: 'The classic game of X and O, enhanced with tactical AI analysis.',
    icon: <Grid3X3 className="w-6 h-6" />,
    color: 'from-cyan-500 to-blue-600',
    difficulty: 'EASY'
  },
  {
    id: 'MIND_READER',
    title: 'Mind Reader',
    description: 'Neural Verification Challenge. Can you distinguish between AI-generated facts and fakes across multiple domains?',
    icon: <Brain className="w-6 h-6" />,
    color: 'from-emerald-500 to-teal-500',
    difficulty: 'HARD'
  },
  {
    id: 'NUMBER_GUESS',
    title: 'Number Quest',
    description: 'Enter the numeric void and solve AI-generated mathematical and trivia challenges.',
    icon: <Hash className="w-6 h-6" />,
    color: 'from-blue-400 to-indigo-600',
    difficulty: 'MEDIUM'
  },
  {
    id: 'RIDDLE_MASTER',
    title: 'Riddle Master',
    description: 'Solve challenging riddles and puzzles generated by the AI.',
    icon: <HelpCircle className="w-6 h-6" />,
    color: 'from-indigo-500 to-blue-700',
    difficulty: 'HARD'
  },
  {
    id: 'MEMORY_MATCH',
    title: 'Memory Match',
    description: 'Test your memory by repeating increasingly complex patterns.',
    icon: <Activity className="w-6 h-6" />,
    color: 'from-cyan-400 to-emerald-500',
    difficulty: 'MEDIUM'
  },
  {
    id: 'CARD_REALM',
    title: 'Nexus Casino',
    description: 'Enter the ultimate card realm. Play Poker, Solitaire, and more in a high-stakes futuristic environment.',
    icon: <Diamond className="w-6 h-6" />,
    color: 'from-red-500 to-rose-700',
    difficulty: 'HARD'
  },
  {
    id: 'WORD_GUESS',
    title: 'Word Guess',
    description: 'Guess the hidden word using clues provided by the AI.',
    icon: <Terminal className="w-6 h-6" />,
    color: 'from-cyan-400 to-blue-600',
    difficulty: 'MEDIUM'
  },
  {
    id: 'CHESS',
    title: 'Grandmaster Chess',
    description: 'The ultimate strategic challenge. Play against AI or real opponents in a high-fidelity environment.',
    icon: <Box className="w-6 h-6" />,
    color: 'from-gray-700 to-black',
    difficulty: 'EXPERT'
  },
  {
    id: 'TRAFFIC_MANAGER',
    title: 'Traffic Manager',
    description: 'Advanced 8-sector urban traffic simulation with dynamic difficulty levels.',
    icon: <Route className="w-6 h-6" />,
    color: 'from-cyan-500 to-emerald-600',
    difficulty: 'EXPERT'
  },
  {
    id: 'EMERGENCY_HERO',
    title: 'Emergency Hero',
    description: 'Save lives by managing resources during major catastrophes.',
    icon: <ShieldAlert className="w-6 h-6" />,
    color: 'from-amber-500 to-red-600',
    difficulty: 'EXPERT'
  },
  {
    id: 'TACTICAL_SHOOTER',
    title: 'Tactical Shooter',
    description: 'Lead a tactical squad to neutralize threats in a digital world.',
    icon: <Target className="w-6 h-6" />,
    color: 'from-red-500 to-orange-600',
    difficulty: 'HARD'
  },
  {
    id: 'EMAIL_TRIAGE',
    title: 'Email Triage (OpenEnv)',
    description: 'A real-world simulation of an email triage task for AI agent training and evaluation.',
    icon: <Mail className="w-6 h-6" />,
    color: 'from-cyan-500 to-blue-600',
    difficulty: 'MEDIUM'
  }
];

const NexusEnvironment = () => (
  <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden">
    <div className="absolute inset-0 nexus-bg-mesh opacity-30" />
    <div className="absolute inset-0 animate-grid-flow opacity-10" 
      style={{ 
        backgroundImage: 'linear-gradient(rgba(6, 182, 212, 0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.2) 1px, transparent 1px)',
        backgroundSize: '50px 50px'
      }} 
    />
    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60" />
    
    {/* Floating Particles */}
    {[...Array(20)].map((_, i) => (
      <motion.div
        key={i}
        initial={{ 
          x: Math.random() * 1000, 
          y: Math.random() * 1000,
          opacity: Math.random() * 0.5
        }}
        animate={{ 
          y: [null, -200],
          opacity: [null, 0]
        }}
        transition={{ 
          duration: Math.random() * 10 + 10, 
          repeat: Infinity, 
          ease: "linear" 
        }}
        className="absolute w-1 h-1 bg-cyan-400 rounded-full blur-[1px]"
      />
    ))}
  </div>
);

export default function App() {
  const [activeGame, setActiveGame] = useState<GameType>('HUB');
  const [pendingGame, setPendingGame] = useState<Game | null>(null);
  const [showSplash, setShowSplash] = useState(true);
  const [user, setUser] = useState<{ name: string, method: string } | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);
  const [difficulty, setDifficulty] = useState('MEDIUM');
  const [greeting, setGreeting] = useState("Initializing Nexus Core...");
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20
      });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  useEffect(() => {
    const fetchGreeting = async () => {
      const msg = await getHubGreeting();
      setGreeting(msg || "Welcome to the Nexus.");
    };
    fetchGreeting();
  }, []);

  const renderActiveGame = () => {
    switch (activeGame) {
      case 'TIC_TAC_TOE': return <NeonTicTacToe difficulty={difficulty} />;
      case 'MIND_READER': return <MindReader />;
      case 'NUMBER_GUESS': return <NumberQuest difficulty={difficulty} />;
      case 'RIDDLE_MASTER': return <RiddleSphinx difficulty={difficulty} />;
      case 'MEMORY_MATCH': return <PatternMimic difficulty={difficulty} />;
      case 'CARD_REALM': return <CardRealm />;
      case 'WORD_GUESS': return <WordGuessGame difficulty={difficulty} />;
      case 'CHESS': return <ChessGame onBack={() => setActiveGame('HUB_3D')} />;
      case 'TRAFFIC_MANAGER': return <TrafficSimulator difficulty={difficulty} />;
      case 'EMERGENCY_HERO': return <DisasterResponse difficulty={difficulty} />;
      case 'TACTICAL_SHOOTER': return <CyberStrikeContainer difficulty={difficulty} />;
      case 'EMAIL_TRIAGE': return <EmailTriage />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#010103] text-white font-sans selection:bg-cyan-500/30 overflow-x-hidden circuit-bg p-4 sm:p-8 relative">
      <NexusEnvironment />
      <AnimatePresence mode="wait">
        {showSplash ? (
          <SplashScreen 
            key="splash"
            onStart={() => {
              setShowSplash(false);
            }} 
          />
        ) : !user ? (
          <NexusAuth key="auth" onAuthenticated={(u) => {
            setUser(u);
            setActiveGame('HUB_3D');
          }} />
        ) : (
          <motion.div
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative"
          >
            {/* Modals */}
      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        difficulty={difficulty}
        setDifficulty={setDifficulty}
      />
      <CreatorModal 
        isOpen={isCreatorOpen} 
        onClose={() => setIsCreatorOpen(false)} 
      />

      {/* Background Effects */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <FloatingData />
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-cyan-500/5 blur-[150px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-fuchsia-500/5 blur-[150px] rounded-full animate-pulse" />
        <div className="absolute inset-0 scanline opacity-5" />
      </div>

      {/* Main Container */}
      <div className="w-full max-w-full mx-auto min-h-screen flex flex-col relative z-10 lg:p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex-1 glass-panel lg:rounded-[2.5rem] p-4 sm:p-8 relative overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
        >
          {/* HUD Frame Elements */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent" />
          <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-fuchsia-500/30 to-transparent" />
          <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-transparent via-cyan-500/30 to-transparent" />
          <div className="absolute top-0 right-0 w-1 h-full bg-gradient-to-b from-transparent via-fuchsia-500/30 to-transparent" />

          {/* Navigation */}
          <nav className="relative z-50 mb-12">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-6 cursor-pointer" onClick={() => setActiveGame('HUB_3D')}>
                <div className="w-14 h-14 bg-cyan-500/10 border border-cyan-500/50 text-cyan-400 flex items-center justify-center rounded-xl font-black text-2xl shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                  N
                </div>
                <div>
                  <h1 className="text-3xl font-black tracking-tighter uppercase italic leading-none text-glow-cyan">NEXUS INTERFACE</h1>
                  <span className="text-[10px] font-mono tracking-[0.5em] text-white/40 uppercase">PROJECT AI: NEXUS CORE // {user?.name || 'GUEST'}</span>
                </div>
              </div>

              <div className="hidden lg:flex items-center gap-12">
                <div className="flex gap-4 mr-8">
                  <button 
                    onClick={() => setActiveGame('HUB')}
                    className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all border ${
                      activeGame === 'HUB' 
                        ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]' 
                        : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'
                    }`}
                  >
                    Standard_Core
                  </button>
                  <button 
                    onClick={() => setActiveGame('HUB_3D')}
                    className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all border ${
                      activeGame === 'HUB_3D' 
                        ? 'bg-fuchsia-500/20 border-fuchsia-500/50 text-fuchsia-400 shadow-[0_0_15px_rgba(217,70,239,0.3)]' 
                        : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'
                    }`}
                  >
                    3D_Nexus_Core
                  </button>
                </div>
                <div className="flex gap-8">
                  <HUDGauge label="Neural_Sync" value={88} color="#06b6d4" />
                  <HUDGauge label="Core_Load" value={42} color="#d946ef" />
                  <HUDGauge label="Security" value={99} color="#10b981" />
                </div>
                <div className="h-12 w-[1px] bg-white/10" />
                <button 
                  onClick={() => setIsSettingsOpen(true)}
                  className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-cyan-500/20 hover:border-cyan-500/50 transition-all group"
                >
                  <Settings className="w-5 h-5 text-white/40 group-hover:text-cyan-400" />
                </button>
                <button 
                  onClick={() => setIsCreatorOpen(true)}
                  className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-fuchsia-500/20 hover:border-fuchsia-500/50 transition-all group"
                >
                  <Info className="w-5 h-5 text-white/40 group-hover:text-fuchsia-400" />
                </button>
                <div className="flex flex-col items-end">
                  <span className="text-[8px] font-mono text-cyan-400/40 uppercase tracking-widest">User_Session</span>
                  <span className="text-sm font-mono text-white/80">AJAY_0X92F</span>
                </div>
              </div>
            </div>
          </nav>

          <main className="relative z-10">
            <AnimatePresence mode="wait">
              {pendingGame ? (
                <GameInstructions 
                  key="instructions"
                  game={pendingGame}
                  onStart={() => {
                    setActiveGame(pendingGame.id);
                    setPendingGame(null);
                  }}
                  onBack={() => setPendingGame(null)}
                />
              ) : (
                <motion.div
                  key={activeGame}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                >
                  {(activeGame === 'HUB' || activeGame === 'HUB_3D') && (
                    <div className="w-full h-full">
                      {activeGame === 'HUB_3D' ? (
                        <GameHub3D 
                          onSelectGame={(id) => {
                            const game = games.find(g => g.id === id);
                            if (game) setPendingGame(game);
                          }} 
                          onOpenList={() => setActiveGame('HUB')} 
                          games={games} 
                        />
                      ) : (
                        <div className="relative min-h-[700px] flex items-center justify-center w-full">
                          <div className="absolute inset-0 opacity-20 pointer-events-none">
                            <Vortex />
                          </div>
                          <div className="w-full relative z-10 px-4">
                            <GameListMobile 
                              games={games} 
                              onSelectGame={(id) => {
                                const game = games.find(g => g.id === id);
                                if (game) setPendingGame(game);
                              }} 
                              onBack={() => setActiveGame('HUB_3D')}
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {activeGame !== 'HUB' && activeGame !== 'HUB_3D' && (
                    <div className="w-full mx-auto">
                      <button 
                        onClick={() => setActiveGame('HUB_3D')}
                        className="mb-8 flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-white/40 hover:text-white transition-colors group"
                      >
                        <ChevronRight className="w-4 h-4 rotate-180 group-hover:-translate-x-1 transition-transform" />
                        De-initialize Node // Return to Core
                      </button>
                      <div className="hologram-glow rounded-3xl overflow-hidden w-full flex-1 flex flex-col min-h-[800px]">
                        {renderActiveGame()}
                      </div>
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </main>
        </motion.div>
      </div>

      {/* Footer HUD */}
      <footer className="fixed bottom-4 left-8 right-8 z-50 pointer-events-none">
        <div className="flex justify-between items-end">
          <div className="flex gap-12">
            <div className="flex flex-col gap-2">
              <span className="text-[8px] font-mono tracking-widest text-white/20 uppercase">Neural_Flux</span>
              <div className="flex gap-1 items-end h-8">
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ height: [10, 30, 15, 25, 10] }}
                    transition={{ duration: 1 + Math.random(), repeat: Infinity }}
                    className="w-1 bg-cyan-500/40 rounded-full"
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-right">
              <span className="text-[8px] font-mono text-white/20 block uppercase">System_Clock</span>
              <span className="text-xs font-mono text-white/60">{new Date().toLocaleTimeString()}</span>
            </div>
            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-cyan-500 animate-pulse" />
            </div>
          </div>
        </div>
      </footer>

      {/* AI Assistant */}
      <AIAssistant gameContext={activeGame !== 'HUB' && activeGame !== 'HUB_3D' ? activeGame : undefined} />
    </motion.div>
        )}
      </AnimatePresence>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: rgba(255,255,255,0.02); }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(6,182,212,0.2); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(6,182,212,0.4); }
      `}} />
    </div>
  );
}
