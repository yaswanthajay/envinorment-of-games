import { State, Action, Observation, ActionType, Email } from './models';

/**
 * Email Triage Environment (OpenEnv Pattern)
 */
export class EmailTriageEnvironment {
  private state: State;
  private initial_emails: Email[] = [
    { id: "1", sender: "spam@bot.com", subject: "[SPAM] Win $1M!", body: "Click here to claim your prize.", category: "SPAM", is_flagged: false, is_read: false, folder: "Inbox" },
    { id: "2", sender: "billing@aws.com", subject: "[INVOICE] Your AWS Bill", body: "Your monthly bill is ready.", category: "INVOICE", is_flagged: false, is_read: false, folder: "Inbox" },
    { id: "3", sender: "ceo@company.com", subject: "[URGENT] Meeting in 5 mins", body: "Where are you?", category: "URGENT", is_flagged: false, is_read: false, folder: "Inbox" },
    { id: "4", sender: "newsletter@tech.com", subject: "Weekly Tech Digest", body: "Top 10 AI tools.", category: "GENERAL", is_flagged: false, is_read: false, folder: "Inbox" },
    { id: "5", sender: "client@agency.com", subject: "[URGENT] Project Update", body: "We need the final files.", category: "URGENT", is_flagged: false, is_read: false, folder: "Inbox" },
    { id: "6", sender: "spam@scam.net", subject: "[SPAM] Account Locked", body: "Verify your login.", category: "SPAM", is_flagged: false, is_read: false, folder: "Inbox" },
    { id: "7", sender: "finance@corp.com", subject: "[INVOICE] Q1 Report", body: "Please review the attached invoice.", category: "INVOICE", is_flagged: false, is_read: false, folder: "Inbox" }
  ];

  constructor() {
    this.state = this.reset_state();
  }

  private reset_state(task_id: string = "easy_cleanup"): State {
    const emails = JSON.parse(JSON.stringify(this.initial_emails));
    return {
      emails,
      folders: ["Inbox", "Spam", "Finance", "Archive", "Trash"],
      step_count: 0,
      task_id,
      score: 0
    };
  }

  public reset(task_id: string = "easy_cleanup"): Observation {
    this.state = this.reset_state(task_id);
    return this.get_observation("System initialized. Task: " + task_id);
  }

  public generate_email(email: Partial<Email>): Email {
    const newEmail: Email = {
      id: Math.random().toString(36).substr(2, 9),
      sender: email.sender || "unknown@example.com",
      subject: email.subject || "No Subject",
      body: email.body || "",
      category: email.category || "GENERAL",
      is_flagged: email.is_flagged || false,
      is_read: email.is_read || false,
      folder: email.folder || "Inbox"
    };
    this.state.emails.push(newEmail);
    return newEmail;
  }

  public step(action: Action): Observation {
    this.state.step_count++;
    const email = this.state.emails.find(e => e.id === action.email_id);
    
    if (!email) {
      return this.get_observation("Email not found.", -0.1);
    }

    let reward = 0;
    let message = "";

    switch (action.type) {
      case ActionType.DELETE:
        email.folder = "Trash";
        if (email.category === "SPAM") {
          reward = 0.5;
          message = "Correctly deleted spam email.";
        } else {
          reward = -0.5;
          message = "Incorrectly deleted a non-spam email.";
        }
        break;

      case ActionType.MOVE:
        if (action.folder) {
          email.folder = action.folder;
          if (email.category === "INVOICE" && action.folder === "Finance") {
            reward = 0.5;
            message = "Correctly categorized invoice.";
          } else {
            reward = -0.2;
            message = "Incorrectly categorized email.";
          }
        }
        break;

      case ActionType.FLAG:
        email.is_flagged = true;
        if (email.category === "URGENT") {
          reward = 0.5;
          message = "Correctly flagged urgent email.";
        } else {
          reward = -0.2;
          message = "Incorrectly flagged non-urgent email.";
        }
        break;

      case ActionType.READ:
        email.is_read = true;
        reward = 0.1;
        message = "Email marked as read.";
        break;

      default:
        reward = -0.1;
        message = "Unknown action.";
    }

    this.state.score += reward;
    
    // Check if task is complete
    const done = this.check_completion();
    if (done) {
      message += " Task complete.";
    }

    return this.get_observation(message, reward, done);
  }

  private check_completion(): boolean {
    if (this.state.task_id === "easy_cleanup") {
      return this.state.emails.filter(e => e.category === "SPAM").every(e => e.folder === "Trash");
    }
    if (this.state.task_id === "medium_categorization") {
      return this.state.emails.filter(e => e.category === "INVOICE").every(e => e.folder === "Finance");
    }
    if (this.state.task_id === "hard_prioritization") {
      return this.state.emails.filter(e => e.category === "URGENT").every(e => e.is_flagged);
    }
    return false;
  }

  public get_state(): State {
    return this.state;
  }

  private get_observation(message: string, reward: number = 0, done: boolean = false): Observation {
    return {
      emails: this.state.emails,
      folders: this.state.folders,
      message,
      reward,
      done,
      info: {
        step_count: this.state.step_count,
        task_id: this.state.task_id,
        score: this.state.score
      }
    };
  }

  public get_grader_score(): number {
    const total_relevant = this.get_total_relevant();
    if (total_relevant === 0) return 1.0;
    
    let correct = 0;
    if (this.state.task_id === "easy_cleanup") {
      correct = this.state.emails.filter(e => e.category === "SPAM" && e.folder === "Trash").length;
    } else if (this.state.task_id === "medium_categorization") {
      correct = this.state.emails.filter(e => e.category === "INVOICE" && e.folder === "Finance").length;
    } else if (this.state.task_id === "hard_prioritization") {
      correct = this.state.emails.filter(e => e.category === "URGENT" && e.is_flagged).length;
    }
    
    return correct / total_relevant;
  }

  private get_total_relevant(): number {
    if (this.state.task_id === "easy_cleanup") return this.initial_emails.filter(e => e.category === "SPAM").length;
    if (this.state.task_id === "medium_categorization") return this.initial_emails.filter(e => e.category === "INVOICE").length;
    if (this.state.task_id === "hard_prioritization") return this.initial_emails.filter(e => e.category === "URGENT").length;
    return 0;
  }
}
