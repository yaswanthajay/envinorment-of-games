/**
 * OpenEnv-compatible models for Email Triage Task
 */

export enum ActionType {
  DELETE = "DELETE",
  MOVE = "MOVE",
  FLAG = "FLAG",
  REPLY = "REPLY",
  READ = "READ"
}

export interface Action {
  type: ActionType;
  email_id: string;
  folder?: string;
  reply_text?: string;
}

export interface Email {
  id: string;
  sender: string;
  subject: string;
  body: string;
  category: "INVOICE" | "SPAM" | "URGENT" | "GENERAL";
  is_flagged: boolean;
  is_read: boolean;
  folder: string;
}

export interface Observation {
  emails: Email[];
  folders: string[];
  message: string;
  reward: number;
  done: boolean;
  info: Record<string, any>;
}

export interface State {
  emails: Email[];
  folders: string[];
  step_count: number;
  task_id: string;
  score: number;
}
