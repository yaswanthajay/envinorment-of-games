
class SoundManager {
  private ctx: AudioContext | null = null;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  private playTone(freq: number, type: OscillatorType, duration: number, volume: number = 0.1) {
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

    gain.gain.setValueAtTime(volume, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  playClick() {
    this.playTone(800, 'sine', 0.1, 0.05);
  }

  playMove() {
    this.playTone(600, 'sine', 0.05, 0.03);
  }

  playCheck() {
    this.playTone(440, 'triangle', 0.1, 0.1);
    setTimeout(() => this.playTone(440, 'triangle', 0.1, 0.1), 150);
  }

  playCheckmate() {
    this.playTone(880, 'square', 0.2, 0.1);
    setTimeout(() => this.playTone(440, 'square', 0.2, 0.1), 200);
    setTimeout(() => this.playTone(220, 'square', 0.4, 0.1), 400);
  }

  playCapture() {
    this.playTone(400, 'sawtooth', 0.05, 0.1);
    setTimeout(() => this.playTone(200, 'sawtooth', 0.1, 0.1), 50);
  }

  playSuccess() {
    this.playTone(400, 'sine', 0.1, 0.1);
    setTimeout(() => this.playTone(600, 'sine', 0.1, 0.1), 100);
    setTimeout(() => this.playTone(800, 'sine', 0.2, 0.1), 200);
  }

  playError() {
    this.playTone(200, 'sawtooth', 0.1, 0.1);
    setTimeout(() => this.playTone(150, 'sawtooth', 0.3, 0.1), 100);
  }

  playAction() {
    this.playTone(1000, 'sine', 0.05, 0.03);
  }

  playGameOver(win: boolean) {
    if (win) {
      this.playTone(523.25, 'sine', 0.2); // C5
      setTimeout(() => this.playTone(659.25, 'sine', 0.2), 150); // E5
      setTimeout(() => this.playTone(783.99, 'sine', 0.2), 300); // G5
      setTimeout(() => this.playTone(1046.50, 'sine', 0.4), 450); // C6
    } else {
      this.playTone(392.00, 'sawtooth', 0.3); // G4
      setTimeout(() => this.playTone(349.23, 'sawtooth', 0.3), 200); // F4
      setTimeout(() => this.playTone(311.13, 'sawtooth', 0.5), 400); // Eb4
    }
  }
}

export const sounds = new SoundManager();
