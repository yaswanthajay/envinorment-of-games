import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Zap, Target, Activity, Cpu, Fingerprint, Eye, ShieldAlert, Terminal, Loader2, Sparkles, Globe, BookOpen, Landmark, DollarSign, Film, Trophy, History, FlaskConical, Laptop, CheckCircle2, XCircle, Rocket, TreePine, Utensils, ScrollText, Palette, Newspaper, Briefcase } from 'lucide-react';
import { getFactOrFakeQuestion } from '../services/aiService';

const TOPICS = [
  { id: 'STUDY', name: 'Study', icon: <BookOpen className="w-4 h-4" /> },
  { id: 'POLITICS', name: 'Politics', icon: <Landmark className="w-4 h-4" /> },
  { id: 'MONEY', name: 'Money', icon: <DollarSign className="w-4 h-4" /> },
  { id: 'MOVIES', name: 'Movies', icon: <Film className="w-4 h-4" /> },
  { id: 'CRICKET', name: 'Cricket', icon: <Trophy className="w-4 h-4" /> },
  { id: 'HISTORY', name: 'History', icon: <History className="w-4 h-4" /> },
  { id: 'SCIENCE', name: 'Science', icon: <FlaskConical className="w-4 h-4" /> },
  { id: 'TECH', name: 'Technology', icon: <Laptop className="w-4 h-4" /> },
  { id: 'GEOGRAPHY', name: 'Geography', icon: <Globe className="w-4 h-4" /> },
  { id: 'SPORTS', name: 'Sports', icon: <Activity className="w-4 h-4" /> },
  { id: 'SPACE', name: 'Space', icon: <Rocket className="w-4 h-4" /> },
  { id: 'NATURE', name: 'Nature', icon: <TreePine className="w-4 h-4" /> },
  { id: 'FOOD', name: 'Food', icon: <Utensils className="w-4 h-4" /> },
  { id: 'LITERATURE', name: 'Literature', icon: <ScrollText className="w-4 h-4" /> },
  { id: 'ART', name: 'Art', icon: <Palette className="w-4 h-4" /> },
  { id: 'NEWS', name: 'Current Affairs', icon: <Newspaper className="w-4 h-4" /> },
  { id: 'BUSINESS', name: 'Business', icon: <Briefcase className="w-4 h-4" /> },
];

const REGIONS_WITH_STATES: Record<string, string[]> = {
  'Global': [],
  'India': ['Andhra Pradesh', 'Telangana', 'Karnataka', 'Tamil Nadu', 'Maharashtra', 'Delhi', 'Gujarat', 'Rajasthan', 'Uttar Pradesh', 'West Bengal'],
  'USA': ['California', 'Texas', 'Florida', 'New York', 'Illinois', 'Pennsylvania', 'Ohio', 'Georgia', 'Washington', 'Arizona'],
  'UK': ['England', 'Scotland', 'Wales', 'Northern Ireland'],
  'Europe': ['Germany', 'France', 'Italy', 'Spain', 'Netherlands', 'Sweden', 'Norway', 'Poland'],
  'Asia': ['China', 'Japan', 'South Korea', 'Indonesia', 'Vietnam', 'Thailand', 'Malaysia'],
  'Australia': ['New South Wales', 'Victoria', 'Queensland', 'Western Australia', 'South Australia'],
  'Africa': ['Nigeria', 'Egypt', 'South Africa', 'Kenya', 'Ethiopia', 'Morocco'],
  'South America': ['Brazil', 'Argentina', 'Colombia', 'Chile', 'Peru'],
  'Middle East': ['Saudi Arabia', 'UAE', 'Israel', 'Turkey', 'Egypt', 'Qatar']
};

const LANGUAGES = [
  'English', 'Hindi', 'Telugu', 'Spanish', 'French', 'German', 'Chinese', 'Japanese', 'Arabic'
];

export default function MindReader() {
  const [gameState, setGameState] = useState<'SETUP' | 'PLAYING' | 'RESULT'>('SETUP');
  const [selectedTopic, setSelectedTopic] = useState(TOPICS[0]);
  const [selectedRegion, setSelectedRegion] = useState('Global');
  const [selectedState, setSelectedState] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('English');
  const [currentQuestion, setCurrentQuestion] = useState<{ statement: string, isReal: boolean, explanation: string } | null>(null);
  const [score, setScore] = useState(0);
  const [difficulty, setDifficulty] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [userAnswer, setUserAnswer] = useState<boolean | null>(null);
  const [feedback, setFeedback] = useState<{ correct: boolean, message: string } | null>(null);
  const [history, setHistory] = useState<{ statement: string, correct: boolean }[]>([]);

  useEffect(() => {
    // Attempt to detect region based on browser language or timezone
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (timeZone.includes('Asia/Kolkata') || timeZone.includes('Asia/Calcutta')) {
      setSelectedRegion('India');
      setSelectedLanguage('English'); // Default to English but user can change
    } else if (timeZone.includes('America')) {
      setSelectedRegion('USA');
    } else if (timeZone.includes('Europe/London')) {
      setSelectedRegion('UK');
    } else if (timeZone.includes('Europe')) {
      setSelectedRegion('Europe');
    } else if (timeZone.includes('Australia')) {
      setSelectedRegion('Australia');
    } else if (timeZone.includes('Africa')) {
      setSelectedRegion('Africa');
    }
  }, []);

  // Reset state when region changes
  useEffect(() => {
    const states = REGIONS_WITH_STATES[selectedRegion];
    if (states && states.length > 0) {
      setSelectedState(states[0]);
    } else {
      setSelectedState('');
    }
  }, [selectedRegion]);

  const fetchQuestion = async () => {
    setIsLoading(true);
    const question = await getFactOrFakeQuestion(
      selectedTopic.name, 
      selectedRegion, 
      selectedState, 
      selectedLanguage, 
      Math.round(difficulty)
    );
    if (question) {
      setCurrentQuestion(question);
      setGameState('PLAYING');
      setUserAnswer(null);
      setFeedback(null);
    }
    setIsLoading(false);
  };

  const handleAnswer = (answer: boolean) => {
    if (!currentQuestion) return;
    setUserAnswer(answer);
    const isCorrect = answer === currentQuestion.isReal;
    setFeedback({
      correct: isCorrect,
      message: isCorrect ? "Correct! Your neural pathways are sharp." : "Incorrect. The Nexus Mind has deceived you."
    });
    
    if (isCorrect) {
      setScore(s => s + Math.round(10 * difficulty));
      setDifficulty(d => Math.min(10, d + 0.5));
    } else {
      setDifficulty(d => Math.max(1, d - 0.2));
    }

    setHistory(prev => [{ statement: currentQuestion.statement, correct: isCorrect }, ...prev].slice(0, 10));
    setGameState('RESULT');
  };

  const startGame = () => {
    fetchQuestion();
  };

  const nextQuestion = () => {
    fetchQuestion();
  };

  return (
    <div className="relative w-full max-w-6xl mx-auto h-[700px] flex gap-6 p-6 font-sans overflow-hidden">
      {/* Background Neural Network Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#10b981_0%,transparent_70%)] opacity-10 animate-pulse" />
        <svg className="w-full h-full">
          <pattern id="neural-grid" width="100" height="100" patternUnits="userSpaceOnUse">
            <circle cx="50" cy="50" r="1" fill="#10b981" />
            <path d="M 50 50 L 150 50 M 50 50 L 50 150" stroke="#10b981" strokeWidth="0.2" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#neural-grid)" />
        </svg>
      </div>

      {/* Left HUD: Metrics */}
      <div className="w-64 flex flex-col gap-4 z-10">
        <div className="p-4 bg-black/60 border border-emerald-500/20 rounded-2xl backdrop-blur-xl">
          <div className="flex items-center gap-2 mb-4 text-emerald-400">
            <Activity className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Neural Metrics</span>
          </div>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-[8px] text-white/40 mb-1 uppercase">
                <span>Cognitive Score</span>
                <span>{score}</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-emerald-500"
                  animate={{ width: `${(score % 1000) / 10}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-[8px] text-white/40 mb-1 uppercase">
                <span>Difficulty Level</span>
                <span>{difficulty.toFixed(1)} / 10</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  className="h-full bg-blue-500"
                  animate={{ width: `${difficulty * 10}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-black/60 border border-emerald-500/20 rounded-2xl backdrop-blur-xl flex-1">
          <div className="flex items-center gap-2 mb-4 text-emerald-400">
            <Terminal className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Cognitive Log</span>
          </div>
          <div className="space-y-2 max-h-[300px] overflow-hidden">
            {history.map((h, i) => (
              <div key={i} className={`text-[9px] font-mono flex items-center gap-2 ${h.correct ? 'text-emerald-400/50' : 'text-red-400/50'}`}>
                <span>{h.correct ? '✓' : '✗'}</span>
                <span className="truncate">{h.statement}</span>
              </div>
            ))}
            {history.length === 0 && (
              <div className="text-[9px] font-mono text-white/20 italic">Awaiting neural pulses...</div>
            )}
          </div>
        </div>
      </div>

      {/* Main Arena */}
      <div className="flex-1 flex flex-col gap-6 z-10">
        {/* Top Header */}
        <div className="flex justify-between items-center p-6 bg-black/60 border border-emerald-500/20 rounded-3xl backdrop-blur-xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/30">
              <Brain className="w-6 h-6 text-emerald-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-2xl font-black text-white tracking-tighter italic uppercase">Mind Reader: Fact or Fake</h2>
              <p className="text-[10px] text-emerald-400/60 font-mono uppercase tracking-widest">Neural Verification v5.0.0</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[8px] text-white/40 uppercase font-bold mb-1">Current Topic</div>
            <div className="text-xl font-black text-white flex items-center gap-2 justify-end">
              {selectedTopic.icon}
              {selectedTopic.name}
            </div>
          </div>
        </div>

        {/* Interaction Zone */}
        <div className="flex-1 bg-black/60 border border-emerald-500/20 rounded-3xl backdrop-blur-xl relative flex flex-col items-center justify-center p-8 overflow-hidden">
          <AnimatePresence mode="wait">
            {gameState === 'SETUP' && (
              <motion.div 
                key="setup"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="w-full max-w-2xl space-y-8"
              >
                <div className="text-center space-y-2">
                  <h3 className="text-3xl font-black text-white uppercase tracking-tighter">Initialize Neural Link</h3>
                  <p className="text-white/40 text-sm">Select your cognitive domain and regional scope.</p>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Cognitive Topic</label>
                    <div className="grid grid-cols-2 gap-2 max-h-[180px] overflow-y-auto pr-2 custom-scrollbar">
                      {TOPICS.map(topic => (
                        <button
                          key={topic.id}
                          onClick={() => setSelectedTopic(topic)}
                          className={`p-3 rounded-xl border transition-all flex items-center gap-2 text-xs ${selectedTopic.id === topic.id ? 'bg-emerald-500/20 border-emerald-500 text-white' : 'bg-white/5 border-white/10 text-white/40 hover:border-white/30'}`}
                        >
                          {topic.icon}
                          {topic.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Regional Scope</label>
                    <div className="grid grid-cols-2 gap-2 max-h-[180px] overflow-y-auto pr-2 custom-scrollbar">
                      {Object.keys(REGIONS_WITH_STATES).map(region => (
                        <button
                          key={region}
                          onClick={() => setSelectedRegion(region)}
                          className={`p-3 rounded-xl border transition-all text-xs ${selectedRegion === region ? 'bg-blue-500/20 border-blue-500 text-white' : 'bg-white/5 border-white/10 text-white/40 hover:border-white/30'}`}
                        >
                          {region}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Language</label>
                    <div className="grid grid-cols-3 gap-2 max-h-[120px] overflow-y-auto pr-2 custom-scrollbar">
                      {LANGUAGES.map(lang => (
                        <button
                          key={lang}
                          onClick={() => setSelectedLanguage(lang)}
                          className={`p-2 rounded-lg border transition-all text-[10px] ${selectedLanguage === lang ? 'bg-purple-500/20 border-purple-500 text-white' : 'bg-white/5 border-white/10 text-white/40 hover:border-white/30'}`}
                        >
                          {lang}
                        </button>
                      ))}
                    </div>
                  </div>

                  {REGIONS_WITH_STATES[selectedRegion].length > 0 && (
                    <div className="space-y-4">
                      <label className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">State / Province</label>
                      <div className="grid grid-cols-2 gap-2 max-h-[120px] overflow-y-auto pr-2 custom-scrollbar">
                        {REGIONS_WITH_STATES[selectedRegion].map(state => (
                          <button
                            key={state}
                            onClick={() => setSelectedState(state)}
                            className={`p-2 rounded-lg border transition-all text-[10px] ${selectedState === state ? 'bg-orange-500/20 border-orange-500 text-white' : 'bg-white/5 border-white/10 text-white/40 hover:border-white/30'}`}
                          >
                            {state}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <button
                  onClick={startGame}
                  disabled={isLoading}
                  className="w-full py-4 bg-emerald-500 text-black font-black uppercase tracking-widest rounded-2xl hover:bg-emerald-400 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Begin Neural Scan'}
                </button>
              </motion.div>
            )}

            {gameState === 'PLAYING' && currentQuestion && (
              <motion.div 
                key="playing"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="w-full max-w-3xl space-y-12 text-center"
              >
                <div className="space-y-6">
                  <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] font-bold text-emerald-400 uppercase tracking-[0.2em]">
                    Verification Required
                  </div>
                  <h3 className="text-3xl font-serif italic text-white leading-tight">
                    "{currentQuestion.statement}"
                  </h3>
                </div>

                <div className="flex gap-8 justify-center">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleAnswer(true)}
                    className="group relative w-48 h-24 rounded-2xl border-2 border-emerald-500/30 bg-emerald-500/5 flex flex-col items-center justify-center gap-2 hover:border-emerald-500 hover:bg-emerald-500/10 transition-all"
                  >
                    <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                    <span className="text-xs font-black uppercase tracking-widest text-white">REAL (YES)</span>
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleAnswer(false)}
                    className="group relative w-48 h-24 rounded-2xl border-2 border-red-500/30 bg-red-500/5 flex flex-col items-center justify-center gap-2 hover:border-red-500 hover:bg-red-500/10 transition-all"
                  >
                    <XCircle className="w-8 h-8 text-red-400" />
                    <span className="text-xs font-black uppercase tracking-widest text-white">FAKE (NO)</span>
                  </motion.button>
                </div>
              </motion.div>
            )}

            {gameState === 'RESULT' && currentQuestion && feedback && (
              <motion.div 
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-2xl space-y-8 text-center"
              >
                <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center border-2 ${feedback.correct ? 'border-emerald-500 bg-emerald-500/10' : 'border-red-500 bg-red-500/10'}`}>
                  {feedback.correct ? <CheckCircle2 className="w-10 h-10 text-emerald-400" /> : <XCircle className="w-10 h-10 text-red-400" />}
                </div>

                <div className="space-y-4">
                  <h3 className={`text-4xl font-black uppercase tracking-tighter ${feedback.correct ? 'text-emerald-400' : 'text-red-400'}`}>
                    {feedback.correct ? 'Pattern Verified' : 'Neural Mismatch'}
                  </h3>
                  <p className="text-white/80 text-lg italic font-serif">
                    {currentQuestion.explanation}
                  </p>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={nextQuestion}
                    disabled={isLoading}
                    className="flex-1 py-4 bg-white text-black font-black uppercase tracking-widest rounded-2xl hover:bg-gray-200 transition-all flex items-center justify-center gap-2"
                  >
                    {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Next Pulse'}
                  </button>
                  <button
                    onClick={() => setGameState('SETUP')}
                    className="px-8 py-4 bg-white/5 border border-white/10 text-white font-black uppercase tracking-widest rounded-2xl hover:bg-white/10 transition-all"
                  >
                    Reset
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Right HUD: Diagnostics */}
      <div className="w-64 flex flex-col gap-4 z-10">
        <div className="p-4 bg-black/60 border border-emerald-500/20 rounded-2xl backdrop-blur-xl">
          <div className="flex items-center gap-2 mb-4 text-emerald-400">
            <Cpu className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">Heuristics</span>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-[8px] text-white/40 uppercase">Region</span>
              <span className="text-[10px] font-mono text-emerald-400">{selectedRegion}{selectedState ? ` - ${selectedState}` : ''}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[8px] text-white/40 uppercase">Language</span>
              <span className="text-[10px] font-mono text-orange-400">{selectedLanguage}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[8px] text-white/40 uppercase">Topic</span>
              <span className="text-[10px] font-mono text-blue-400">{selectedTopic.name}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[8px] text-white/40 uppercase">Cognition</span>
              <span className="text-[10px] font-mono text-purple-400">{gameState}</span>
            </div>
          </div>
        </div>

        <div className="p-4 bg-black/60 border border-emerald-500/20 rounded-2xl backdrop-blur-xl flex-1">
          <div className="flex items-center gap-2 mb-4 text-emerald-400">
            <ShieldAlert className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-widest">System Status</span>
          </div>
          <div className="space-y-4">
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[7px] text-white/20 uppercase">
                <span>Verification Accuracy</span>
                <span>{history.length > 0 ? Math.round((history.filter(h => h.correct).length / history.length) * 100) : 0}%</span>
              </div>
              <div className="h-0.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500/50" style={{ width: `${history.length > 0 ? (history.filter(h => h.correct).length / history.length) * 100 : 0}%` }} />
              </div>
            </div>
            <div className="mt-8 pt-4 border-t border-white/5">
              <div className="text-[8px] text-white/40 uppercase mb-2">Neural Link Status</div>
              <div className="p-2 bg-emerald-500/5 rounded border border-emerald-500/10">
                <div className="text-[9px] font-mono text-emerald-400/70">
                  {isLoading ? "FETCHING_DATA..." : "STABLE_CONNECTION"}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

