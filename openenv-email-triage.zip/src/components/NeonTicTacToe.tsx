import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getAIMove } from '../services/aiService';
import { 
  RefreshCw, 
  User, 
  Cpu, 
  Trophy, 
  XCircle, 
  MessageSquare, 
  Activity,
  Zap,
  Shield,
  Terminal,
  Brain,
  Grid3X3,
  Crosshair,
  Timer,
  AlertTriangle
} from 'lucide-react';
import { sounds } from '../lib/sounds';
import { GoogleGenAI } from "@google/genai";
import confetti from 'canvas-confetti';

const ArenaBackground = () => (
  <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-40">
    {/* Perspective Grid */}
    <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)]" />
    
    {/* Glowing Nodes */}
    {[...Array(6)].map((_, i) => (
      <motion.div
        key={i}
        animate={{ 
          opacity: [0.1, 0.3, 0.1],
          scale: [1, 1.2, 1]
        }}
        transition={{ duration: 3 + i, repeat: Infinity, delay: i }}
        style={{ 
          top: `${15 + i * 15}%`,
          left: i % 2 === 0 ? '5%' : '90%'
        }}
        className="absolute w-24 h-24 bg-cyan-500/10 blur-[40px] rounded-full"
      />
    ))}

    {/* Scanning Line */}
    <motion.div 
      animate={{ top: ['-10%', '110%'] }}
      transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
      className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent z-10"
    />
  </div>
);

const HUDPanel = ({ title, icon: Icon, children, side = 'left' }: { title: string, icon: any, children: React.ReactNode, side?: 'left' | 'right' }) => (
  <div className={`hidden lg:flex flex-col gap-4 w-64 p-6 bg-black/40 backdrop-blur-xl border border-white/5 rounded-[2rem] relative overflow-hidden ${side === 'left' ? 'order-1' : 'order-3'}`}>
    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    <div className="flex items-center gap-3 mb-2">
      <div className="p-2 bg-white/5 rounded-lg">
        <Icon className="w-4 h-4 text-cyan-400" />
      </div>
      <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/40">{title}</span>
    </div>
    {children}
  </div>
);

export default function NeonTicTacToe({ difficulty = "MEDIUM" }: { difficulty?: string }) {
  const [board, setBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [isUserTurn, setIsUserTurn] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);
  const [aiCommentary, setAiCommentary] = useState("Awaiting initial tactical input.");
  const [loading, setLoading] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [winStatus, setWinStatus] = useState<'WIN' | 'LOSE' | 'DRAW' | null>(null);
  const [aiFeedback, setAiFeedback] = useState<string>("");
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [stats, setStats] = useState({ wins: 0, losses: 0, draws: 0 });

  const checkWinner = (squares: (string | null)[]) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6]
    ];
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return squares.includes(null) ? null : 'Draw';
  };

  const generateFeedback = async (status: 'WIN' | 'LOSE' | 'DRAW') => {
    setIsGeneratingFeedback(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const prompt = `
        The player just finished a Tic-Tac-Toe game.
        Status: ${status}
        Difficulty: ${difficulty}
        Board: ${JSON.stringify(board)}
        
        Provide a short, punchy analysis of their performance. 
        Identify 1 weakness and give 1 specific tip for next time.
        Keep it under 60 words. Use a professional, AI-like encouraging tone.
      `;
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      setAiFeedback(response.text || "Strategic analysis unavailable.");
    } catch (error) {
      console.error("Feedback error:", error);
      setAiFeedback("The neural network is recalculating. Your play was noted.");
    } finally {
      setIsGeneratingFeedback(false);
    }
  };

  const endGame = (status: 'WIN' | 'LOSE' | 'DRAW') => {
    setIsGameOver(true);
    setWinStatus(status);
    if (status === 'WIN') setStats(s => ({ ...s, wins: s.wins + 1 }));
    if (status === 'LOSE') setStats(s => ({ ...s, losses: s.losses + 1 }));
    if (status === 'DRAW') setStats(s => ({ ...s, draws: s.draws + 1 }));
    
    sounds.playGameOver(status === 'WIN');
    if (status === 'WIN') confetti();
    generateFeedback(status);
  };

  const handleClick = async (i: number) => {
    if (board[i] || winner || !isUserTurn || isGameOver) return;

    sounds.playClick();
    const newBoard = [...board];
    newBoard[i] = 'X';
    setBoard(newBoard);
    
    const win = checkWinner(newBoard);
    if (win) {
      setWinner(win);
      endGame(win === 'X' ? 'WIN' : win === 'O' ? 'LOSE' : 'DRAW');
      return;
    }

    setIsUserTurn(false);
    setLoading(true);

    // AI Turn
    const aiResponse = await getAIMove({
      gameType: "Tic-Tac-Toe",
      board: newBoard,
      history: [],
      difficulty: difficulty
    });

    if (aiResponse && aiResponse.move !== undefined) {
      const move = parseInt(aiResponse.move);
      if (newBoard[move] === null) {
        newBoard[move] = 'O';
      } else {
        const emptyIndices = newBoard.map((v, idx) => v === null ? idx : null).filter(v => v !== null);
        if (emptyIndices.length > 0) {
          newBoard[emptyIndices[0] as number] = 'O';
        }
      }
      setAiCommentary(aiResponse.commentary || "Calculated.");
      sounds.playAction();
    }

    setBoard(newBoard);
    const finalWin = checkWinner(newBoard);
    if (finalWin) {
      setWinner(finalWin);
      endGame(finalWin === 'X' ? 'WIN' : finalWin === 'O' ? 'LOSE' : 'DRAW');
    }
    setIsUserTurn(true);
    setLoading(false);
  };

  const reset = () => {
    sounds.playAction();
    setBoard(Array(9).fill(null));
    setIsUserTurn(true);
    setWinner(null);
    setAiCommentary("Neural pathways reset. Ready for engagement.");
    setIsGameOver(false);
    setWinStatus(null);
    setAiFeedback("");
  };

  return (
    <div className="relative w-full min-h-[700px] flex items-center justify-center p-4 sm:p-8 overflow-hidden rounded-[3rem] bg-[#0a0b0d] border border-white/5 shadow-2xl">
      <ArenaBackground />

      <div className="relative z-10 flex flex-col lg:flex-row items-center justify-center gap-12 w-full max-w-7xl">
        
        {/* Left HUD: Player Intel */}
        <HUDPanel title="Combatant_Intel" icon={User} side="left">
          <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
              <div className="w-12 h-12 rounded-xl bg-cyan-500/20 flex items-center justify-center border border-cyan-500/30">
                <Zap className="w-6 h-6 text-cyan-400" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Signal_Strength</span>
                <span className="text-sm font-black text-white font-mono">98.4% // STABLE</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex flex-col items-center">
                <span className="text-[8px] font-black text-white/20 uppercase mb-1">Wins</span>
                <span className="text-xl font-black text-emerald-400 font-mono">{stats.wins}</span>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex flex-col items-center">
                <span className="text-[8px] font-black text-white/20 uppercase mb-1">Losses</span>
                <span className="text-xl font-black text-red-400 font-mono">{stats.losses}</span>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[8px] font-black text-white/20 uppercase">Tactical_Efficiency</span>
                <span className="text-[10px] font-mono text-cyan-400">72%</span>
              </div>
              <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  animate={{ width: '72%' }}
                  className="h-full bg-cyan-500 shadow-[0_0_10px_#06b6d4]"
                />
              </div>
            </div>
          </div>
        </HUDPanel>

        {/* Center: The Arena Board */}
        <div className="order-2 flex flex-col items-center gap-8">
          <div className="relative p-10 bg-black/60 backdrop-blur-3xl rounded-[3.5rem] border-[12px] border-[#1e2022] shadow-[0_0_100px_rgba(0,0,0,0.5)]">
            {/* Corner Accents */}
            <div className="absolute top-4 left-4 w-8 h-8 border-t-4 border-l-4 border-cyan-500/30 rounded-tl-xl" />
            <div className="absolute top-4 right-4 w-8 h-8 border-t-4 border-r-4 border-cyan-500/30 rounded-tr-xl" />
            <div className="absolute bottom-4 left-4 w-8 h-8 border-b-4 border-l-4 border-cyan-500/30 rounded-bl-xl" />
            <div className="absolute bottom-4 right-4 w-8 h-8 border-b-4 border-r-4 border-cyan-500/30 rounded-br-xl" />

            <div className="flex justify-between w-full mb-8 items-center px-2">
              <div className="flex flex-col">
                <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic flex items-center gap-3">
                  Tic-Tac-Toe
                </h2>
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
                  <span className="text-[8px] font-black text-cyan-400/60 uppercase tracking-[0.3em]">Arena_Active // Sector_09</span>
                </div>
              </div>
              <button 
                onClick={reset} 
                className="w-12 h-12 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/10 flex items-center justify-center transition-all group"
              >
                <RefreshCw className="w-5 h-5 text-white/40 group-hover:text-white group-hover:rotate-180 transition-all duration-500" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 relative">
              {/* Grid Lines Overlay */}
              <div className="absolute inset-0 pointer-events-none opacity-10">
                <div className="absolute top-1/3 left-0 right-0 h-px bg-white" />
                <div className="absolute top-2/3 left-0 right-0 h-px bg-white" />
                <div className="absolute left-1/3 top-0 bottom-0 w-px bg-white" />
                <div className="absolute left-2/3 top-0 bottom-0 w-px bg-white" />
              </div>

              {board.map((cell, i) => (
                <motion.button
                  key={i}
                  whileHover={{ scale: cell ? 1 : 1.05, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleClick(i)}
                  className={`relative w-24 h-24 sm:w-28 sm:h-28 rounded-3xl border-2 flex items-center justify-center text-5xl font-black transition-all duration-500 overflow-hidden
                    ${cell === 'X' ? 'border-cyan-500 bg-cyan-500/10 text-cyan-400 shadow-[0_0_30px_rgba(6,182,212,0.4)]' : 
                      cell === 'O' ? 'border-fuchsia-500 bg-fuchsia-500/10 text-fuchsia-400 shadow-[0_0_30px_rgba(217,70,239,0.4)]' : 
                      'border-white/5 hover:border-white/20 bg-white/5'}`}
                >
                  <AnimatePresence mode="wait">
                    {cell && (
                      <motion.span
                        initial={{ scale: 0.5, opacity: 0, rotate: -45 }}
                        animate={{ scale: 1, opacity: 1, rotate: 0 }}
                        className="relative z-10"
                      >
                        {cell}
                      </motion.span>
                    )}
                  </AnimatePresence>
                  
                  {/* Cell Background Glow */}
                  {cell && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 0.2 }}
                      className={`absolute inset-0 ${cell === 'X' ? 'bg-cyan-400' : 'bg-fuchsia-400'} blur-2xl`}
                    />
                  )}
                </motion.button>
              ))}
            </div>

            {/* AI Commentary Bar */}
            <div className="mt-10 bg-black/40 p-6 rounded-[2rem] border border-white/5 relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-r from-fuchsia-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="flex items-center gap-4 mb-3">
                <div className="w-8 h-8 rounded-lg bg-fuchsia-500/10 flex items-center justify-center border border-fuchsia-500/20">
                  <Brain className="w-4 h-4 text-fuchsia-400" />
                </div>
                <div className="flex flex-col">
                  <span className="text-[8px] font-black text-fuchsia-400/60 uppercase tracking-[0.3em]">Nexus_Mind // Analysis</span>
                  <div className="flex gap-1">
                    {[...Array(3)].map((_, i) => (
                      <motion.div 
                        key={i}
                        animate={{ opacity: [0.2, 1, 0.2] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                        className="w-1 h-1 rounded-full bg-fuchsia-400" 
                      />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-sm text-white/80 italic font-serif leading-relaxed relative z-10">
                "{loading ? "Processing multidimensional move sets..." : aiCommentary}"
              </p>
            </div>
          </div>

          {/* Quick Stats Footer */}
          <div className="flex gap-12 text-center">
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Difficulty</span>
              <span className="text-xs font-black text-cyan-400 uppercase italic">{difficulty}</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Protocol</span>
              <span className="text-xs font-black text-white/60 uppercase italic">NEON_STRIKE_V4</span>
            </div>
            <div className="flex flex-col">
              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Latency</span>
              <span className="text-xs font-black text-emerald-400 uppercase italic">12MS</span>
            </div>
          </div>
        </div>

        {/* Right HUD: System Diagnostics */}
        <HUDPanel title="System_Diagnostics" icon={Cpu} side="right">
          <div className="space-y-6">
            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-3 h-3 text-fuchsia-400" />
                  <span className="text-[8px] font-black text-white/40 uppercase">Neural_Load</span>
                </div>
                <span className="text-[10px] font-mono text-fuchsia-400">42%</span>
              </div>
              <div className="flex gap-1 h-4 items-end">
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ height: [4, 16, 8, 12, 4] }}
                    transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
                    className="flex-1 bg-fuchsia-500/30 rounded-full"
                  />
                ))}
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Terminal className="w-3 h-3 text-cyan-400" />
                <span className="text-[8px] font-black text-white/40 uppercase">Live_Tactical_Feed</span>
              </div>
              <div className="space-y-2 font-mono text-[9px] text-white/30">
                <div className="flex justify-between">
                  <span>SCANNING_GRID...</span>
                  <span className="text-emerald-500">OK</span>
                </div>
                <div className="flex justify-between">
                  <span>AI_HEURISTICS...</span>
                  <span className="text-emerald-500">READY</span>
                </div>
                <div className="flex justify-between">
                  <span>PATTERN_RECOGNITION...</span>
                  <span className="text-cyan-500">ACTIVE</span>
                </div>
                <motion.div 
                  animate={{ opacity: [0.2, 1, 0.2] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="text-fuchsia-500"
                >
                  {">"} WAITING_FOR_INPUT_
                </motion.div>
              </div>
            </div>

            <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Security</span>
              </div>
              <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-[0_0_10px_#10b981]" />
            </div>
          </div>
        </HUDPanel>

      </div>

      {/* Game Over Overlay */}
      <AnimatePresence>
        {isGameOver && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/95 backdrop-blur-2xl z-[110] p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              className="max-w-xl w-full space-y-10 text-center"
            >
              <div className={`w-32 h-32 rounded-[2.5rem] mx-auto flex items-center justify-center border-4 ${
                winStatus === 'WIN' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 shadow-[0_0_50px_rgba(16,185,129,0.2)]' : 
                winStatus === 'LOSE' ? 'bg-red-500/10 border-red-500/30 text-red-400 shadow-[0_0_50px_rgba(239,68,68,0.2)]' : 
                'bg-amber-500/10 border-amber-500/30 text-amber-400 shadow-[0_0_50px_rgba(245,158,11,0.2)]'
              }`}>
                {winStatus === 'WIN' ? <Trophy className="w-16 h-16" /> : 
                 winStatus === 'LOSE' ? <XCircle className="w-16 h-16" /> : 
                 <Zap className="w-16 h-16" />}
              </div>

              <div className="space-y-4">
                <h3 className="text-6xl font-black text-white uppercase italic tracking-tighter">
                  {winStatus === 'WIN' ? "Victory Achieved" : winStatus === 'LOSE' ? "System Defeat" : "Tactical Draw"}
                </h3>
                <div className="flex justify-center gap-4">
                  <div className="px-4 py-1 bg-white/5 rounded-full border border-white/10">
                    <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Difficulty: {difficulty}</span>
                  </div>
                  <div className="px-4 py-1 bg-white/5 rounded-full border border-white/10">
                    <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Protocol: NEON_STRIKE</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-[2.5rem] p-8 border border-white/10 space-y-6 text-left relative overflow-hidden">
                <div className="flex items-center gap-3 text-cyan-400 relative z-10">
                  <MessageSquare className="w-5 h-5" />
                  <span className="text-xs font-black uppercase tracking-[0.2em]">Post-Match Tactical Analysis</span>
                </div>
                
                {isGeneratingFeedback ? (
                  <div className="space-y-3 py-6 relative z-10">
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ x: ['-100%', '100%'] }}
                        transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                        className="h-full w-1/2 bg-cyan-500"
                      />
                    </div>
                    <p className="text-[10px] text-white/20 uppercase font-black tracking-widest animate-pulse">Analyzing neural patterns...</p>
                  </div>
                ) : (
                  <p className="text-lg text-white/80 leading-relaxed italic font-serif relative z-10">
                    "{aiFeedback}"
                  </p>
                )}
                <div className="absolute top-0 right-0 p-4 opacity-5">
                  <Cpu className="w-32 h-32" />
                </div>
              </div>

              <button 
                onClick={reset} 
                className="w-full py-6 bg-white text-black font-black rounded-3xl hover:bg-cyan-400 transition-all uppercase tracking-[0.4em] text-sm shadow-2xl active:scale-95"
              >
                Re-Initialize Arena
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
