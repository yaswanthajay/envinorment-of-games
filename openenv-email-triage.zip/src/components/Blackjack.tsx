import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Spade, Heart, Diamond, Club, Play, RotateCcw, Coins, User, Brain, Zap, Shield, Trophy, AlertCircle } from 'lucide-react';

type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';
type Card = { suit: Suit; value: number; label: string };

const SUITS: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
const VALUES = [
  { label: 'A', value: 11 },
  { label: '2', value: 2 },
  { label: '3', value: 3 },
  { label: '4', value: 4 },
  { label: '5', value: 5 },
  { label: '6', value: 6 },
  { label: '7', value: 7 },
  { label: '8', value: 8 },
  { label: '9', value: 9 },
  { label: '10', value: 10 },
  { label: 'J', value: 10 },
  { label: 'Q', value: 10 },
  { label: 'K', value: 10 },
];

export default function Blackjack() {
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [gameState, setGameState] = useState<'IDLE' | 'PLAYING' | 'DEALER_TURN' | 'OVER'>('IDLE');
  const [message, setMessage] = useState('Place your bet to start.');
  const [credits, setCredits] = useState(1000);

  const createDeck = () => {
    const newDeck: Card[] = [];
    SUITS.forEach(suit => {
      VALUES.forEach(val => {
        newDeck.push({ suit, ...val });
      });
    });
    return newDeck.sort(() => Math.random() - 0.5);
  };

  const calculateScore = (hand: Card[]) => {
    let score = hand.reduce((acc, card) => acc + card.value, 0);
    let aces = hand.filter(card => card.label === 'A').length;
    while (score > 21 && aces > 0) {
      score -= 10;
      aces -= 1;
    }
    return score;
  };

  const startNewGame = () => {
    const newDeck = createDeck();
    const pHand = [newDeck.pop()!, newDeck.pop()!];
    const dHand = [newDeck.pop()!, newDeck.pop()!];
    setDeck(newDeck);
    setPlayerHand(pHand);
    setDealerHand(dHand);
    setGameState('PLAYING');
    setMessage('Hit or Stand?');
    setCredits(c => c - 100);
  };

  const hit = () => {
    const newDeck = [...deck];
    const card = newDeck.pop()!;
    const newHand = [...playerHand, card];
    setPlayerHand(newHand);
    setDeck(newDeck);
    if (calculateScore(newHand) > 21) {
      setGameState('OVER');
      setMessage('Bust! Dealer wins.');
    }
  };

  const stand = () => {
    setGameState('DEALER_TURN');
    let currentDealerHand = [...dealerHand];
    let currentDeck = [...deck];
    
    const playDealer = () => {
      const score = calculateScore(currentDealerHand);
      if (score < 17) {
        const card = currentDeck.pop()!;
        currentDealerHand.push(card);
        setDealerHand([...currentDealerHand]);
        setDeck([...currentDeck]);
        setTimeout(playDealer, 600);
      } else {
        determineWinner(currentDealerHand);
      }
    };
    
    playDealer();
  };

  const determineWinner = (finalDealerHand: Card[]) => {
    const pScore = calculateScore(playerHand);
    const dScore = calculateScore(finalDealerHand);
    setGameState('OVER');
    if (dScore > 21 || pScore > dScore) {
      setMessage('You win!');
      setCredits(c => c + 200);
    } else if (dScore > pScore) {
      setMessage('Dealer wins.');
    } else {
      setMessage('Push (Draw).');
      setCredits(c => c + 100);
    }
  };

  const CardView = ({ card, hidden = false }: { card: Card; hidden?: boolean }) => (
    <motion.div
      initial={{ scale: 0, rotate: -20 }}
      animate={{ scale: 1, rotate: 0 }}
      className={`w-24 h-36 lg:w-32 lg:h-48 rounded-2xl border-2 flex flex-col p-4 justify-between shadow-2xl ${
        hidden 
          ? "bg-gradient-to-br from-cyan-600 to-blue-800 border-cyan-400/50" 
          : "bg-white/10 border-white/20 backdrop-blur-xl"
      }`}
    >
      {!hidden ? (
        <>
          <div className="flex flex-col items-start leading-none">
            <span className={`text-2xl font-black ${card.suit === 'hearts' || card.suit === 'diamonds' ? 'text-red-500' : 'text-white'}`}>
              {card.label}
            </span>
            {card.suit === 'spades' && <Spade size={16} className="text-white" />}
            {card.suit === 'hearts' && <Heart size={16} className="text-red-500" />}
            {card.suit === 'diamonds' && <Diamond size={16} className="text-red-500" />}
            {card.suit === 'clubs' && <Club size={16} className="text-white" />}
          </div>
          <div className="flex justify-center opacity-20">
            {card.suit === 'spades' && <Spade size={48} className="text-white" />}
            {card.suit === 'hearts' && <Heart size={48} className="text-red-500" />}
            {card.suit === 'diamonds' && <Diamond size={48} className="text-red-500" />}
            {card.suit === 'clubs' && <Club size={48} className="text-white" />}
          </div>
          <div className="flex flex-col items-end leading-none rotate-180">
            <span className={`text-2xl font-black ${card.suit === 'hearts' || card.suit === 'diamonds' ? 'text-red-500' : 'text-white'}`}>
              {card.label}
            </span>
            {card.suit === 'spades' && <Spade size={16} className="text-white" />}
            {card.suit === 'hearts' && <Heart size={16} className="text-red-500" />}
            {card.suit === 'diamonds' && <Diamond size={16} className="text-red-500" />}
            {card.suit === 'clubs' && <Club size={16} className="text-white" />}
          </div>
        </>
      ) : (
        <div className="flex items-center justify-center h-full">
          <div className="w-12 h-12 rounded-full border-2 border-white/10 flex items-center justify-center">
            <div className="w-6 h-6 rounded-full bg-white/5" />
          </div>
        </div>
      )}
    </motion.div>
  );

  return (
    <div className="flex flex-col h-full gap-12 p-8 items-center justify-center relative overflow-hidden bg-[#050505]">
      {/* High-Tech Table Environment */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" 
        style={{ 
          backgroundImage: 'radial-gradient(circle at 50% 50%, #06b6d4 0%, transparent 70%)',
          backgroundSize: '100% 100%'
        }} 
      />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] border-[40px] border-white/5 rounded-full blur-3xl pointer-events-none" />
      
      {/* Decorative Table Lines */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] border-2 border-cyan-500/10 rounded-[200px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] border border-cyan-500/5 rounded-[150px] pointer-events-none" />

      {/* Dealer Area */}
      <div className="flex flex-col items-center gap-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 bg-black/60 backdrop-blur-xl px-8 py-3 rounded-2xl border border-white/10 shadow-2xl"
        >
          <div className="w-10 h-10 bg-cyan-500/20 rounded-xl flex items-center justify-center border border-cyan-500/30">
            <Brain className="text-cyan-400" size={20} />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 block">Neural Dealer</span>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-white uppercase italic tracking-tighter">Node_Alpha</span>
              {gameState !== 'IDLE' && (
                <span className="px-2 py-0.5 bg-cyan-500 text-black text-[10px] font-black rounded-md ml-2">
                  {gameState === 'PLAYING' ? '?' : calculateScore(dealerHand)}
                </span>
              )}
            </div>
          </div>
        </motion.div>
        
        <div className="flex gap-6">
          <AnimatePresence>
            {dealerHand.map((card, i) => (
              <CardView key={i} card={card} hidden={i === 1 && gameState === 'PLAYING'} />
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Center Info & Pot */}
      <div className="flex flex-col items-center gap-6 text-center relative z-10">
        <AnimatePresence mode="wait">
          <motion.div 
            key={message}
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.2, y: -10 }}
            className="text-5xl lg:text-7xl font-black uppercase tracking-tighter italic text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.4)]"
          >
            {message}
          </motion.div>
        </AnimatePresence>
        
        <div className="flex items-center gap-12 bg-white/5 backdrop-blur-xl px-10 py-4 rounded-3xl border border-white/10">
          <div className="flex flex-col items-center">
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.4em] mb-1">Your Credits</span>
            <div className="flex items-center gap-2">
              <Coins className="text-amber-400" size={16} />
              <span className="text-3xl font-black tabular-nums text-white">${credits.toLocaleString()}</span>
            </div>
          </div>
          <div className="w-[1px] h-10 bg-white/10" />
          <div className="flex flex-col items-center">
            <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.4em] mb-1">Current Bet</span>
            <div className="flex items-center gap-2">
              <Zap className="text-cyan-400" size={16} />
              <span className="text-3xl font-black tabular-nums text-cyan-400">$100</span>
            </div>
          </div>
        </div>
      </div>

      {/* Player Area */}
      <div className="flex flex-col items-center gap-8 relative z-10">
        <div className="flex gap-6">
          <AnimatePresence>
            {playerHand.map((card, i) => (
              <CardView key={i} card={card} />
            ))}
          </AnimatePresence>
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 bg-black/60 backdrop-blur-xl px-8 py-3 rounded-2xl border border-white/10 shadow-2xl"
        >
          <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center border border-emerald-500/30">
            <User className="text-emerald-400" size={20} />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 block">Player Node</span>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-white uppercase italic tracking-tighter">You</span>
              {gameState !== 'IDLE' && (
                <span className="px-2 py-0.5 bg-emerald-500 text-black text-[10px] font-black rounded-md ml-2">
                  {calculateScore(playerHand)}
                </span>
              )}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Controls */}
      <div className="flex gap-6 w-full max-w-xl relative z-10">
        {gameState === 'IDLE' || gameState === 'OVER' ? (
          <button 
            onClick={startNewGame}
            className="w-full py-7 bg-cyan-500 text-black font-black rounded-[2rem] hover:bg-white transition-all uppercase tracking-[0.2em] text-sm shadow-[0_0_50px_rgba(6,182,212,0.4)] flex items-center justify-center gap-4 active:scale-95"
          >
            <Play size={20} fill="currentColor" /> INITIALIZE_NEW_HAND
          </button>
        ) : (
          <>
            <button 
              onClick={hit}
              disabled={gameState !== 'PLAYING'}
              className="flex-1 py-7 bg-white/5 text-white font-black rounded-[2rem] hover:bg-white/10 transition-all uppercase tracking-[0.2em] text-sm border border-white/10 disabled:opacity-50 active:scale-95"
            >
              HIT_ME
            </button>
            <button 
              onClick={stand}
              disabled={gameState !== 'PLAYING'}
              className="flex-1 py-7 bg-emerald-500 text-black font-black rounded-[2rem] hover:bg-white transition-all uppercase tracking-[0.2em] text-sm shadow-[0_0_50px_rgba(16,185,129,0.4)] disabled:opacity-50 active:scale-95"
            >
              STAND_STILL
            </button>
          </>
        )}
      </div>
    </div>
  );
}
