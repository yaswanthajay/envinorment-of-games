import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bomb, Gem, Coins, AlertTriangle, History, Zap, Shield, Trophy } from 'lucide-react';

export default function MinesGame() {
  const [grid, setGrid] = useState<(null | 'GEM' | 'BOMB')[]>(Array(25).fill(null));
  const [minesCount, setMinesCount] = useState(3);
  const [revealed, setRevealed] = useState<number[]>([]);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isWon, setIsWon] = useState(false);
  const [bet, setBet] = useState(100);
  const [credits, setCredits] = useState(5000);
  const [multiplier, setMultiplier] = useState(1.00);
  const [isPlaying, setIsPlaying] = useState(false);
  const [cashedOut, setCashedOut] = useState(false);

  const initializeGame = () => {
    if (credits < bet) return;
    
    setCredits(prev => prev - bet);
    const newGrid = Array(25).fill('GEM');
    const bombIndices: number[] = [];
    while (bombIndices.length < minesCount) {
      const rand = Math.floor(Math.random() * 25);
      if (!bombIndices.includes(rand)) {
        bombIndices.push(rand);
        newGrid[rand] = 'BOMB';
      }
    }
    setGrid(newGrid);
    setRevealed([]);
    setIsGameOver(false);
    setIsWon(false);
    setIsPlaying(true);
    setCashedOut(false);
    setMultiplier(1.00);
  };

  const calculateMultiplier = (revealedCount: number) => {
    // Simple multiplier formula for mines: (25 / (25 - mines)) * (24 / (24 - mines)) ...
    let mult = 1.00;
    for (let i = 0; i < revealedCount; i++) {
      mult *= (25 - i) / (25 - minesCount - i);
    }
    return Number(mult.toFixed(2));
  };

  const revealTile = (index: number) => {
    if (!isPlaying || revealed.includes(index) || cashedOut) return;

    const newRevealed = [...revealed, index];
    setRevealed(newRevealed);

    if (grid[index] === 'BOMB') {
      setIsGameOver(true);
      setIsPlaying(false);
    } else {
      const newMult = calculateMultiplier(newRevealed.length);
      setMultiplier(newMult);
      
      if (newRevealed.length === 25 - minesCount) {
        setIsWon(true);
        cashOut(newMult);
      }
    }
  };

  const cashOut = (finalMult = multiplier) => {
    if (!isPlaying || cashedOut || isGameOver) return;
    
    const winAmount = Math.floor(bet * finalMult);
    setCredits(prev => prev + winAmount);
    setCashedOut(true);
    setIsPlaying(false);
  };

  return (
    <div className="flex flex-col h-full gap-8 p-8 relative overflow-hidden bg-[#050505]">
      {/* Immersive Background */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" 
        style={{ 
          backgroundImage: 'radial-gradient(circle at 50% 50%, #10b981 0%, transparent 70%)',
          backgroundSize: '100% 100%'
        }} 
      />
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 pointer-events-none" />

      <div className="flex justify-between items-center bg-black/40 p-6 rounded-3xl border border-white/10 backdrop-blur-xl relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl border border-emerald-500/30 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Gem className="text-emerald-400" />
          </div>
          <div>
            <h2 className="text-2xl font-black uppercase tracking-tighter italic">Nexus Mines</h2>
            <p className="text-[8px] font-mono text-white/30 uppercase tracking-[0.4em]">Node_Omega // Extraction_Protocol</p>
          </div>
        </div>

        <div className="flex gap-8">
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-1">Credits</span>
            <div className="flex items-center gap-2">
              <Coins className="text-amber-400" size={16} />
              <span className="text-2xl font-black tabular-nums">${credits.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-8 relative z-10">
        {/* Main Grid Area */}
        <div className="flex-1 bg-black/60 rounded-[3rem] border border-white/10 p-12 flex flex-col items-center justify-center relative overflow-hidden">
          {/* Grid Lines */}
          <div className="absolute inset-0 opacity-5 pointer-events-none" 
            style={{ 
              backgroundImage: 'linear-gradient(rgba(16, 185, 129, 0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(16, 185, 129, 0.2) 1px, transparent 1px)',
              backgroundSize: '40px 40px'
            }} 
          />

          <div className="grid grid-cols-5 gap-4">
            {grid.map((tile, i) => (
              <motion.button
                key={i}
                whileHover={isPlaying && !revealed.includes(i) ? { scale: 1.05, y: -5 } : {}}
                whileTap={isPlaying && !revealed.includes(i) ? { scale: 0.95 } : {}}
                onClick={() => revealTile(i)}
                className={`w-16 h-16 lg:w-24 lg:h-24 rounded-2xl border-2 transition-all duration-500 flex items-center justify-center relative overflow-hidden ${
                  revealed.includes(i) || isGameOver || cashedOut
                    ? tile === 'BOMB' 
                      ? 'bg-red-500/20 border-red-500/50 shadow-[0_0_30px_rgba(239,68,68,0.3)]' 
                      : 'bg-emerald-500/20 border-emerald-500/50 shadow-[0_0_30px_rgba(16,185,129,0.3)]'
                    : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                }`}
              >
                <AnimatePresence mode="wait">
                  {(revealed.includes(i) || isGameOver || cashedOut) ? (
                    <motion.div
                      key={tile}
                      initial={{ scale: 0, rotate: -45 }}
                      animate={{ scale: 1, rotate: 0 }}
                      className="flex items-center justify-center"
                    >
                      {tile === 'BOMB' ? (
                        <Bomb className="text-red-500 w-8 h-8 lg:w-12 lg:h-12" />
                      ) : (
                        <Gem className="text-emerald-400 w-8 h-8 lg:w-12 lg:h-12" />
                      )}
                    </motion.div>
                  ) : (
                    <div className="w-4 h-4 rounded-full border-2 border-white/5" />
                  )}
                </AnimatePresence>
              </motion.button>
            ))}
          </div>

          {/* Overlays */}
          <AnimatePresence>
            {isGameOver && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 bg-red-500/10 backdrop-blur-md flex flex-col items-center justify-center z-20"
              >
                <AlertTriangle className="text-red-500 w-24 h-24 mb-4 animate-bounce" />
                <h3 className="text-6xl font-black text-red-500 uppercase italic tracking-tighter">BOOM!</h3>
                <p className="text-2xl font-black text-white/60 mt-2">You hit a mine.</p>
                <button 
                  onClick={initializeGame}
                  className="mt-8 px-10 py-4 bg-red-500 text-white font-black rounded-2xl hover:bg-white hover:text-red-500 transition-all uppercase tracking-widest text-sm"
                >
                  TRY_AGAIN
                </button>
              </motion.div>
            )}
            {cashedOut && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 bg-emerald-500/10 backdrop-blur-md flex flex-col items-center justify-center z-20"
              >
                <Trophy className="text-emerald-400 w-24 h-24 mb-4 animate-bounce" />
                <h3 className="text-6xl font-black text-emerald-400 uppercase italic tracking-tighter">SECURED!</h3>
                <p className="text-2xl font-black text-white/60 mt-2">Win: ${(bet * multiplier).toFixed(0)}</p>
                <button 
                  onClick={initializeGame}
                  className="mt-8 px-10 py-4 bg-emerald-500 text-black font-black rounded-2xl hover:bg-white transition-all uppercase tracking-widest text-sm"
                >
                  PLAY_NEXT_ROUND
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Controls Panel */}
        <div className="w-full lg:w-80 flex flex-col gap-6">
          <div className="bg-black/40 p-8 rounded-[2rem] border border-white/10 backdrop-blur-xl">
            <div className="flex items-center gap-3 mb-6">
              <Zap className="text-cyan-400" size={16} />
              <span className="text-[10px] font-black uppercase tracking-widest">Extraction Terminal</span>
            </div>

            <div className="flex flex-col gap-6 mb-8">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">Bet Amount</span>
                <div className="flex items-center gap-2 bg-black/40 p-4 rounded-2xl border border-white/10">
                  <Coins size={16} className="text-amber-400" />
                  <input 
                    type="number" 
                    value={bet}
                    onChange={(e) => setBet(Number(e.target.value))}
                    disabled={isPlaying}
                    className="bg-transparent border-none outline-none text-xl font-black w-full tabular-nums"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">Mines Count</span>
                <div className="flex items-center gap-2 bg-black/40 p-4 rounded-2xl border border-white/10">
                  <Bomb size={16} className="text-red-400" />
                  <select 
                    value={minesCount}
                    onChange={(e) => setMinesCount(Number(e.target.value))}
                    disabled={isPlaying}
                    className="bg-transparent border-none outline-none text-xl font-black w-full tabular-nums appearance-none cursor-pointer"
                  >
                    {[1, 3, 5, 10, 15, 20, 24].map(n => (
                      <option key={n} value={n} className="bg-[#010103]">{n} Mines</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {!isPlaying ? (
              <button 
                onClick={initializeGame}
                disabled={credits < bet}
                className="w-full py-6 bg-cyan-500 text-black font-black rounded-[2rem] hover:bg-white transition-all uppercase tracking-widest text-sm shadow-[0_0_40px_rgba(6,182,212,0.4)] active:scale-95 disabled:opacity-50"
              >
                START_EXTRACTION
              </button>
            ) : (
              <button 
                onClick={() => cashOut()}
                disabled={revealed.length === 0}
                className="w-full py-6 bg-emerald-500 text-black font-black rounded-[2rem] hover:bg-white transition-all uppercase tracking-widest text-sm shadow-[0_0_40px_rgba(16,185,129,0.4)] active:scale-95 disabled:opacity-50"
              >
                CASH_OUT @ {multiplier}x
              </button>
            )}
          </div>

          <div className="flex-1 bg-black/40 p-8 rounded-[2rem] border border-white/10 backdrop-blur-xl flex flex-col items-center justify-center text-center">
            <div className="text-6xl font-black text-white tabular-nums mb-2">{multiplier}x</div>
            <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em] italic">Current_Extraction_Yield</p>
            <div className="mt-6 flex items-center gap-2 px-4 py-2 bg-emerald-500/10 rounded-full border border-emerald-500/20">
              <Shield className="text-emerald-400" size={12} />
              <span className="text-[8px] font-black text-emerald-400 uppercase tracking-widest">Secure_Protocol_Active</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
