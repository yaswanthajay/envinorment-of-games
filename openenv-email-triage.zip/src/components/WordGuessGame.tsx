import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Gamepad2, 
  RefreshCw, 
  Trophy, 
  Keyboard, 
  Brain, 
  Zap, 
  Activity, 
  Shield, 
  Terminal,
  Volume2,
  Star,
  Timer,
  Book,
  Settings,
  Bot
} from 'lucide-react';
import confetti from 'canvas-confetti';

type Screen = 'HOME' | 'GAME' | 'RESULT';

interface Observation {
  masked_word: string;
  guessed_letters: string[];
  attempts_remaining: number;
  message: string;
  reward: number;
  done: boolean;
  clue?: string;
}

const HangmanDrawing: React.FC<{ attempts: number }> = ({ attempts }) => {
  const parts = [
    <circle key="head" cx="150" cy="80" r="20" stroke="white" strokeWidth="4" fill="none" />, // Head
    <line key="body" x1="150" y1="100" x2="150" y2="160" stroke="white" strokeWidth="4" />, // Body
    <line key="arm-l" x1="150" y1="120" x2="120" y2="140" stroke="white" strokeWidth="4" />, // Left Arm
    <line key="arm-r" x1="150" y1="120" x2="180" y2="140" stroke="white" strokeWidth="4" />, // Right Arm
    <line key="leg-l" x1="150" y1="160" x2="130" y2="200" stroke="white" strokeWidth="4" />, // Left Leg
    <line key="leg-r" x1="150" y1="160" x2="170" y2="200" stroke="white" strokeWidth="4" />, // Right Leg
  ];

  const errors = 6 - attempts;

  return (
    <div className="relative w-full aspect-square max-w-[300px] glass-panel rounded-2xl p-4 border-2 border-fuchsia-500/50 shadow-[0_0_20px_rgba(217,70,239,0.2)]">
      <svg viewBox="0 0 300 300" className="w-full h-full">
        {/* Gallows */}
        <line x1="50" y1="250" x2="250" y2="250" stroke="#fbbf24" strokeWidth="6" strokeLinecap="round" />
        <line x1="100" y1="250" x2="100" y2="50" stroke="#fbbf24" strokeWidth="6" strokeLinecap="round" />
        <line x1="100" y1="50" x2="150" y2="50" stroke="#fbbf24" strokeWidth="6" strokeLinecap="round" />
        <line x1="150" y1="50" x2="150" y2="60" stroke="#fbbf24" strokeWidth="6" strokeLinecap="round" />
        
        {/* Man */}
        {parts.slice(0, errors)}
      </svg>
    </div>
  );
};

const WordGuessGame: React.FC<{ difficulty?: string }> = ({ difficulty = "MEDIUM" }) => {
  const [screen, setScreen] = useState<Screen>('HOME');
  const [obs, setObs] = useState<Observation | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [timer, setTimer] = useState(0);

  useEffect(() => {
    let interval: any;
    if (screen === 'GAME' && !obs?.done) {
      interval = setInterval(() => setTimer(t => t + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [screen, obs?.done]);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const resetGame = async () => {
    setLoading(true);
    setError(null);
    setTimer(0);
    try {
      const response = await fetch(`/api/reset?difficulty=${difficulty}`);
      const data = await response.json();
      setObs(data);
      setScreen('GAME');
    } catch (err) {
      setError("Failed to initialize Nexus Core.");
    } finally {
      setLoading(false);
    }
  };

  const makeGuess = async (letter: string) => {
    if (!obs || obs.done || loading) return;
    
    setLoading(true);
    try {
      const response = await fetch('/api/step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guess: letter })
      });
      const data: Observation = await response.json();
      setObs(data);
      
      if (data.done) {
        setTimeout(() => {
          setScreen('RESULT');
          if (data.reward === 1) {
            confetti({
              particleCount: 150,
              spread: 70,
              origin: { y: 0.6 },
              colors: ['#06b6d4', '#d946ef', '#fbbf24']
            });
          }
        }, 1000);
      }
    } catch (err) {
      setError("Neural link interrupted.");
    } finally {
      setLoading(false);
    }
  };

  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");

  const renderHome = () => (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full max-w-[380px] lg:max-w-[500px] aspect-[9/19] lg:aspect-auto lg:min-h-[700px] glass-panel rounded-[3rem] p-8 lg:p-12 flex flex-col items-center justify-between overflow-hidden border border-white/20 shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
    >
      {/* Background Decorative Elements */}
      <div className="absolute top-[-10%] left-[-20%] w-[80%] h-[40%] bg-purple-500/20 blur-[80px] rounded-full" />
      <div className="absolute bottom-[10%] right-[-20%] w-[80%] h-[40%] bg-blue-500/20 blur-[80px] rounded-full" />
      
      {/* Top Status Bar (Mock) - Hidden on large screens */}
      <div className="w-full flex justify-between items-center px-4 pt-2 opacity-60 lg:hidden">
        <span className="text-[10px] font-bold">9:41</span>
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full border border-white/40" />
          <div className="w-3 h-3 rounded-full border border-white/40" />
          <div className="w-3 h-3 rounded-full bg-white/40" />
        </div>
      </div>

      <div className="flex flex-col items-center text-center space-y-6 lg:space-y-10 z-10 mt-12 lg:mt-0">
        <h1 className="text-4xl lg:text-6xl font-black tracking-tight text-white leading-tight">
          Make It <br /> Awesome
        </h1>

        {/* Robot Image inspired by Image 3 */}
        <motion.div 
          animate={{ 
            y: [0, -15, 0],
            rotate: [0, 2, -2, 0]
          }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="relative py-8 lg:py-12"
        >
          <div className="absolute inset-0 bg-white/5 blur-3xl rounded-full scale-150" />
          <div className="w-40 h-40 lg:w-56 lg:h-56 rounded-full bg-gradient-to-br from-white/10 to-white/5 border border-white/20 flex items-center justify-center relative z-10 shadow-inner">
            <Bot className="w-20 h-20 lg:w-32 lg:h-32 text-white" />
            {/* Eyes */}
            <div className="absolute top-[40%] left-[30%] w-2 h-2 lg:w-3 lg:h-3 bg-cyan-400 rounded-full animate-pulse" />
            <div className="absolute top-[40%] right-[30%] w-2 h-2 lg:w-3 lg:h-3 bg-cyan-400 rounded-full animate-pulse" />
          </div>
          
          {/* Decorative Rings */}
          <div className="absolute -inset-4 border border-white/5 rounded-full animate-[spin_10s_linear_infinite]" />
          <div className="absolute -inset-8 border border-white/5 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
        </motion.div>

        <div className="bg-white/10 backdrop-blur-md border border-white/10 px-4 py-1 lg:px-6 lg:py-2 rounded-full">
          <span className="text-[10px] lg:text-xs font-bold text-white/60 tracking-widest">V1.24</span>
        </div>
      </div>

      <div className="w-full space-y-8 lg:space-y-12 z-10 pb-8 lg:pb-0">
        <p className="text-white/40 text-[11px] lg:text-sm text-center font-medium leading-relaxed px-4">
          Nice to meet you! How can I help you? <br />
          Decryption sequence ready for initialization.
        </p>

        <motion.button 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={resetGame}
          className="w-full py-4 lg:py-6 bg-white text-black font-bold rounded-2xl lg:rounded-3xl shadow-xl hover:bg-white/90 transition-colors text-sm lg:text-lg tracking-tight"
        >
          Get started
        </motion.button>

        {/* Home Indicator - Hidden on large screens */}
        <div className="w-32 h-1 bg-white/20 mx-auto rounded-full lg:hidden" />
      </div>
    </motion.div>
  );

  const renderGame = () => {
    if (!obs) return null;

    return (
      <div className="w-full max-w-6xl mx-auto space-y-6 p-4">
        {/* Top Stats Bar inspired by Image 1 */}
        <div className="glass-panel border-2 border-emerald-500/50 rounded-xl p-3 flex items-center justify-between shadow-[0_0_15px_rgba(16,185,129,0.1)]">
          <div className="flex items-center gap-6">
            <Volume2 className="w-5 h-5 text-emerald-400 cursor-pointer" />
            <div className="flex items-center gap-2 bg-black/40 px-4 py-1.5 rounded-lg border border-white/10">
              <Book className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono uppercase tracking-widest text-white/80">dictionary</span>
            </div>
          </div>

          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4 text-yellow-400" />
              <span className="text-xs font-mono text-white/80">0</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-400" />
              <span className="text-xs font-mono text-white/80">100</span>
            </div>
            <div className="flex items-center gap-2">
              <Timer className="w-4 h-4 text-yellow-400" />
              <span className="text-xs font-mono text-white/80">{formatTime(timer)}</span>
            </div>
          </div>

          <Settings className="w-5 h-5 text-white/40 cursor-pointer hover:text-white transition-colors" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Game Logic */}
          <div className="lg:col-span-2 space-y-6">
            {/* Clue Box */}
            {obs.clue && (
              <div className="glass-panel border border-cyan-500/30 bg-cyan-500/5 rounded-xl p-4 mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Brain className="w-4 h-4 text-cyan-400" />
                  <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">Neural Clue</span>
                </div>
                <p className="text-xs text-white/80 italic leading-relaxed">
                  "{obs.clue}"
                </p>
              </div>
            )}

            {/* Question Box */}
            <div className="glass-panel border-2 border-fuchsia-500/50 rounded-2xl p-8 text-center relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-fuchsia-500 to-transparent opacity-50" />
              <h3 className="text-white/60 font-mono uppercase tracking-[0.2em] text-sm mb-6">Can you guess the hidden word?</h3>
              
              <div className="flex justify-center flex-wrap gap-3 mb-8">
                {obs.masked_word.split("").map((char, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0.8 }}
                    animate={{ scale: 1 }}
                    className={`w-12 h-16 flex items-center justify-center border-b-4 text-3xl font-black transition-all ${
                      char === "_" 
                        ? 'border-white/10 text-transparent' 
                        : 'border-cyan-500 text-cyan-400 text-glow-cyan'
                    }`}
                  >
                    {char !== "_" ? char : ""}
                  </motion.div>
                ))}
              </div>

              <button className="px-8 py-2 bg-cyan-500/10 border border-cyan-500/50 rounded-lg text-cyan-400 text-xs font-bold uppercase tracking-widest hover:bg-cyan-500/20 transition-all">
                CONTINUE
              </button>
            </div>

            {/* Keyboard Box */}
            <div className="glass-panel border-2 border-fuchsia-500/50 rounded-2xl p-6">
              <div className="grid grid-cols-7 md:grid-cols-9 lg:grid-cols-10 gap-2">
                {alphabet.map((letter) => {
                  const isGuessed = obs.guessed_letters.includes(letter);
                  const isCorrect = isGuessed && obs.masked_word.includes(letter);
                  
                  return (
                    <button
                      key={letter}
                      disabled={isGuessed || loading || obs.done}
                      onClick={() => makeGuess(letter)}
                      className={`h-10 rounded-lg font-mono text-sm font-bold transition-all border ${
                        isGuessed 
                          ? isCorrect 
                            ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400' 
                            : 'bg-red-500/10 border-red-500/20 text-red-500/40'
                          : 'bg-white/5 border-white/10 text-white/60 hover:border-cyan-500/50 hover:text-cyan-400 hover:bg-cyan-500/10'
                      }`}
                    >
                      {letter}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Drawing */}
          <div className="flex flex-col items-center justify-start">
            <HangmanDrawing attempts={obs.attempts_remaining} />
            
            <div className="mt-8 w-full glass-panel border border-white/10 rounded-xl p-4 text-center">
              <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest block mb-2">System Status</span>
              <p className="text-xs font-mono text-cyan-400 italic">
                {obs.message}
              </p>
            </div>
          </div>
        </div>

        {/* Footer info inspired by Image 1 */}
        <div className="flex justify-between items-center px-2 opacity-40">
          <button className="text-[10px] font-bold uppercase tracking-widest bg-fuchsia-500/20 border border-fuchsia-500/50 px-4 py-1 rounded">CONTACT US</button>
          <div className="flex gap-4">
            <div className="w-5 h-5 rounded-full border border-white/50" />
            <div className="w-5 h-5 rounded-full border border-white/50" />
            <div className="w-5 h-5 rounded-full border border-white/50" />
          </div>
        </div>
      </div>
    );
  };

  const renderResult = () => {
    if (!obs) return null;
    const win = obs.reward === 1;

    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex flex-col items-center justify-center min-h-[600px] w-full max-w-lg mx-auto p-8"
      >
        <div className={`w-full p-12 rounded-3xl border-2 bg-black/60 backdrop-blur-2xl shadow-2xl ${
          win ? 'border-emerald-500/50 shadow-emerald-500/20' : 'border-red-500/50 shadow-red-500/20'
        }`}>
          <div className="text-center space-y-6">
            <h2 className={`text-6xl font-black tracking-tighter uppercase italic ${
              win ? 'text-emerald-400 text-glow-emerald' : 'text-red-500 text-glow-red'
            }`}>
              {win ? 'SUCCESS' : 'FAILED'}
            </h2>
            
            <p className="text-white/60 font-mono text-sm leading-relaxed">
              {obs.message}
            </p>

            <div className="py-8">
               <span className="text-[10px] font-mono text-white/30 uppercase tracking-[0.4em] block mb-4">Sequence Revealed</span>
               <div className="text-3xl font-black tracking-widest text-white">{obs.masked_word.replace(/_/g, '?')}</div>
            </div>

            <div className="flex flex-col gap-4">
              <button 
                onClick={resetGame}
                className="neon-pill px-8 py-4 rounded-full text-white font-bold tracking-widest uppercase"
              >
                Try Again
              </button>
              
              <button 
                onClick={() => setScreen('HOME')}
                className="text-white/40 font-bold tracking-widest uppercase text-xs hover:text-white transition-colors"
              >
                Exit Terminal
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="min-h-[700px] flex items-center justify-center relative overflow-hidden brick-wall">
      {/* Background Glows inspired by Image 3 */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden">
        <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] bg-fuchsia-500/10 blur-[120px] rounded-full" />
        <div className="absolute -bottom-[20%] -right-[10%] w-[60%] h-[60%] bg-cyan-500/10 blur-[120px] rounded-full" />
      </div>

      <AnimatePresence mode="wait">
        {screen === 'HOME' && renderHome()}
        {screen === 'GAME' && renderGame()}
        {screen === 'RESULT' && renderResult()}
      </AnimatePresence>

      {error && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-red-500/20 border border-red-500/50 rounded-full text-red-500 text-xs font-mono uppercase tracking-widest animate-bounce z-50">
          {error}
        </div>
      )}
    </div>
  );
};

export default WordGuessGame;
