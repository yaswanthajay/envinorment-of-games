import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldAlert, 
  Users, 
  Heart, 
  Home, 
  Truck, 
  Timer, 
  AlertTriangle, 
  Play, 
  Pause, 
  RefreshCw, 
  Activity,
  Map as MapIcon,
  Zap,
  Droplets,
  Stethoscope,
  Tent,
  Cpu,
  User,
  Info,
  Lightbulb,
  Trophy,
  XCircle,
  MessageSquare,
  Building2,
  Factory,
  ShoppingBag,
  Trees,
  Waves,
  Plane,
  Microscope,
  Construction,
  TrendingUp,
  BarChart3,
  Cloud,
  Sun,
  Wind,
  Mountain,
  ChevronRight,
  ArrowUpRight,
  Settings,
  Bell,
  Search,
  LayoutGrid,
  PieChart
} from 'lucide-react';
import { sounds } from '../lib/sounds';
import { GoogleGenAI } from "@google/genai";
import confetti from 'canvas-confetti';

interface District {
  id: number;
  name: string;
  type: 'VILLAGE' | 'FOREST_TOWN' | 'COASTAL_CITY' | 'MOUNTAIN_RETREAT' | 'FARM_LAND' | 'RIVER_SIDE' | 'VALLEY_HUB' | 'GARDEN_DISTRICT' | 'SKY_REACH';
  crisisLevel: number; // 0-100
  population: number;
  growth: number; // 0-100
  level: number;
  needs: {
    food: number;
    medical: number;
    safety: number;
    power: number;
  };
  status: 'STABLE' | 'WARNING' | 'CRITICAL' | 'EVACUATED';
  image: string;
}

const DISTRICT_TYPES = [
  { type: 'VILLAGE', icon: Home, color: 'text-green-600', bg: 'bg-green-500/20', img: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=400&q=80' },
  { type: 'FOREST_TOWN', icon: Trees, color: 'text-emerald-600', bg: 'bg-emerald-500/20', img: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&w=400&q=80' },
  { type: 'COASTAL_CITY', icon: Waves, color: 'text-blue-600', bg: 'bg-blue-500/20', img: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400&q=80' },
  { type: 'MOUNTAIN_RETREAT', icon: Mountain, color: 'text-slate-600', bg: 'bg-slate-500/20', img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=400&q=80' },
  { type: 'FARM_LAND', icon: Sun, color: 'text-amber-600', bg: 'bg-amber-500/20', img: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=400&q=80' },
  { type: 'RIVER_SIDE', icon: Droplets, color: 'text-cyan-600', bg: 'bg-cyan-500/20', img: 'https://images.unsplash.com/photo-1437333306198-097bbd9ccc15?auto=format&fit=crop&w=400&q=80' },
  { type: 'VALLEY_HUB', icon: Wind, color: 'text-teal-600', bg: 'bg-teal-500/20', img: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=400&q=80' },
  { type: 'GARDEN_DISTRICT', icon: ShoppingBag, color: 'text-rose-600', bg: 'bg-rose-500/20', img: 'https://images.unsplash.com/photo-1466721591366-2d5fba72006d?auto=format&fit=crop&w=400&q=80' },
  { type: 'SKY_REACH', icon: Cloud, color: 'text-sky-600', bg: 'bg-sky-500/20', img: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?auto=format&fit=crop&w=400&q=80' },
];

export default function DisasterResponse({ difficulty = "MEDIUM" }: { difficulty?: string }) {
  const [gameLevel, setGameLevel] = useState(1);
  const [districts, setDistricts] = useState<District[]>([]);
  const [selectedDistrictId, setSelectedDistrictId] = useState<number | null>(null);
  const [resources, setResources] = useState({
    food: 100,
    medical: 100,
    safety: 100,
    power: 100
  });

  const [prosperity, setProsperity] = useState(85);
  const [time, setTime] = useState(180);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [winStatus, setWinStatus] = useState<'WIN' | 'LOSE' | null>(null);
  const [aiFeedback, setAiFeedback] = useState<string>("");
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [isAiGuidance, setIsAiGuidance] = useState(false);
  const [showInstructions, setShowInstructions] = useState(true);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const difficultyMap: Record<string, number> = {
    'EASY': 0.3,
    'MEDIUM': 0.6,
    'HARD': 1.0,
    'INSANE': 1.5
  };
  const diffMultiplier = (difficultyMap[difficulty.toUpperCase()] || 0.6) * (1 + (gameLevel - 1) * 0.2);

  // Initialize districts based on level
  useEffect(() => {
    const numDistricts = Math.min(9, 3 + (gameLevel - 1) * 2);
    const initialDistricts = DISTRICT_TYPES.slice(0, numDistricts).map((dt, i) => ({
      id: i,
      name: `${dt.type.charAt(0) + dt.type.slice(1).toLowerCase().replace('_', ' ')}`,
      type: dt.type as District['type'],
      crisisLevel: 5 + Math.random() * 10,
      population: 2000 + Math.floor(Math.random() * 3000),
      growth: 60 + Math.random() * 15,
      level: 1,
      needs: { food: 0, medical: 0, safety: 0, power: 0 },
      status: 'STABLE' as District['status'],
      image: dt.img
    }));
    setDistricts(initialDistricts);
  }, [gameLevel]);

  const updateTown = useCallback(() => {
    setDistricts(prev => prev.map(district => {
      let newCrisis = district.crisisLevel + (Math.random() * 1.0 * diffMultiplier);
      
      const newNeeds = {
        food: Math.min(100, district.needs.food + (newCrisis / 40)),
        medical: Math.min(100, district.needs.medical + (newCrisis / 50)),
        safety: Math.min(100, district.needs.safety + (newCrisis / 60)),
        power: Math.min(100, district.needs.power + (newCrisis / 70))
      };

      const avgNeeds = (newNeeds.food + newNeeds.medical + newNeeds.safety + newNeeds.power) / 4;
      let newGrowth = district.growth + (avgNeeds < 10 ? 0.7 : -0.3 * (avgNeeds / 10));
      newGrowth = Math.max(0, Math.min(100, newGrowth));

      // District Level Up
      let newLevel = district.level;
      if (newGrowth > 90 && district.crisisLevel < 10) {
        newLevel += 0.01; // Slow level progression
      }

      const newPopulation = Math.floor(district.population * (1 + (newGrowth - 50) / 15000));

      let newStatus: District['status'] = 'STABLE';
      if (newCrisis > 70) newStatus = 'CRITICAL';
      else if (newCrisis > 40) newStatus = 'WARNING';

      return {
        ...district,
        crisisLevel: Math.min(100, newCrisis),
        needs: newNeeds,
        growth: newGrowth,
        level: newLevel,
        population: newPopulation,
        status: newStatus
      };
    }));

    // Resource regeneration increases with level
    const regenBoost = 1 + (gameLevel - 1) * 0.1;
    setResources(prev => ({
      food: Math.min(100 + (gameLevel - 1) * 20, prev.food + 1.2 * regenBoost),
      medical: Math.min(100 + (gameLevel - 1) * 20, prev.medical + 1.0 * regenBoost),
      safety: Math.min(100 + (gameLevel - 1) * 20, prev.safety + 0.9 * regenBoost),
      power: Math.min(100 + (gameLevel - 1) * 20, prev.power + 0.8 * regenBoost)
    }));

    setDistricts(prev => {
      const avgCrisis = prev.reduce((acc, d) => acc + d.crisisLevel, 0) / prev.length;
      const avgGrowth = prev.reduce((acc, d) => acc + d.growth, 0) / prev.length;
      const newProsperity = Math.max(0, Math.min(100, (100 - avgCrisis + avgGrowth) / 2));
      setProsperity(newProsperity);
      
      return prev;
    });
  }, [diffMultiplier, gameLevel]);

  useEffect(() => {
    if (isPlaying && !isGameOver) {
      timerRef.current = setInterval(() => {
        setTime(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            endGame();
            return 0;
          }
          return prev - 1;
        });
        updateTown();
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, isGameOver, updateTown]);

  const allocateResource = (districtId: number, type: keyof District['needs']) => {
    if (!isPlaying || isGameOver) return;
    
    const cost = 10;
    if (resources[type] < cost) {
      sounds.playError();
      return;
    }

    setResources(prev => ({ ...prev, [type]: prev[type] - cost }));
    setDistricts(prev => prev.map(d => {
      if (d.id === districtId) {
        const newNeeds = { ...d.needs, [type]: Math.max(0, d.needs[type] - 50) };
        const newCrisis = Math.max(0, d.crisisLevel - 20);
        const newGrowth = Math.min(100, d.growth + 8);
        return { ...d, needs: newNeeds, crisisLevel: newCrisis, growth: newGrowth };
      }
      return d;
    }));
    sounds.playAction();
  };

  const endGame = () => {
    setIsPlaying(false);
    setIsGameOver(true);
    const finalProsperity = prosperity;
    const status = finalProsperity > 70 ? 'WIN' : 'LOSE';
    setWinStatus(status);
    
    if (status === 'WIN') {
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#3b82f6', '#f59e0b']
      });
    }

    generateFeedback(status);
  };

  const generateFeedback = async (status: 'WIN' | 'LOSE') => {
    setIsGeneratingFeedback(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analyze this valley management performance:
          Level: ${gameLevel}
          Final Prosperity: ${prosperity}%
          Status: ${status}
          Difficulty: ${difficulty}
          Provide a short, encouraging debrief as a valley elder (max 2 sentences).`,
      });
      setAiFeedback(response.text || "The valley thrives under your wisdom.");
    } catch (error) {
      setAiFeedback(status === 'WIN' ? "The valley is at peace. Your stewardship has ensured a bright future." : "The balance is tipped. We must learn to listen to the land once more.");
    } finally {
      setIsGeneratingFeedback(false);
    }
  };

  const selectedDistrict = districts.find(d => d.id === selectedDistrictId);

  return (
    <div className="min-h-screen relative text-slate-900 font-sans selection:bg-emerald-500/30 overflow-hidden flex">
      {/* Scenic Background */}
      <div className="fixed inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80" 
          alt="Scenic Background" 
          className="w-full h-full object-cover opacity-90"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-sky-400/10 via-transparent to-emerald-900/30" />
      </div>

      {/* Sidebar Navigation (Dashboard Style) */}
      <div className="w-20 lg:w-24 bg-white/10 backdrop-blur-2xl border-r border-white/20 z-50 flex flex-col items-center py-8 gap-8">
        <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/30">
          <ShieldAlert className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1 flex flex-col gap-6">
          <button className="p-3 bg-white/20 rounded-xl text-emerald-600 shadow-sm"><LayoutGrid className="w-6 h-6" /></button>
          <button className="p-3 text-slate-400 hover:text-emerald-600 transition-colors"><PieChart className="w-6 h-6" /></button>
          <button className="p-3 text-slate-400 hover:text-emerald-600 transition-colors"><Users className="w-6 h-6" /></button>
          <button className="p-3 text-slate-400 hover:text-emerald-600 transition-colors"><Bell className="w-6 h-6" /></button>
          <button className="p-3 text-slate-400 hover:text-emerald-600 transition-colors"><Settings className="w-6 h-6" /></button>
        </div>
        <button className="p-3 text-slate-400 hover:text-rose-500 transition-colors" onClick={() => window.location.reload()}><RefreshCw className="w-6 h-6" /></button>
      </div>

      <div className="flex-1 relative z-10 flex flex-col overflow-hidden">
        {/* Top Header (Dashboard Style) */}
        <header className="h-20 bg-white/10 backdrop-blur-md border-b border-white/20 flex items-center justify-between px-8">
          <div className="flex flex-col">
            <h1 className="text-xl font-black text-slate-800 tracking-tight uppercase">Valley Quality Control</h1>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Environmental & Resource Management</p>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center bg-white/20 rounded-full px-4 py-2 border border-white/30">
              <Search className="w-4 h-4 text-slate-400 mr-2" />
              <input type="text" placeholder="Search districts..." className="bg-transparent border-none outline-none text-xs text-slate-700 w-48" />
            </div>
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-end">
                <span className="text-xs font-black text-slate-800">Guardian Adam</span>
                <span className="text-[8px] font-bold text-emerald-600 uppercase">Level {gameLevel} Master</span>
              </div>
              <div className="w-10 h-10 rounded-full bg-emerald-100 border border-emerald-200 overflow-hidden">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Adam" alt="Avatar" />
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-8 overflow-y-auto custom-scrollbar flex flex-col gap-8">
          {/* Stats Overview Row */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col justify-between h-32">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Overall Prosperity</span>
                <TrendingUp className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="flex items-end justify-between">
                <span className="text-3xl font-black text-slate-800">{Math.round(prosperity)}%</span>
                <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">+2.4%</span>
              </div>
            </div>
            <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col justify-between h-32">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Valley Level</span>
                <ArrowUpRight className="w-4 h-4 text-blue-500" />
              </div>
              <div className="flex items-end justify-between">
                <span className="text-3xl font-black text-slate-800">{gameLevel}</span>
                <button 
                  onClick={() => setGameLevel(prev => Math.min(4, prev + 1))}
                  className="text-[8px] font-black text-white bg-blue-600 px-3 py-1.5 rounded-lg uppercase tracking-widest hover:bg-blue-700 transition-colors"
                >
                  Upgrade
                </button>
              </div>
            </div>
            <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col justify-between h-32">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Time Remaining</span>
                <Timer className="w-4 h-4 text-rose-500" />
              </div>
              <div className="flex items-end justify-between">
                <span className="text-3xl font-black text-slate-800 tabular-nums">{time}s</span>
                <button 
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`p-2 rounded-lg ${isPlaying ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
              </div>
            </div>
            <div className="bg-white/60 backdrop-blur-xl p-6 rounded-3xl border border-white/40 shadow-sm flex flex-col justify-between h-32">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Population</span>
                <Users className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="flex items-end justify-between">
                <span className="text-2xl font-black text-slate-800 tabular-nums">{districts.reduce((acc, d) => acc + d.population, 0).toLocaleString()}</span>
                <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-lg">Thriving</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 flex-1">
            {/* Main Content Area */}
            <div className="xl:col-span-2 flex flex-col gap-8">
              {/* Resource Bars Section */}
              <div className="bg-white/60 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/40 shadow-sm">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">Global Resource Distribution</h3>
                  <div className="flex gap-2">
                    <button className="px-3 py-1 text-[10px] font-bold bg-white/40 rounded-lg text-slate-500 border border-white/60">Daily</button>
                    <button className="px-3 py-1 text-[10px] font-bold bg-emerald-600 rounded-lg text-white">Real-time</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {[
                    { label: 'Harvest', val: resources.food, color: 'bg-blue-500', icon: Droplets, max: 100 + (gameLevel - 1) * 20 },
                    { label: 'Wellness', val: resources.medical, color: 'bg-emerald-500', icon: Stethoscope, max: 100 + (gameLevel - 1) * 20 },
                    { label: 'Protection', val: resources.safety, color: 'bg-amber-500', icon: ShieldAlert, max: 100 + (gameLevel - 1) * 20 },
                    { label: 'Energy', val: resources.power, color: 'bg-indigo-500', icon: Zap, max: 100 + (gameLevel - 1) * 20 }
                  ].map((res, i) => (
                    <div key={i} className="space-y-4">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-lg ${res.color}/20 text-${res.color.split('-')[1]}-600`}><res.icon className="w-4 h-4" /></div>
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{res.label}</span>
                      </div>
                      <div className="relative h-24 w-full bg-slate-100 rounded-2xl overflow-hidden flex flex-col justify-end">
                        <motion.div 
                          animate={{ height: `${(res.val / res.max) * 100}%` }} 
                          className={`w-full ${res.color} opacity-80`}
                        />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-xs font-black text-slate-800">{Math.round(res.val)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* District Grid */}
              <div className="bg-white/60 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/40 shadow-sm flex-1">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight">District Management Grid</h3>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{districts.length} active zones</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {districts.map((district) => {
                    const dt = DISTRICT_TYPES.find(d => d.type === district.type)!;
                    return (
                      <motion.button
                        key={district.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => {
                          setSelectedDistrictId(district.id);
                          sounds.playClick();
                        }}
                        className={`p-4 rounded-3xl border text-left flex items-center gap-4 transition-all ${
                          selectedDistrictId === district.id 
                            ? 'bg-emerald-600 border-emerald-700 shadow-lg shadow-emerald-500/20' 
                            : 'bg-white/40 border-white/60 hover:bg-white/60'
                        }`}
                      >
                        <div className={`w-12 h-12 rounded-2xl overflow-hidden border-2 ${selectedDistrictId === district.id ? 'border-white/40' : 'border-white/60'}`}>
                          <img src={district.image} alt={district.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1">
                          <h4 className={`text-xs font-black uppercase tracking-tight ${selectedDistrictId === district.id ? 'text-white' : 'text-slate-800'}`}>{district.name}</h4>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex-1 h-1 bg-black/10 rounded-full overflow-hidden">
                              <div className={`h-full ${district.crisisLevel > 70 ? 'bg-rose-500' : 'bg-emerald-500'}`} style={{ width: `${district.crisisLevel}%` }} />
                            </div>
                            <span className={`text-[8px] font-bold ${selectedDistrictId === district.id ? 'text-white/60' : 'text-slate-400'}`}>{Math.round(district.crisisLevel)}%</span>
                          </div>
                        </div>
                        <ChevronRight className={`w-4 h-4 ${selectedDistrictId === district.id ? 'text-white' : 'text-slate-300'}`} />
                      </motion.button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right Detail Panel (Dashboard Style) */}
            <div className="xl:col-span-1 flex flex-col gap-8">
              <AnimatePresence mode="wait">
                {selectedDistrict ? (
                  <motion.div
                    key={selectedDistrict.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="bg-slate-900 rounded-[2.5rem] p-8 text-white shadow-2xl flex flex-col gap-8 h-full"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">District Profile</span>
                        <h3 className="text-2xl font-black italic tracking-tighter uppercase">{selectedDistrict.name}</h3>
                      </div>
                      <div className="bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full border border-emerald-500/30 text-[10px] font-black uppercase">
                        Lv. {Math.floor(selectedDistrict.level)}
                      </div>
                    </div>

                    <div className="aspect-video w-full rounded-3xl overflow-hidden border border-white/10 relative group">
                      <img src={selectedDistrict.image} alt={selectedDistrict.name} className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-700" />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                        <div className="flex flex-col">
                          <span className="text-[8px] font-bold text-white/40 uppercase tracking-widest">Current Status</span>
                          <span className={`text-xs font-black uppercase ${selectedDistrict.status === 'CRITICAL' ? 'text-rose-400' : 'text-emerald-400'}`}>{selectedDistrict.status}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[8px] font-bold text-white/40 uppercase tracking-widest">Growth Rate</span>
                          <span className="text-xs font-black text-white">{Math.round(selectedDistrict.growth)}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <h4 className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Resource Requirements</h4>
                      <div className="grid grid-cols-1 gap-4">
                        {[
                          { id: 'food', label: 'Harvest Needs', val: selectedDistrict.needs.food, icon: Droplets, color: 'text-blue-400', bg: 'bg-blue-500/20' },
                          { id: 'medical', label: 'Wellness Needs', val: selectedDistrict.needs.medical, icon: Stethoscope, color: 'text-emerald-400', bg: 'bg-emerald-500/20' },
                          { id: 'safety', label: 'Protection Needs', val: selectedDistrict.needs.safety, icon: ShieldAlert, color: 'text-amber-400', bg: 'bg-amber-500/20' },
                          { id: 'power', label: 'Energy Needs', val: selectedDistrict.needs.power, icon: Zap, color: 'text-indigo-400', bg: 'bg-indigo-500/20' }
                        ].map((req, i) => (
                          <div key={i} className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center justify-between group hover:bg-white/10 transition-colors">
                            <div className="flex items-center gap-3">
                              <div className={`p-2 rounded-lg ${req.bg} ${req.color}`}><req.icon className="w-4 h-4" /></div>
                              <div className="flex flex-col">
                                <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">{req.label}</span>
                                <div className="w-24 h-1 bg-white/10 rounded-full mt-1 overflow-hidden">
                                  <motion.div animate={{ width: `${req.val}%` }} className={`h-full ${req.color.replace('text', 'bg')}`} />
                                </div>
                              </div>
                            </div>
                            <button 
                              onClick={() => allocateResource(selectedDistrict.id, req.id as any)}
                              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                                resources[req.id as keyof typeof resources] >= 10 
                                  ? 'bg-white text-slate-900 hover:bg-emerald-400' 
                                  : 'bg-white/5 text-white/20 cursor-not-allowed'
                              }`}
                            >
                              Supply
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="mt-auto pt-6 border-t border-white/10">
                      <div className="flex items-center gap-4 text-white/40">
                        <Info className="w-4 h-4" />
                        <p className="text-[10px] font-serif italic leading-relaxed">
                          This district is currently {selectedDistrict.status.toLowerCase()}. 
                          {selectedDistrict.growth > 80 ? " Growth is exceptional." : " Focus on fulfilling needs to boost growth."}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="bg-white/40 backdrop-blur-xl rounded-[2.5rem] p-12 border border-white/60 flex flex-col items-center justify-center text-center h-full">
                    <div className="w-20 h-20 bg-slate-200 rounded-full flex items-center justify-center mb-6">
                      <MapIcon className="w-10 h-10 text-slate-400" />
                    </div>
                    <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight mb-2">Select a District</h3>
                    <p className="text-xs text-slate-500 font-serif italic">Click on any town in the grid to view detailed environmental analytics and resource requirements.</p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </main>
      </div>

      <AnimatePresence>
        {isGameOver && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 z-[300] bg-white/40 backdrop-blur-xl flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="max-w-2xl w-full bg-white/80 border border-white/40 rounded-[3rem] p-12 text-center shadow-2xl"
            >
              <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-8 ${
                winStatus === 'WIN' ? 'bg-emerald-500/20 text-emerald-600 shadow-[0_0_50px_rgba(16,185,129,0.3)]' : 'bg-rose-500/20 text-rose-600 shadow-[0_0_50px_rgba(225,29,72,0.3)]'
              }`}>
                {winStatus === 'WIN' ? <Trophy className="w-12 h-12" /> : <XCircle className="w-12 h-12" />}
              </div>
              
              <h2 className="text-5xl lg:text-7xl font-black tracking-tighter uppercase mb-4 text-slate-800">
                {winStatus === 'WIN' ? 'Valley Flourishing' : 'Town in Distress'}
              </h2>
              
              <div className="grid grid-cols-2 gap-6 mb-12">
                <div className="bg-white/50 p-6 rounded-3xl border border-white/60">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Final Prosperity</span>
                  <span className="text-4xl font-black text-emerald-600">{Math.round(prosperity)}%</span>
                </div>
                <div className="bg-white/50 p-6 rounded-3xl border border-white/60">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2">Valley Level</span>
                  <span className="text-4xl font-black text-slate-700">{gameLevel}</span>
                </div>
              </div>

              <div className="bg-emerald-50/80 p-8 rounded-3xl border border-emerald-100 mb-12 text-left relative overflow-hidden">
                <h4 className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.3em] mb-4">Guardian's Reflection</h4>
                <p className="text-lg font-serif italic text-slate-700 leading-relaxed">
                  {isGeneratingFeedback ? "Listening to the winds..." : aiFeedback}
                </p>
              </div>

              <button 
                onClick={() => window.location.reload()}
                className="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-700 transition-all active:scale-95 shadow-lg shadow-emerald-500/30 text-sm lg:text-base"
              >
                Restart Simulation
              </button>
            </motion.div>
          </motion.div>
        )}

        {showInstructions && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[400] bg-white/60 backdrop-blur-2xl rounded-[2rem] p-12 flex flex-col items-center justify-center text-center"
          >
            <div className="w-20 h-20 bg-emerald-500/10 border border-emerald-500/30 rounded-3xl flex items-center justify-center mb-8 shadow-lg shadow-emerald-500/20">
              <Trees className="w-10 h-10 text-emerald-600" />
            </div>
            <h3 className="text-4xl lg:text-6xl font-black text-slate-800 tracking-tighter uppercase mb-6">Valley Quality Control</h3>
            <div className="max-w-2xl space-y-6 mb-12 text-slate-600 font-serif italic text-base lg:text-lg leading-relaxed">
              <p>Guardian, welcome to the scenic valley management dashboard. Your mission is to maintain environmental quality across all districts.</p>
              <ul className="text-left space-y-4 bg-white/40 p-8 rounded-[2rem] border border-white/60">
                <li className="flex items-start gap-3"><span className="text-emerald-600 font-black">01</span> Click on any town in the grid to see its **Detailed Profile**.</li>
                <li className="flex items-start gap-3"><span className="text-emerald-600 font-black">02</span> Monitor specific needs: <span className="text-blue-600 font-bold">Harvest</span>, <span className="text-emerald-600 font-bold">Wellness</span>, <span className="text-amber-600 font-bold">Protection</span>, and <span className="text-indigo-600 font-bold">Energy</span>.</li>
                <li className="flex items-start gap-3"><span className="text-emerald-600 font-black">03</span> Level up the valley to unlock more towns and increase resource capacity.</li>
                <li className="flex items-start gap-3"><span className="text-emerald-600 font-black">04</span> Maintain prosperity above 70% to ensure the valley's future.</li>
              </ul>
            </div>
            <button 
              onClick={() => setShowInstructions(false)}
              className="bg-emerald-600 text-white px-16 py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-500/30 text-sm lg:text-base active:scale-95"
            >
              Access Dashboard
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
