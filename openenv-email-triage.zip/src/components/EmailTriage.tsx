import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mail, 
  Trash2, 
  FolderInput, 
  Flag, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw,
  ChevronRight,
  Inbox,
  Send,
  Archive,
  Trash,
  DollarSign,
  AlertTriangle,
  Zap
} from 'lucide-react';

interface Email {
  id: string;
  sender: string;
  subject: string;
  body: string;
  category: "INVOICE" | "SPAM" | "URGENT" | "GENERAL";
  is_flagged: boolean;
  is_read: boolean;
  folder: string;
}

interface Observation {
  emails: Email[];
  folders: string[];
  message: string;
  reward: number;
  done: boolean;
  info: {
    step_count: number;
    task_id: string;
    score: number;
  };
}

export default function EmailTriage() {
  const [obs, setObs] = useState<Observation | null>(null);
  const [taskId, setTaskId] = useState("easy_cleanup");
  const [loading, setLoading] = useState(false);
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [summary, setSummary] = useState<string | null>(null);
  const [summarizing, setSummarizing] = useState(false);
  const [showGenerator, setShowGenerator] = useState(false);
  const [newEmail, setNewEmail] = useState({
    sender: "",
    subject: "",
    body: "",
    category: "GENERAL" as Email["category"],
    folder: "Inbox"
  });

  const resetEnv = async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/reset?task_id=${id}`);
      const data = await res.json();
      setObs(data);
      setTaskId(id);
      setSelectedEmailId(null);
      setSummary(null);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const stepEnv = async (action: any) => {
    try {
      const res = await fetch('/api/step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(action)
      });
      const data = await res.json();
      setObs(data);
    } catch (err) {
      console.error(err);
    }
  };

  const generateEmail = async () => {
    try {
      const res = await fetch('/api/generate_email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEmail)
      });
      const data = await res.json();
      if (obs) {
        setObs({
          ...obs,
          emails: [...obs.emails, data]
        });
      }
      setShowGenerator(false);
      setNewEmail({
        sender: "",
        subject: "",
        body: "",
        category: "GENERAL",
        folder: "Inbox"
      });
    } catch (err) {
      console.error(err);
    }
  };

  const summarizeEmail = async (email: Email) => {
    setSummarizing(true);
    setSummary(null);
    try {
      const { GoogleGenAI } = await import("@google/genai");
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Summarize this email in one short sentence: 
        From: ${email.sender}
        Subject: ${email.subject}
        Body: ${email.body}`
      });
      setSummary(response.text || "Could not summarize.");
    } catch (err) {
      console.error(err);
      setSummary("Error generating summary.");
    } finally {
      setSummarizing(false);
    }
  };

  useEffect(() => {
    resetEnv("easy_cleanup");
  }, []);

  useEffect(() => {
    if (selectedEmailId) {
      const email = obs?.emails.find(e => e.id === selectedEmailId);
      if (email && !email.is_read) {
        stepEnv({ type: "READ", email_id: selectedEmailId });
      }
      setSummary(null);
    }
  }, [selectedEmailId]);

  if (!obs) return <div className="flex items-center justify-center h-full text-white/40 font-mono">Initializing Environment...</div>;

  const filteredEmails = obs.emails.filter(e => 
    e.folder === 'Inbox' && (
      e.sender.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.body.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const selectedEmail = obs.emails.find(e => e.id === selectedEmailId);

  return (
    <div className="flex flex-col h-full bg-[#050505] text-white font-sans overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between p-6 border-b border-white/10 bg-black/40 backdrop-blur-md">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-cyan-500/20 border border-cyan-500/50 rounded-lg flex items-center justify-center text-cyan-400">
            <Mail className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black tracking-tighter uppercase italic text-glow-cyan">Email_Triage_Env</h2>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">Task_ID:</span>
              <span className="text-[10px] font-mono text-cyan-400/80 uppercase">{obs.info.task_id}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex flex-col items-end">
            <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Progress_Score</span>
            <span className="text-lg font-mono text-cyan-400">{obs.info.score.toFixed(1)}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Steps</span>
            <span className="text-lg font-mono text-fuchsia-400">{obs.info.step_count}</span>
          </div>
          <button 
            onClick={() => resetEnv(taskId)}
            className="p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-cyan-500/20 hover:border-cyan-500/50 transition-all group"
          >
            <RefreshCw className={`w-5 h-5 text-white/40 group-hover:text-cyan-400 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </header>

      {/* Task Selector & Search */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 bg-black/20 border-b border-white/5">
        <div className="flex gap-2">
          {["easy_cleanup", "medium_categorization", "hard_prioritization"].map(id => (
            <button
              key={id}
              onClick={() => resetEnv(id)}
              className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest transition-all border ${
                taskId === id 
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]' 
                  : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'
              }`}
            >
              {id.replace('_', ' ')}
            </button>
          ))}
        </div>
        
        <div className="flex items-center gap-4 flex-1 max-w-md">
          <div className="relative flex-1">
            <input 
              type="text"
              placeholder="Search emails..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-1.5 text-xs text-white/80 focus:outline-none focus:border-cyan-500/50 transition-all"
            />
          </div>
          <button 
            onClick={() => setShowGenerator(true)}
            className="px-4 py-1.5 rounded-lg bg-fuchsia-500/20 border border-fuchsia-500/50 text-fuchsia-400 text-[10px] font-bold uppercase tracking-widest hover:bg-fuchsia-500/30 transition-all"
          >
            New_Email
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar Folders */}
        <div className="w-64 border-r border-white/5 bg-black/20 p-4 space-y-2">
          <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest block mb-4">Directories</span>
          {obs.folders.map(folder => (
            <div 
              key={folder}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-all group cursor-pointer"
            >
              {folder === 'Inbox' && <Inbox className="w-4 h-4 text-cyan-400" />}
              {folder === 'Spam' && <AlertTriangle className="w-4 h-4 text-amber-500" />}
              {folder === 'Finance' && <DollarSign className="w-4 h-4 text-emerald-500" />}
              {folder === 'Archive' && <Archive className="w-4 h-4 text-blue-400" />}
              {folder === 'Trash' && <Trash className="w-4 h-4 text-red-500" />}
              <span className="text-sm text-white/60 group-hover:text-white transition-colors">{folder}</span>
              <span className="ml-auto text-[10px] font-mono text-white/20">
                {obs.emails.filter(e => e.folder === folder).length}
              </span>
            </div>
          ))}
        </div>

        {/* Email List */}
        <div className="flex-1 overflow-y-auto border-r border-white/5 custom-scrollbar">
          <div className="p-4 border-b border-white/5 bg-white/2 flex justify-between items-center">
            <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Active_Queue</span>
            <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">{filteredEmails.length} Results</span>
          </div>
          {filteredEmails.map(email => (
            <motion.div
              layoutId={email.id}
              key={email.id}
              onClick={() => setSelectedEmailId(email.id)}
              className={`p-4 border-b border-white/5 cursor-pointer transition-all hover:bg-white/5 relative ${
                selectedEmailId === email.id ? 'bg-cyan-500/10 border-l-2 border-l-cyan-500' : ''
              }`}
            >
              {!email.is_read && (
                <div className="absolute top-4 left-1 w-1.5 h-1.5 bg-cyan-500 rounded-full shadow-[0_0_8px_rgba(6,182,212,1)]" />
              )}
              <div className="flex justify-between items-start mb-1">
                <span className={`text-sm font-bold ${email.is_read ? 'text-white/40' : 'text-white/80'}`}>{email.sender}</span>
                <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-tighter ${
                  email.category === 'URGENT' ? 'bg-red-500/20 text-red-400' :
                  email.category === 'SPAM' ? 'bg-amber-500/20 text-amber-400' :
                  email.category === 'INVOICE' ? 'bg-emerald-500/20 text-emerald-400' :
                  'bg-blue-500/20 text-blue-400'
                }`}>
                  {email.category}
                </span>
              </div>
              <h4 className={`text-xs font-medium mb-1 truncate ${email.is_read ? 'text-white/30' : 'text-white/60'}`}>{email.subject}</h4>
              <p className="text-[10px] text-white/20 line-clamp-1 italic">{email.body}</p>
            </motion.div>
          ))}
          {filteredEmails.length === 0 && (
            <div className="flex flex-col items-center justify-center p-12 text-white/20">
              <CheckCircle2 className="w-12 h-12 mb-4 opacity-20" />
              <span className="text-sm font-mono uppercase tracking-widest">No_Emails_Found</span>
            </div>
          )}
        </div>

        {/* Email Detail / Actions */}
        <div className="w-[450px] bg-black/40 flex flex-col relative">
          <AnimatePresence mode="wait">
            {showGenerator ? (
              <motion.div
                key="generator"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="flex flex-col h-full p-8"
              >
                <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-black tracking-tighter uppercase italic text-white">Generate_Email</h3>
                  <button onClick={() => setShowGenerator(false)} className="text-white/40 hover:text-white transition-colors">
                    <RefreshCw className="w-4 h-4 rotate-45" />
                  </button>
                </div>
                
                <div className="space-y-4 flex-1">
                  <div className="space-y-1">
                    <label className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Sender</label>
                    <input 
                      type="text"
                      value={newEmail.sender}
                      onChange={(e) => setNewEmail({...newEmail, sender: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-xs text-white/80 focus:outline-none focus:border-cyan-500/50"
                      placeholder="e.g. boss@company.com"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Subject</label>
                    <input 
                      type="text"
                      value={newEmail.subject}
                      onChange={(e) => setNewEmail({...newEmail, subject: e.target.value})}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-xs text-white/80 focus:outline-none focus:border-cyan-500/50"
                      placeholder="e.g. [URGENT] Report Due"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Category</label>
                    <select 
                      value={newEmail.category}
                      onChange={(e) => setNewEmail({...newEmail, category: e.target.value as Email["category"]})}
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-xs text-white/80 focus:outline-none focus:border-cyan-500/50"
                    >
                      <option value="GENERAL">GENERAL</option>
                      <option value="SPAM">SPAM</option>
                      <option value="INVOICE">INVOICE</option>
                      <option value="URGENT">URGENT</option>
                    </select>
                  </div>
                  <div className="space-y-1 flex-1 flex flex-col">
                    <label className="text-[8px] font-mono text-white/20 uppercase tracking-widest">Body</label>
                    <textarea 
                      value={newEmail.body}
                      onChange={(e) => setNewEmail({...newEmail, body: e.target.value})}
                      className="w-full flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-xs text-white/80 focus:outline-none focus:border-cyan-500/50 resize-none"
                      placeholder="Email content..."
                    />
                  </div>
                </div>
                
                <button 
                  onClick={generateEmail}
                  className="mt-8 w-full py-4 rounded-xl bg-cyan-500/20 border border-cyan-500/50 text-cyan-400 font-bold uppercase text-[10px] tracking-widest hover:bg-cyan-500/30 transition-all"
                >
                  Dispatch_Email
                </button>
              </motion.div>
            ) : selectedEmail ? (
              <motion.div 
                key={selectedEmail.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex flex-col h-full p-8"
              >
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h3 className="text-2xl font-black tracking-tighter uppercase italic text-white mb-2">{selectedEmail.subject}</h3>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-white/40">From:</span>
                      <span className="text-xs text-cyan-400/80 font-mono">{selectedEmail.sender}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {selectedEmail.is_flagged && (
                      <Flag className="w-5 h-5 text-red-500 fill-red-500" />
                    )}
                    <button 
                      onClick={() => summarizeEmail(selectedEmail)}
                      disabled={summarizing}
                      className="p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-cyan-500/20 hover:border-cyan-500/50 transition-all group disabled:opacity-50"
                      title="AI Summarize"
                    >
                      <Zap className={`w-4 h-4 text-white/40 group-hover:text-cyan-400 ${summarizing ? 'animate-pulse' : ''}`} />
                    </button>
                  </div>
                </div>

                <div className="flex-1 flex flex-col gap-4 overflow-hidden">
                  <div className="flex-1 p-6 bg-white/5 rounded-2xl border border-white/5 font-serif italic text-white/60 leading-relaxed overflow-y-auto custom-scrollbar">
                    {selectedEmail.body}
                  </div>
                  
                  {summary && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-cyan-500/10 border border-cyan-500/20 rounded-xl"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="w-3 h-3 text-cyan-400" />
                        <span className="text-[8px] font-mono text-cyan-400 uppercase tracking-widest">AI_Summary</span>
                      </div>
                      <p className="text-[10px] text-white/70 leading-relaxed">{summary}</p>
                    </motion.div>
                  )}
                </div>

                <div className="space-y-4 mt-8">
                  <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest block">Available_Actions</span>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => stepEnv({ type: "DELETE", email_id: selectedEmail.id })}
                      className="flex items-center justify-center gap-2 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500/20 transition-all font-bold uppercase text-[10px] tracking-widest"
                    >
                      <Trash2 className="w-4 h-4" />
                      Delete_Spam
                    </button>
                    <button 
                      onClick={() => stepEnv({ type: "FLAG", email_id: selectedEmail.id })}
                      className="flex items-center justify-center gap-2 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 transition-all font-bold uppercase text-[10px] tracking-widest"
                    >
                      <Flag className="w-4 h-4" />
                      Flag_Urgent
                    </button>
                    <button 
                      onClick={() => stepEnv({ type: "MOVE", email_id: selectedEmail.id, folder: "Finance" })}
                      className="flex items-center justify-center gap-2 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20 transition-all font-bold uppercase text-[10px] tracking-widest"
                    >
                      <DollarSign className="w-4 h-4" />
                      To_Finance
                    </button>
                    <button 
                      onClick={() => stepEnv({ type: "MOVE", email_id: selectedEmail.id, folder: "Archive" })}
                      className="flex items-center justify-center gap-2 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 hover:bg-blue-500/20 transition-all font-bold uppercase text-[10px] tracking-widest"
                    >
                      <Archive className="w-4 h-4" />
                      Archive
                    </button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-white/10 p-12 text-center">
                <Mail className="w-16 h-16 mb-6 opacity-10" />
                <h3 className="text-xl font-black tracking-tighter uppercase italic mb-2">Select_Email</h3>
                <p className="text-xs font-serif italic text-white/20">Awaiting agent input or manual selection to begin triage process.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Footer Status */}
      <footer className="p-4 bg-black/60 border-t border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${obs.done ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'}`} />
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">
              Status: {obs.done ? 'Task_Complete' : 'Processing_Queue'}
            </span>
          </div>
          <div className="h-4 w-[1px] bg-white/10" />
          <div className="flex items-center gap-2 text-[10px] font-mono text-cyan-400/60">
            <AlertCircle className="w-3 h-3" />
            <span>{obs.message}</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[8px] font-mono text-white/20 uppercase tracking-widest">System_Ready</span>
          <div className="flex gap-1">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="w-1 h-3 bg-cyan-500/20 rounded-full" />
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
