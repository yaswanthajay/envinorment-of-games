import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Chess, Move } from 'chess.js';
import { Chessboard } from 'react-chessboard';
import { 
  Trophy, 
  RotateCcw, 
  Flag, 
  ChevronLeft, 
  ChevronRight, 
  Settings, 
  User, 
  Cpu, 
  Clock,
  History,
  AlertCircle,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Volume2,
  VolumeX,
  Palette,
  Maximize2,
  Minimize2,
  Undo
} from 'lucide-react';
import { io, Socket } from 'socket.io-client';
import { motion, AnimatePresence } from 'motion/react';
import useSound from 'use-sound';

interface ChessGameProps {
  onBack: () => void;
}

type GameMode = 'AI' | 'ONLINE' | 'FRIENDS' | 'PUZZLES' | 'DAILY';
type Difficulty = 'EASY' | 'MEDIUM' | 'HARD' | 'EXPERT';
type Theme = 'CLASSIC' | 'WOOD' | 'NEON' | 'DARK';

const THEMES: Record<Theme, { dark: string, light: string, accent: string }> = {
  CLASSIC: { dark: '#769656', light: '#eeeed2', accent: '#f6f669' },
  WOOD: { dark: '#b58863', light: '#f0d9b5', accent: '#cdbeaf' },
  NEON: { dark: '#1a1a2e', light: '#16213e', accent: '#0f3460' },
  DARK: { dark: '#2a2a2a', light: '#3a3a3a', accent: '#4a4a4a' }
};

export const ChessGame: React.FC<ChessGameProps> = ({ onBack }) => {
  const [game, setGame] = useState(new Chess());
  const [mode, setMode] = useState<GameMode | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty>('MEDIUM');
  const [playerColor, setPlayerColor] = useState<'white' | 'black'>('white');
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  const [status, setStatus] = useState<string>('Select a game mode');
  const [isGameOver, setIsGameOver] = useState(false);
  const [winner, setWinner] = useState<string | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);
  const [gameId, setGameId] = useState<string | null>(null);
  const [whiteTimer, setWhiteTimer] = useState(600);
  const [blackTimer, setBlackTimer] = useState(600);
  const [isMatchmaking, setIsMatchmaking] = useState(false);
  const [theme, setTheme] = useState<Theme>('DARK');
  const [isMuted, setIsMuted] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const getPiecePath = (p: string) => {
    const map: Record<string, string> = {
      wP: '4/45/Chess_plt45.svg',
      wN: '7/70/Chess_nlt45.svg',
      wB: 'b/b1/Chess_blt45.svg',
      wR: '7/72/Chess_rlt45.svg',
      wQ: '1/15/Chess_qlt45.svg',
      wK: '4/42/Chess_klt45.svg',
      bP: 'c/c7/Chess_pdt45.svg',
      bN: 'e/ef/Chess_ndt45.svg',
      bB: '9/98/Chess_bdt45.svg',
      bR: 'f/ff/Chess_rdt45.svg',
      bQ: '4/47/Chess_qdt45.svg',
      bK: 'f/f0/Chess_kdt45.svg',
    };
    return map[p];
  };

  const customPieces = useMemo(() => {
    const pieceComponents: any = {};
    const pieces = ['wP', 'wN', 'wB', 'wR', 'wQ', 'wK', 'bP', 'bN', 'bB', 'bR', 'bQ', 'bK'];
    
    pieces.forEach((p) => {
      pieceComponents[p] = ({ squareWidth }: { squareWidth: number }) => (
        <div
          style={{
            width: squareWidth,
            height: squareWidth,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'grab',
          }}
        >
          <img
            src={`https://upload.wikimedia.org/wikipedia/commons/${getPiecePath(p)}`}
            alt={p}
            style={{ 
              width: '100%', 
              height: '100%',
              filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.3))',
              pointerEvents: 'none', // Prevent image from interfering with drag
            }}
            referrerPolicy="no-referrer"
          />
        </div>
      );
    });
    return pieceComponents;
  }, []);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);

  // Sounds
  const [playMove] = useSound('https://assets.chesscomfiles.com/chess-themes/sounds/_default/default/move-self.mp3', { soundEnabled: !isMuted });
  const [playCapture] = useSound('https://assets.chesscomfiles.com/chess-themes/sounds/_default/default/capture.mp3', { soundEnabled: !isMuted });
  const [playCheck] = useSound('https://assets.chesscomfiles.com/chess-themes/sounds/_default/default/move-check.mp3', { soundEnabled: !isMuted });
  const [playEnd] = useSound('https://assets.chesscomfiles.com/chess-themes/sounds/_default/default/game-end.mp3', { soundEnabled: !isMuted });

  const [playerElo, setPlayerElo] = useState(1200);
  const [opponentElo, setOpponentElo] = useState(1200);

  const [moveSquares, setMoveSquares] = useState({});
  const [optionSquares, setOptionSquares] = useState({});
  const [lastMoveSquares, setLastMoveSquares] = useState({});
  const [checkSquare, setCheckSquare] = useState({});
  const [hoverSquare, setHoverSquare] = useState<string | null>(null);

  // Initialize Socket.io
  useEffect(() => {
    const newSocket = io();
    setSocket(newSocket);

    newSocket.on('match_found', ({ gameId, color, opponentElo }) => {
      setGameId(gameId);
      setPlayerColor(color);
      setOpponentElo(opponentElo);
      setMode('ONLINE');
      setIsMatchmaking(false);
      setStatus(`Match found! You are playing as ${color}.`);
      setGame(new Chess());
      setMoveHistory([]);
      setIsGameOver(false);
      setWhiteTimer(600);
      setBlackTimer(600);
    });

    newSocket.on('opponent_move', (move: Move) => {
      setGame((prevGame) => {
        const gameCopy = new Chess(prevGame.fen());
        try {
          const result = gameCopy.move(move);
          if (result) {
            if (result.captured) playCapture();
            else if (gameCopy.isCheck()) playCheck();
            else playMove();
          }
        } catch (e) {
          console.error("Invalid opponent move", e);
        }
        return gameCopy;
      });
    });

    newSocket.on('opponent_resigned', () => {
      setStatus('Opponent resigned. You win!');
      setIsGameOver(true);
      setWinner(playerColor);
      playEnd();
    });

    return () => {
      newSocket.disconnect();
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [playerColor, playMove, playCapture, playCheck, playEnd]);

  // Timer Logic
  useEffect(() => {
    if (mode && !isGameOver) {
      timerRef.current = setInterval(() => {
        if (game.turn() === 'w') {
          setWhiteTimer((prev) => {
            if (prev <= 0) {
              setIsGameOver(true);
              setWinner('black');
              setStatus('White ran out of time.');
              playEnd();
              return 0;
            }
            return prev - 1;
          });
        } else {
          setBlackTimer((prev) => {
            if (prev <= 0) {
              setIsGameOver(true);
              setWinner('white');
              setStatus('Black ran out of time.');
              playEnd();
              return 0;
            }
            return prev - 1;
          });
        }
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [mode, isGameOver, game.turn(), playEnd]);

  // Game Status Logic
  useEffect(() => {
    if (game.isCheckmate()) {
      setStatus(`Checkmate! ${game.turn() === 'w' ? 'Black' : 'White'} wins.`);
      setIsGameOver(true);
      setWinner(game.turn() === 'w' ? 'black' : 'white');
      playEnd();
    } else if (game.isDraw()) {
      setStatus('Draw!');
      setIsGameOver(true);
      playEnd();
    } else if (game.isCheck()) {
      setStatus('Check!');
    } else {
      setStatus(game.turn() === 'w' ? "White's turn" : "Black's turn");
    }

    setMoveHistory(game.history());
  }, [game, playEnd]);

  const capturedPieces = useMemo(() => {
    const pieces = { white: [] as string[], black: [] as string[] };
    const board = game.board();
    const currentPieces: Record<string, number> = {};
    
    board.forEach(row => {
      row.forEach(square => {
        if (square) {
          const key = square.color + square.type;
          currentPieces[key] = (currentPieces[key] || 0) + 1;
        }
      });
    });

    const startingPieces: Record<string, number> = {
      wp: 8, wn: 2, wb: 2, wr: 2, wq: 1, wk: 1,
      bp: 8, bn: 2, bb: 2, br: 2, bq: 1, bk: 1
    };

    Object.entries(startingPieces).forEach(([key, count]) => {
      const lost = count - (currentPieces[key] || 0);
      for (let i = 0; i < lost; i++) {
        if (key[0] === 'w') pieces.black.push(key[1]);
        else pieces.white.push(key[1]);
      }
    });

    return pieces;
  }, [game]);

  function getMoveOptions(square: string) {
    const piece = game.get(square as any);
    const isPawn = piece?.type === 'p';
    const moves = game.moves({
      square: square as any,
      verbose: true,
    }) as any[];
    if (moves.length === 0) {
      setOptionSquares({});
      return false;
    }

    const newSquares: any = {};
    moves.map((move) => {
      const isCapture = move.flags.includes('c') || move.flags.includes('e');
      const isSpecial = move.flags.includes('k') || move.flags.includes('q') || move.flags.includes('p');
      const isPawnCapture = isPawn && isCapture;
      
      newSquares[move.to] = {
        className: isPawnCapture ? "pawn-capture-glow" : "valid-move-glow",
        background: isPawnCapture
          ? "radial-gradient(circle, rgba(239, 68, 68, 0.8) 85%, transparent 85%)"
          : isCapture
          ? "radial-gradient(circle, rgba(239, 68, 68, 0.5) 85%, transparent 85%)"
          : isSpecial
          ? "radial-gradient(circle, rgba(251, 191, 36, 0.5) 85%, transparent 85%)"
          : "radial-gradient(circle, rgba(255, 255, 255, 0.3) 25%, transparent 25%)",
        backgroundColor: isPawnCapture ? "rgba(239, 68, 68, 0.4)" : isCapture ? "rgba(239, 68, 68, 0.2)" : "transparent",
        borderRadius: "50%",
        boxShadow: isPawnCapture 
          ? "0 0 30px rgba(239, 68, 68, 1), inset 0 0 15px rgba(239, 68, 68, 0.6)" 
          : isCapture 
          ? "0 0 20px rgba(239, 68, 68, 0.6)" 
          : isSpecial 
          ? "0 0 20px rgba(251, 191, 36, 0.6)" 
          : "none",
        transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
        zIndex: 10,
      };
      return move;
    });
    newSquares[square] = {
      className: "selected-square-highlight",
      backgroundColor: "rgba(6, 182, 212, 0.2)",
      boxShadow: "inset 0 0 15px rgba(6, 182, 212, 0.4)",
    };
    setOptionSquares(newSquares);
    return true;
  }

  const updateBoardState = useCallback((gameCopy: Chess, result?: Move) => {
    setGame(gameCopy);
    setOptionSquares({});
    setMoveSquares({});
    setHoverSquare(null);
    
    // Update last move highlight
    if (result) {
      setLastMoveSquares({
        [result.from]: { className: "last-move-highlight" },
        [result.to]: { className: "last-move-highlight" },
      });
    }

    // Update check highlight
    if (gameCopy.isCheck()) {
      const board = gameCopy.board();
      let kingPos = "";
      for (let i = 0; i < 8; i++) {
        for (let j = 0; j < 8; j++) {
          const piece = board[i][j];
          if (piece && piece.type === 'k' && piece.color === gameCopy.turn()) {
            kingPos = String.fromCharCode(97 + j) + (8 - i);
          }
        }
      }
      if (kingPos) {
        setCheckSquare({
          [kingPos]: { className: "king-check-pulse" }
        });
      }
    } else {
      setCheckSquare({});
    }
  }, []);

  const makeAMove = useCallback((move: any) => {
    try {
      const gameCopy = new Chess(game.fen());
      const result = gameCopy.move(move);
      
      if (result) {
        updateBoardState(gameCopy, result);
        if (result.captured) playCapture();
        else if (gameCopy.isCheck()) playCheck();
        else playMove();

        if (mode === 'ONLINE' && socket && gameId) {
          socket.emit('move', { gameId, move: result });
        }
        return true;
      }
    } catch (e) {
      return false;
    }
    return false;
  }, [game, mode, socket, gameId, playMove, playCapture, playCheck, updateBoardState]);

  function onSquareClick(square: string) {
    if (isGameOver) return;
    
    // from square
    if (Object.keys(moveSquares).length === 0) {
      // Enforce turns for selection
      const piece = game.get(square as any);
      if (piece && ((mode === 'ONLINE' || mode === 'AI') && piece.color !== playerColor[0])) {
        return;
      }

      const hasOptions = getMoveOptions(square);
      if (hasOptions) {
        setMoveSquares({ [square]: { 
          className: "selected-square-highlight",
          backgroundColor: "rgba(6, 182, 212, 0.2)",
          boxShadow: "inset 0 0 15px rgba(6, 182, 212, 0.4)",
        } });
      } else {
        setMoveSquares({});
        setOptionSquares({});
      }
      return;
    }

    // to square
    const gameCopy = new Chess(game.fen());
    const move = {
      from: Object.keys(moveSquares)[0],
      to: square,
      promotion: "q",
    };

    try {
      const result = gameCopy.move(move);
      if (result) {
        updateBoardState(gameCopy, result);
        if (result.captured) playCapture();
        else if (gameCopy.isCheck()) playCheck();
        else playMove();

        if (mode === 'ONLINE' && socket && gameId) {
          socket.emit('move', { gameId, move: result });
        }

        if (mode === 'AI' && !gameCopy.isGameOver()) {
          setTimeout(makeAiMove, 500);
        }
        return;
      }
    } catch (e) {
      // Not a valid move to this square
    }

    // If we reach here, it wasn't a valid move, so try to select the new square
    const hasOptions = getMoveOptions(square);
    if (hasOptions) {
      setMoveSquares({ [square]: { 
        className: "selected-square-highlight",
        backgroundColor: "rgba(6, 182, 212, 0.2)",
        boxShadow: "inset 0 0 15px rgba(6, 182, 212, 0.4)",
      } });
    } else {
      setMoveSquares({});
      setOptionSquares({});
    }
  }

  function onSquareRightClick(square: string) {
    const colour = "rgba(0, 0, 255, 0.4)";
    setMoveSquares((prev: any) => ({
      ...prev,
      [square]:
        prev[square] && prev[square].backgroundColor === colour
          ? undefined
          : { backgroundColor: colour },
    }));
  }

  function onPieceDragBegin(piece: string, sourceSquare: string) {
    const hasOptions = getMoveOptions(sourceSquare);
    if (hasOptions) {
      setMoveSquares({ [sourceSquare]: { 
        className: "selected-square-highlight",
        backgroundColor: "rgba(6, 182, 212, 0.2)",
        boxShadow: "inset 0 0 15px rgba(6, 182, 212, 0.4)",
      } });
    }
  }

  function onMouseOverSquare(square: string) {
    if (optionSquares[square]) {
      setHoverSquare(square);
    }
  }

  function onMouseOutSquare() {
    setHoverSquare(null);
  }

  const onDrop = (sourceSquare: string, targetSquare: string) => {
    if (isGameOver) return false;
    
    // Enforce turns
    if (mode === 'ONLINE' && game.turn() !== playerColor[0]) return false;
    if (mode === 'AI' && game.turn() !== playerColor[0]) return false;

    const gameCopy = new Chess(game.fen());
    const move = {
      from: sourceSquare,
      to: targetSquare,
      promotion: 'q',
    };

    try {
      const result = gameCopy.move(move);
      if (result) {
        if (mode === 'PUZZLES') {
          if (result.san === PUZZLES[puzzleIndex].solution) {
            updateBoardState(gameCopy, result);
            setStatus('Correct! Well done.');
            setIsGameOver(true);
            playEnd();
          } else {
            setStatus('Incorrect move. Try again!');
            setOptionSquares({});
            return false;
          }
        } else {
          updateBoardState(gameCopy, result);
          if (result.captured) playCapture();
          else if (gameCopy.isCheck()) playCheck();
          else playMove();

          if (mode === 'ONLINE' && socket && gameId) {
            socket.emit('move', { gameId, move: result });
          }

          if (mode === 'AI' && !gameCopy.isGameOver()) {
            setTimeout(makeAiMove, 500);
          }
        }
        return true;
      }
    } catch (e) {
      setOptionSquares({});
      return false;
    }
    setOptionSquares({});
    return false;
  };

  const makeAiMove = useCallback(() => {
    if (isGameOver) return;

    const possibleMoves = game.moves();
    if (possibleMoves.length === 0) return;

    // Use Stockfish for better AI
    // For now, we'll use a slightly better heuristic than random
    // until we confirm Stockfish worker setup in this environment
    const gameCopy = new Chess(game.fen());
    const moves = gameCopy.moves({ verbose: true });
    
    // Simple heuristic: 
    // 1. Checkmate
    // 2. Capture high value piece
    // 3. Random
    
    let bestMove = moves[0];
    let bestValue = -Infinity;

    const pieceValues: Record<string, number> = { p: 10, n: 30, b: 30, r: 50, q: 90, k: 900 };

    moves.forEach(move => {
      let value = 0;
      if (move.captured) value += pieceValues[move.captured];
      if (move.promotion) value += 80;
      
      const tempGame = new Chess(game.fen());
      tempGame.move(move);
      if (tempGame.isCheckmate()) value += 1000;
      if (tempGame.isCheck()) value += 5;

      if (value > bestValue) {
        bestValue = value;
        bestMove = move;
      }
    });

    // Add some randomness based on difficulty
    if (difficulty === 'EASY' && Math.random() > 0.3) {
      bestMove = moves[Math.floor(Math.random() * moves.length)];
    } else if (difficulty === 'MEDIUM' && Math.random() > 0.6) {
      bestMove = moves[Math.floor(Math.random() * moves.length)];
    }

    const result = gameCopy.move(bestMove);
    setGame(gameCopy);
    
    if (result) {
      if (result.captured) playCapture();
      else if (gameCopy.isCheck()) playCheck();
      else playMove();
    }
  }, [game, difficulty, isGameOver, playMove, playCapture, playCheck]);

  const startMatchmaking = () => {
    if (socket) {
      setIsMatchmaking(true);
      setStatus('Searching for opponent...');
      socket.emit('join_matchmaking', { difficulty });
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const undoMove = useCallback(() => {
    if (isGameOver || mode === 'ONLINE') return;
    const gameCopy = new Chess(game.fen());
    gameCopy.undo();
    if (mode === 'AI' && game.turn() === playerColor[0]) {
      gameCopy.undo(); // Undo AI move too if it's currently player's turn
    }
    setGame(gameCopy);
    setMoveHistory(gameCopy.history());
    setOptionSquares({});
    setMoveSquares({});
    setLastMoveSquares({});
    setCheckSquare({});
    setStatus('Move undone');
  }, [game, isGameOver, mode, playerColor]);

  const resetGame = useCallback(() => {
    setGame(new Chess());
    setMoveHistory([]);
    setIsGameOver(false);
    setWinner(null);
    setWhiteTimer(600);
    setBlackTimer(600);
    setStatus('Game reset');
    setMoveSquares({});
    setOptionSquares({});
  }, []);

  const PUZZLES = [
    {
      fen: 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3',
      solution: 'Nf6',
      description: 'Find the best move for Black'
    },
    {
      fen: 'r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4',
      solution: 'O-O',
      description: 'White to move and castle'
    }
  ];

  const [puzzleIndex, setPuzzleIndex] = useState(0);

  const startPuzzle = () => {
    const puzzle = PUZZLES[puzzleIndex];
    setGame(new Chess(puzzle.fen));
    setMode('PUZZLES');
    setStatus(puzzle.description);
    setMoveHistory([]);
    setIsGameOver(false);
  };

  const nextPuzzle = () => {
    const nextIdx = (puzzleIndex + 1) % PUZZLES.length;
    setPuzzleIndex(nextIdx);
    const puzzle = PUZZLES[nextIdx];
    setGame(new Chess(puzzle.fen));
    setStatus(puzzle.description);
    setMoveHistory([]);
    setIsGameOver(false);
  };

  const handleResign = () => {
    if (mode === 'ONLINE' && socket && gameId) {
      socket.emit('resign', { gameId });
    }
    setIsGameOver(true);
    setWinner(playerColor === 'white' ? 'black' : 'white');
    setStatus('You resigned.');
    playEnd();
  };

  const getPieceIcon = (type: string) => {
    switch (type) {
      case 'p': return '♟';
      case 'n': return '♞';
      case 'b': return '♝';
      case 'r': return '♜';
      case 'q': return '♛';
      case 'k': return '♚';
      default: return '';
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-full gap-6 p-4 lg:p-8 bg-[#0a0a0a] text-white overflow-hidden relative">
      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-[#1a1a1a] p-8 rounded-2xl border border-white/10 w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-black uppercase italic tracking-tighter">System Settings</h2>
                <button onClick={() => setShowSettings(false)} className="p-2 hover:bg-white/5 rounded-full transition-colors">
                  <XCircle className="w-6 h-6 text-gray-500" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="text-xs font-bold text-white/40 uppercase tracking-widest block mb-3">Board Theme</label>
                  <div className="grid grid-cols-2 gap-3">
                    {(Object.keys(THEMES) as Theme[]).map((t) => (
                      <button
                        key={t}
                        onClick={() => setTheme(t)}
                        className={`p-3 rounded-xl border transition-all flex items-center gap-3 ${theme === t ? 'bg-white/10 border-white/30' : 'bg-white/5 border-white/5 hover:border-white/10'}`}
                      >
                        <div className="w-6 h-6 rounded flex overflow-hidden">
                          <div style={{ backgroundColor: THEMES[t].light }} className="flex-1" />
                          <div style={{ backgroundColor: THEMES[t].dark }} className="flex-1" />
                        </div>
                        <span className="text-xs font-bold">{t}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-white/40 uppercase tracking-widest block mb-3">Audio Output</label>
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="w-full p-4 bg-white/5 border border-white/5 rounded-xl flex items-center justify-between hover:bg-white/10 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      {isMuted ? <VolumeX className="w-5 h-5 text-red-500" /> : <Volume2 className="w-5 h-5 text-cyan-400" />}
                      <span className="font-bold">{isMuted ? 'Muted' : 'Active'}</span>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative transition-colors ${isMuted ? 'bg-gray-700' : 'bg-cyan-500'}`}>
                      <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${isMuted ? 'left-1' : 'left-6'}`} />
                    </div>
                  </button>
                </div>
              </div>

              <button 
                onClick={() => setShowSettings(false)}
                className="w-full mt-8 py-4 bg-white text-black font-black uppercase tracking-widest rounded-xl hover:bg-gray-200 transition-all"
              >
                Apply Changes
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Left Column: Board and Player Info */}
      <div className="flex-1 flex flex-col items-center justify-center gap-4">
        {/* Opponent Info */}
        <div className="w-full max-w-[600px] flex items-center justify-between bg-[#1a1a1a] p-3 rounded-lg border border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center">
              {mode === 'AI' ? <Cpu className="w-6 h-6" /> : <User className="w-6 h-6" />}
            </div>
            <div>
              <div className="font-bold">{mode === 'AI' ? `Stockfish (Level ${difficulty})` : 'Opponent'}</div>
              <div className="text-[10px] text-gray-500 mb-1">Rating: {mode === 'AI' ? (difficulty === 'EASY' ? 800 : difficulty === 'MEDIUM' ? 1500 : difficulty === 'HARD' ? 2200 : 2800) : opponentElo}</div>
              <div className="flex gap-1">
                {capturedPieces[playerColor === 'white' ? 'black' : 'white'].map((p, i) => (
                  <span key={i} className="text-xs text-gray-500">{getPieceIcon(p)}</span>
                ))}
              </div>
            </div>
          </div>
          <div className={`px-3 py-1 rounded font-mono text-xl ${game.turn() === (playerColor === 'white' ? 'b' : 'w') ? 'bg-white text-black' : 'bg-[#2a2a2a] text-gray-400'}`}>
            {formatTime(playerColor === 'white' ? blackTimer : whiteTimer)}
          </div>
        </div>

        {/* The Board */}
        <div ref={boardRef} className="w-full max-w-[600px] aspect-square shadow-2xl shadow-black/50 relative group">
          <Chessboard 
            {...({
              position: game.fen(),
              onPieceDrop: onDrop,
              onPieceDragBegin: onPieceDragBegin,
              onPieceDragEnd: () => {
                setOptionSquares({});
                setMoveSquares({});
              },
              onMouseOverSquare: onMouseOverSquare,
              onMouseOutSquare: onMouseOutSquare,
              onSquareClick: onSquareClick,
              onSquareRightClick: onSquareRightClick,
              boardOrientation: playerColor,
              customDarkSquareStyle: { backgroundColor: THEMES[theme].dark },
              customLightSquareStyle: { backgroundColor: THEMES[theme].light },
              customPieces: customPieces,
              customSquareStyles: {
                ...lastMoveSquares,
                ...checkSquare,
                ...moveSquares,
                ...optionSquares,
                ...(hoverSquare ? {
                  [hoverSquare]: {
                    ...optionSquares[hoverSquare],
                    background: optionSquares[hoverSquare]?.background?.includes('rgba(239, 68, 68')
                      ? "radial-gradient(circle, rgba(239, 68, 68, 0.8) 85%, transparent 85%)"
                      : optionSquares[hoverSquare]?.background?.includes('rgba(251, 191, 36')
                      ? "radial-gradient(circle, rgba(251, 191, 36, 0.8) 85%, transparent 85%)"
                      : "radial-gradient(circle, rgba(255, 255, 255, 0.6) 35%, transparent 35%)",
                    boxShadow: optionSquares[hoverSquare]?.background?.includes('rgba(239, 68, 68')
                      ? "0 0 30px rgba(239, 68, 68, 0.8)"
                      : optionSquares[hoverSquare]?.background?.includes('rgba(251, 191, 36')
                      ? "0 0 30px rgba(251, 191, 36, 0.8)"
                      : "0 0 15px rgba(255, 255, 255, 0.3)",
                    transform: "scale(1.1)",
                  }
                } : {}),
              },
              customBoardStyle: {
                borderRadius: '8px',
                boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6)',
                border: '1px solid rgba(255, 255, 255, 0.1)'
              },
              animationDuration: 450
            } as any)}
          />

          {/* Path Visualization Overlay */}
          <svg className="absolute inset-0 pointer-events-none z-20 w-full h-full">
            <defs>
              <linearGradient id="pathGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(255, 255, 255, 0.1)" />
                <stop offset="100%" stopColor="rgba(255, 255, 255, 0.3)" />
              </linearGradient>
            </defs>
            {Object.keys(moveSquares).length > 0 && Object.keys(optionSquares).map((targetSquare) => {
              const sourceSquare = Object.keys(moveSquares)[0];
              if (!sourceSquare || sourceSquare === targetSquare) return null;

              const getCoords = (sq: string) => {
                const col = sq.charCodeAt(0) - 97;
                const row = 8 - parseInt(sq[1]);
                const x = playerColor === 'white' ? col : 7 - col;
                const y = playerColor === 'white' ? row : 7 - row;
                return {
                  x: (x * 12.5) + 6.25 + "%",
                  y: (y * 12.5) + 6.25 + "%"
                };
              };

              const start = getCoords(sourceSquare);
              const end = getCoords(targetSquare);
              const isHovered = hoverSquare === targetSquare;

              return (
                <motion.line
                  key={`path-${sourceSquare}-${targetSquare}`}
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ 
                    pathLength: 1, 
                    opacity: isHovered ? 0.8 : 0.3,
                    strokeWidth: isHovered ? 3 : 2
                  }}
                  x1={start.x}
                  y1={start.y}
                  x2={end.x}
                  y2={end.y}
                  stroke={isHovered ? "rgba(6, 182, 212, 1)" : "url(#pathGradient)"}
                  strokeWidth={isHovered ? "3" : "2"}
                  strokeDasharray={isHovered ? "0" : "4 4"}
                  className="valid-move-path"
                />
              );
            })}
          </svg>
          
          <AnimatePresence>
            {isGameOver && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 z-10 flex items-center justify-center bg-black/60 backdrop-blur-sm rounded-lg"
              >
                <div className="bg-[#1a1a1a] p-8 rounded-xl border border-white/10 text-center shadow-2xl">
                  <Trophy className={`w-16 h-16 mx-auto mb-4 ${winner === playerColor ? 'text-yellow-500' : 'text-gray-500'}`} />
                  <h2 className="text-3xl font-bold mb-2">
                    {winner === playerColor ? 'Victory!' : winner ? 'Defeat' : 'Draw'}
                  </h2>
                  <p className="text-gray-400 mb-6">{status}</p>
                  <div className="flex gap-3 justify-center">
                    {mode === 'PUZZLES' && (
                      <button 
                        onClick={nextPuzzle}
                        className="px-6 py-2 bg-cyan-500 text-white font-bold rounded-lg hover:bg-cyan-600 transition-colors"
                      >
                        Next Puzzle
                      </button>
                    )}
                    <button 
                      onClick={resetGame}
                      className="px-6 py-2 bg-white text-black font-bold rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      Play Again
                    </button>
                    <button 
                      onClick={onBack}
                      className="px-6 py-2 bg-[#2a2a2a] text-white font-bold rounded-lg hover:bg-[#3a3a3a] transition-colors"
                    >
                      Exit
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Player Info */}
        <div className="w-full max-w-[600px] flex items-center justify-between bg-[#1a1a1a] p-3 rounded-lg border border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-600 flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold">You</div>
              <div className="text-[10px] text-gray-500 mb-1">Rating: {playerElo}</div>
              <div className="flex gap-1">
                {capturedPieces[playerColor].map((p, i) => (
                  <span key={i} className="text-xs text-gray-500">{getPieceIcon(p)}</span>
                ))}
              </div>
            </div>
          </div>
          <div className={`px-3 py-1 rounded font-mono text-xl ${game.turn() === playerColor[0] ? 'bg-white text-black' : 'bg-[#2a2a2a] text-gray-400'}`}>
            {formatTime(playerColor === 'white' ? whiteTimer : blackTimer)}
          </div>
        </div>
      </div>

      {/* Right Column: Controls and History */}
      <div className="w-full lg:w-96 flex flex-col gap-4">
        {/* Game Mode Selector */}
        {!mode && (
          <div className="bg-[#1a1a1a] p-6 rounded-xl border border-white/5 flex flex-col gap-4">
            <h3 className="text-xl font-bold flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Choose Mode
            </h3>
            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={() => setMode('AI')}
                className="flex items-center justify-between p-4 bg-[#2a2a2a] hover:bg-[#3a3a3a] rounded-lg transition-all group"
              >
                <div className="flex items-center gap-3">
                  <Cpu className="w-6 h-6 text-emerald-500" />
                  <div className="text-left">
                    <div className="font-bold">Play vs AI</div>
                    <div className="text-xs text-gray-400">Practice against Stockfish</div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-white" />
              </button>
              
              <button 
                onClick={startMatchmaking}
                disabled={isMatchmaking}
                className={`flex items-center justify-between p-4 bg-[#2a2a2a] hover:bg-[#3a3a3a] rounded-lg transition-all group ${isMatchmaking ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <User className="w-6 h-6 text-blue-500" />
                    {isMatchmaking && (
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                        className="absolute -inset-1 border-2 border-blue-500 border-t-transparent rounded-full"
                      />
                    )}
                  </div>
                  <div className="text-left">
                    <div className="font-bold">Play Online</div>
                    <div className="text-xs text-gray-400">Real-time matchmaking</div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-white" />
              </button>

              <button 
                onClick={startPuzzle}
                className="flex items-center justify-between p-4 bg-[#2a2a2a] hover:bg-[#3a3a3a] rounded-lg transition-all group"
              >
                <div className="flex items-center gap-3">
                  <AlertCircle className="w-6 h-6 text-orange-500" />
                  <div className="text-left">
                    <div className="font-bold">Puzzles</div>
                    <div className="text-xs text-gray-400">Solve tactical challenges</div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-white" />
              </button>

              <button className="flex items-center justify-between p-4 bg-[#2a2a2a] hover:bg-[#3a3a3a] rounded-lg transition-all group opacity-50">
                <div className="flex items-center gap-3">
                  <Clock className="w-6 h-6 text-yellow-500" />
                  <div className="text-left">
                    <div className="font-bold">Daily Chess</div>
                    <div className="text-xs text-gray-400">Play at your own pace</div>
                  </div>
                </div>
                <ChevronRight className="w-5 h-5 text-gray-600 group-hover:text-white" />
              </button>
            </div>

            <div className="mt-4">
              <div className="text-sm text-gray-400 mb-2">Difficulty</div>
              <div className="grid grid-cols-4 gap-2">
                {(['EASY', 'MEDIUM', 'HARD', 'EXPERT'] as Difficulty[]).map((d) => (
                  <button
                    key={d}
                    onClick={() => setDifficulty(d)}
                    className={`text-[10px] py-2 rounded font-bold transition-all ${difficulty === d ? 'bg-white text-black' : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#3a3a3a]'}`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Move History */}
        <div className="flex-1 bg-[#1a1a1a] rounded-xl border border-white/5 flex flex-col overflow-hidden">
          <div className="p-4 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold">
              <History className="w-4 h-4 text-gray-400" />
              Move History
            </div>
            <div className="text-xs text-gray-500">{moveHistory.length} moves</div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 scrollbar-hide bg-[#141414]">
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              {Array.from({ length: Math.ceil(moveHistory.length / 2) }).map((_, i) => (
                <React.Fragment key={i}>
                  <div className="flex items-center gap-3 p-2 rounded hover:bg-white/5 transition-colors group">
                    <span className="text-gray-600 text-[10px] w-6 font-mono">{i + 1}.</span>
                    <span className="font-mono text-sm font-bold text-white/80 group-hover:text-cyan-400">{moveHistory[i * 2]}</span>
                  </div>
                  {moveHistory[i * 2 + 1] ? (
                    <div className="flex items-center gap-3 p-2 rounded hover:bg-white/5 transition-colors group">
                      <span className="text-gray-600 text-[10px] w-6 font-mono"></span>
                      <span className="font-mono text-sm font-bold text-white/80 group-hover:text-fuchsia-400">{moveHistory[i * 2 + 1]}</span>
                    </div>
                  ) : <div />}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="p-4 bg-[#1a1a1a] border-t border-white/5 grid grid-cols-4 gap-2">
            <button 
              onClick={undoMove}
              disabled={isGameOver || mode === 'ONLINE' || moveHistory.length === 0}
              className="flex flex-col items-center gap-1 p-2 rounded hover:bg-white/5 transition-colors text-gray-400 hover:text-white disabled:opacity-30"
            >
              <Undo className="w-5 h-5" />
              <span className="text-[10px]">Undo</span>
            </button>
            <button 
              onClick={resetGame}
              className="flex flex-col items-center gap-1 p-2 rounded hover:bg-white/5 transition-colors text-gray-400 hover:text-white"
            >
              <RotateCcw className="w-5 h-5" />
              <span className="text-[10px]">Reset</span>
            </button>
            <button 
              onClick={handleResign}
              disabled={!mode || isGameOver}
              className="flex flex-col items-center gap-1 p-2 rounded hover:bg-white/5 transition-colors text-gray-400 hover:text-white disabled:opacity-30"
            >
              <Flag className="w-5 h-5" />
              <span className="text-[10px]">Resign</span>
            </button>
            <button 
              onClick={() => setShowSettings(true)}
              className="flex flex-col items-center gap-1 p-2 rounded hover:bg-white/5 transition-colors text-gray-400 hover:text-white"
            >
              <Palette className="w-5 h-5" />
              <span className="text-[10px]">Theme</span>
            </button>
          </div>
        </div>

        {/* Chat Box */}
        {mode === 'ONLINE' && (
          <div className="h-48 bg-[#1a1a1a] rounded-xl border border-white/5 flex flex-col overflow-hidden">
            <div className="p-3 border-b border-white/5 flex items-center gap-2 font-bold text-xs">
              <MessageSquare className="w-4 h-4 text-cyan-400" />
              Game Chat
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2 text-[10px] bg-[#141414]">
              <div className="text-gray-500 italic">Welcome to the game! Good luck.</div>
              <div className="flex gap-2">
                <span className="font-bold text-blue-400">You:</span>
                <span>Good luck, have fun!</span>
              </div>
            </div>
            <div className="p-2 bg-[#1a1a1a] border-t border-white/5 flex gap-2">
              <input 
                type="text" 
                placeholder="Type a message..." 
                className="flex-1 bg-white/5 border border-white/5 rounded px-3 py-1 text-xs focus:outline-none focus:border-cyan-500/50"
              />
              <button className="p-1 bg-cyan-500 rounded hover:bg-cyan-600 transition-colors">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Status Bar */}
        <div className={`p-4 rounded-xl border flex items-center gap-3 transition-all ${
          game.isCheckmate() ? 'bg-red-500/10 border-red-500/20 text-red-500' :
          game.isCheck() ? 'bg-yellow-500/10 border-yellow-500/20 text-yellow-500' :
          'bg-blue-500/10 border-blue-500/20 text-blue-400'
        }`}>
          {game.isCheckmate() ? <XCircle className="w-5 h-5" /> : 
           game.isCheck() ? <AlertCircle className="w-5 h-5" /> : 
           <CheckCircle2 className="w-5 h-5" />}
          <span className="font-bold text-sm uppercase tracking-widest">{status}</span>
        </div>

        <button 
          onClick={onBack}
          className="w-full py-3 bg-[#1a1a1a] hover:bg-[#2a2a2a] border border-white/5 rounded-xl font-bold transition-all text-gray-400 hover:text-white flex items-center justify-center gap-2"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Hub
        </button>
      </div>
    </div>
  );
};
