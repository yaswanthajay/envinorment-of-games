import React from 'react';
import { motion } from 'motion/react';
import { 
  Settings, 
  Star, 
  Mail, 
  Plus, 
  Play, 
  Users, 
  Gamepad2, 
  Shield, 
  ArrowLeft,
  Power,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Info,
  Zap,
  Target,
  Activity,
  Trophy,
  BarChart3,
  User,
  Globe,
  Map as MapIcon
} from 'lucide-react';

export interface World {
  id: string;
  name: string;
  description: string;
  image: string;
  theme: {
    wall: string;
    floor: string;
    ceiling: string;
    accent: string;
  };
}

export const WORLDS: World[] = [
  {
    id: '1',
    name: 'Abandoned Hallway',
    description: 'A dark, dilapidated corridor with peeling wallpaper and flickering lights. Perfect for close-quarters combat.',
    image: 'https://picsum.photos/seed/hallway/800/600',
    theme: {
      wall: '#3e2723',
      floor: '#212121',
      ceiling: '#1a1a1a',
      accent: '#4e342e'
    }
  },
  {
    id: '2',
    name: 'Dilapidated Office',
    description: 'A messy office sector with scattered desks, old sofas, and blueish walls. Plenty of cover but limited visibility.',
    image: 'https://picsum.photos/seed/office/800/600',
    theme: {
      wall: '#455a64',
      floor: '#37474f',
      ceiling: '#cfd8dc',
      accent: '#263238'
    }
  },
  {
    id: '3',
    name: 'Messy Room',
    description: 'A cluttered room with bookshelves and debris. The classic training ground for elite cyber units.',
    image: 'https://picsum.photos/seed/room/800/600',
    theme: {
      wall: '#d2b48c',
      floor: '#8b4513',
      ceiling: '#f5f5dc',
      accent: '#5d4037'
    }
  }
];

export interface Operator {
  id: string;
  name: string;
  codename: string;
  role: string;
  description: string;
  stats: {
    damage: number;
    armor: number;
    speed: number;
    accuracy: number;
  };
  image: string;
  thumbnail: string;
}

export const OPERATORS: Operator[] = [
  {
    id: '1',
    name: 'Intel Unit "Frost"',
    codename: 'FROST',
    role: 'Cyber Intelligence',
    description: 'Cyber intelligence specialist with advanced reconnaissance gear. Master of electronic warfare and battlefield analysis. Enhanced optical systems and tech integration enable superior target acquisition and tactical superiority.',
    stats: { damage: 165, armor: 138, speed: 195, accuracy: 198 },
    image: 'https://picsum.photos/seed/frost/800/800',
    thumbnail: 'https://picsum.photos/seed/frost/100/100'
  },
  {
    id: '2',
    name: 'Heavy Unit "Titan"',
    codename: 'TITAN',
    role: 'Frontline Assault',
    description: 'Heavily armored combatant designed for high-intensity conflict. Equipped with reinforced plating and heavy weaponry. Titan excels at breaking enemy lines and absorbing significant damage while maintaining offensive pressure.',
    stats: { damage: 190, armor: 195, speed: 120, accuracy: 150 },
    image: 'https://picsum.photos/seed/titan/800/800',
    thumbnail: 'https://picsum.photos/seed/titan/100/100'
  },
  {
    id: '3',
    name: 'Stealth Unit "Ghost"',
    codename: 'GHOST',
    role: 'Infiltration',
    description: 'Specialized in covert operations and silent eliminations. Ghost utilizes active camouflage and silenced weaponry to strike from the shadows. High mobility and precision make them the ultimate predator on the battlefield.',
    stats: { damage: 175, armor: 110, speed: 200, accuracy: 190 },
    image: 'https://picsum.photos/seed/ghost/800/800',
    thumbnail: 'https://picsum.photos/seed/ghost/100/100'
  },
  {
    id: '4',
    name: 'Support Unit "Nova"',
    codename: 'NOVA',
    role: 'Tactical Support',
    description: 'Provides critical battlefield support through advanced healing tech and supply drops. Nova ensures the squad stays operational under fire. Her tactical drones provide real-time intel and defensive barriers.',
    stats: { damage: 140, armor: 150, speed: 160, accuracy: 170 },
    image: 'https://picsum.photos/seed/nova/800/800',
    thumbnail: 'https://picsum.photos/seed/nova/100/100'
  }
];

interface LobbyProps {
  onPlay: () => void;
  onSelectMode: () => void;
  userName: string;
  currency: number;
}

export const CyberStrikeLobby: React.FC<LobbyProps> = ({ onPlay, onSelectMode, userName, currency }) => {
  return (
    <div className="relative w-full h-[700px] bg-[#2c2c2c] overflow-hidden font-sans text-white select-none">
      {/* Background Stage */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-[800px] h-[800px] bg-gradient-to-b from-transparent to-black/20 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-20 w-[600px] h-[100px] bg-black/40 rounded-[100%] blur-xl" />
        {/* Character Placeholder */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          className="relative z-10 h-[80%] aspect-[3/4] flex items-center justify-center"
        >
          <img 
            src="https://picsum.photos/seed/soldier/600/800" 
            alt="Soldier"
            className="h-full object-contain drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>

      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-black/60 to-transparent flex items-center justify-between px-6 z-30">
        <div className="flex items-center gap-3">
          <button className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center hover:bg-red-700 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex items-center gap-2 bg-black/40 px-3 py-1 rounded-md border border-white/10">
            <div className="w-8 h-8 rounded-full bg-slate-700 border border-white/20 overflow-hidden">
              <img src="https://picsum.photos/seed/avatar/100/100" alt="Avatar" referrerPolicy="no-referrer" />
            </div>
            <span className="font-black text-sm tracking-tighter uppercase">{userName}</span>
          </div>
        </div>

        <div className="absolute left-1/2 -translate-x-1/2 top-2 bg-white text-black text-[10px] font-bold px-12 py-2 rounded shadow-lg border border-black/10">
          GOOGLE AD 320x50
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-black/60 px-4 py-1.5 rounded-md border border-white/10">
            <div className="w-5 h-5 bg-yellow-500 rounded-full flex items-center justify-center text-[10px] font-black text-black">G</div>
            <span className="font-mono font-bold text-yellow-500">{currency.toLocaleString()}</span>
            <button className="ml-2 w-5 h-5 bg-white/10 hover:bg-white/20 rounded flex items-center justify-center">
              <Plus className="w-3 h-3" />
            </button>
          </div>
          <div className="flex gap-2">
            <button className="w-10 h-10 bg-black/40 hover:bg-black/60 rounded-md border border-white/10 flex flex-col items-center justify-center gap-0.5">
              <Settings className="w-4 h-4" />
              <span className="text-[7px] font-bold uppercase">Setting</span>
            </button>
            <button className="w-10 h-10 bg-black/40 hover:bg-black/60 rounded-md border border-white/10 flex flex-col items-center justify-center gap-0.5">
              <Star className="w-4 h-4" />
              <span className="text-[7px] font-bold uppercase">Rate Us</span>
            </button>
            <button className="relative w-10 h-10 bg-black/40 hover:bg-black/60 rounded-md border border-white/10 flex flex-col items-center justify-center gap-0.5">
              <Mail className="w-4 h-4" />
              <span className="text-[7px] font-bold uppercase">Mail</span>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-600 rounded-full border border-white/20 flex items-center justify-center text-[6px] font-bold">1</div>
            </button>
          </div>
        </div>
      </div>

      {/* Left Side Controls */}
      <div className="absolute left-6 top-32 z-30 flex flex-col gap-4">
        <button className="group relative flex flex-col items-center">
          <div className="w-16 h-16 bg-white rounded-full border-4 border-red-600 flex items-center justify-center text-black font-black text-xl shadow-xl group-hover:scale-110 transition-transform relative">
            ADS
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-1 bg-red-600 rotate-45" />
          </div>
          <div className="mt-1 bg-red-600 px-4 py-0.5 text-[10px] font-black uppercase italic tracking-tighter">Remove Ads</div>
        </button>

        <div className="w-48 bg-black/60 border border-white/10 rounded-lg overflow-hidden shadow-2xl">
          <div className="relative h-24 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center p-4">
            <div className="absolute top-0 left-0 bg-yellow-500 text-black text-[8px] font-black px-2 py-0.5 flex items-center gap-1">
              <Play className="w-2 h-2 fill-current" /> AD
            </div>
            <img src="https://picsum.photos/seed/gun/200/100" alt="Gun" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          <button className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-black uppercase tracking-tighter border-t border-white/10">
            Get This Gun
          </button>
        </div>

        <div className="w-48 bg-black/60 border border-white/10 rounded-lg overflow-hidden shadow-2xl">
          <div className="relative h-24 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center p-4">
            <div className="absolute top-0 left-0 bg-yellow-500 text-black text-[8px] font-black px-2 py-0.5 flex items-center gap-1">
              <Play className="w-2 h-2 fill-current" /> AD
            </div>
            <div className="flex items-end gap-1">
              <div className="w-8 h-12 bg-yellow-500/20 border border-yellow-500/40 rounded" />
              <div className="w-10 h-16 bg-yellow-500/40 border border-yellow-500/60 rounded" />
              <div className="w-12 h-20 bg-yellow-500/60 border border-yellow-500 rounded" />
            </div>
          </div>
          <button className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-xs font-black uppercase tracking-tighter border-t border-white/10">
            Get 1000 Coins
          </button>
        </div>
      </div>

      {/* Right Side Controls */}
      <div className="absolute right-6 top-32 z-30 flex flex-col gap-4">
        <button 
          onClick={onSelectMode}
          className="w-64 h-24 bg-black/60 border border-white/10 rounded-lg overflow-hidden relative group shadow-2xl"
        >
          <img src="https://picsum.photos/seed/multi/300/150" alt="Multiplayer" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent" />
          <div className="absolute top-2 left-2 flex items-center gap-2">
            <div className="w-1 h-4 bg-yellow-500" />
            <span className="text-xs font-black uppercase tracking-widest text-yellow-500">Multiplayer</span>
          </div>
        </button>

        <button 
          onClick={onSelectMode}
          className="w-64 h-24 bg-black/60 border border-white/10 rounded-lg overflow-hidden relative group shadow-2xl"
        >
          <img src="https://picsum.photos/seed/campaign/300/150" alt="Campaign" className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent" />
          <div className="absolute top-2 left-2 flex items-center gap-2">
            <div className="w-1 h-4 bg-yellow-500" />
            <span className="text-xs font-black uppercase tracking-widest text-yellow-500">Campaign</span>
          </div>
        </button>
      </div>

      {/* Bottom Controls */}
      <div className="absolute bottom-6 left-6 z-30">
        <button className="flex items-center gap-3 group">
          <div className="w-12 h-12 bg-black/60 border border-white/10 rounded-lg flex items-center justify-center group-hover:bg-white group-hover:text-black transition-colors">
            <Users className="w-6 h-6" />
          </div>
          <span className="font-black text-xl uppercase tracking-tighter italic group-hover:text-yellow-500 transition-colors">Weapons</span>
          <div className="w-3 h-3 bg-red-600 rounded-full border-2 border-white animate-pulse" />
        </button>
      </div>

      <div className="absolute bottom-6 right-6 z-30">
        <button 
          onClick={onPlay}
          className="w-64 h-16 bg-gradient-to-r from-orange-500 to-yellow-500 rounded-lg flex items-center justify-between px-8 group hover:from-orange-600 hover:to-yellow-600 transition-all shadow-[0_0_30px_rgba(249,115,22,0.4)]"
        >
          <span className="text-3xl font-black uppercase italic tracking-tighter text-black">Play</span>
          <Play className="w-10 h-10 fill-black text-black group-hover:translate-x-2 transition-transform" />
        </button>
      </div>
    </div>
  );
};

export const CyberStrikeModeSelection: React.FC<{ onBack: () => void, onStart: (mode: string) => void }> = ({ onBack, onStart }) => {
  return (
    <div className="relative w-full h-[700px] bg-[#0a0a0a] overflow-hidden font-sans text-white select-none flex flex-col">
      {/* Header */}
      <div className="h-20 bg-black/80 border-b border-white/5 flex items-center justify-between px-8 z-30">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="w-10 h-10 hover:bg-white/10 rounded-full flex items-center justify-center transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-4xl font-black tracking-tighter italic uppercase">Cyber Strike</h1>
        </div>
        <button className="w-10 h-10 hover:bg-red-600/20 rounded-full flex items-center justify-center transition-colors">
          <Power className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 flex p-8 gap-8">
        {/* Main Feature */}
        <div className="flex-[2] flex flex-col gap-6">
          <div className="relative flex-1 rounded-xl overflow-hidden border border-white/10 group">
            <img 
              src="https://picsum.photos/seed/horde/1200/800" 
              alt="Cyber Horde" 
              className="absolute inset-0 w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
            
            <div className="absolute bottom-8 left-8 right-8">
              <div className="flex gap-4 mb-6">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className={`w-16 h-12 rounded border-2 ${i === 1 ? 'border-orange-500' : 'border-white/20'} overflow-hidden`}>
                    <img src={`https://picsum.photos/seed/thumb${i}/100/100`} alt="thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
              <h2 className="text-3xl font-black text-orange-500 uppercase mb-2">New Game Mode: Cyber Horde</h2>
              <p className="text-sm text-white/60 max-w-xl leading-relaxed">
                We've always known Blackwood would stop at nothing to achieve their goals, but we didn't dare to imagine what they were truly capable of. Until now. To face this new evil, we don't just need soldiers. We need warriors. Are you ready? It's time to find out.
              </p>
            </div>
          </div>
        </div>

        {/* Side Modes */}
        <div className="flex-1 flex flex-col gap-4">
          {[
            { id: 'CO-OP', img: 'coop', label: 'CO-OP' },
            { id: 'VERSUS', img: 'versus', label: 'VERSUS' },
            { id: 'SPECIAL', img: 'special', label: 'SPECIAL OPERATIONS' }
          ].map(mode => (
            <button 
              key={mode.id}
              onClick={() => onStart(mode.id)}
              className="relative h-1/3 rounded-xl overflow-hidden border border-white/10 group"
            >
              <img 
                src={`https://picsum.photos/seed/${mode.img}/600/400`} 
                alt={mode.label} 
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent" />
              <div className="absolute inset-0 flex items-center px-8">
                <div className="flex flex-col items-start gap-1">
                  <span className="text-orange-500 font-black text-xl italic uppercase tracking-tighter">Play</span>
                  <span className="text-white font-black text-2xl uppercase tracking-tighter">{mode.label}</span>
                </div>
              </div>
              <div className="absolute inset-0 bg-orange-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export const CyberStrikeSquadLobby: React.FC<{ 
  onBack: () => void, 
  onReady: () => void,
  onSelectPlayer: (operator: Operator) => void
}> = ({ onBack, onReady, onSelectPlayer }) => {
  const squad = [
    { id: '1', name: '[Epic] Frost', status: 'Not Ready', operator: OPERATORS[0] },
    { id: '2', name: 'DarkVeil', status: 'Ready', isLeader: true, operator: OPERATORS[1] },
    { id: '3', name: 'spinalfluid', status: 'Not Ready', operator: OPERATORS[2] },
    { id: '4', name: 'RZE', status: 'Not Ready', operator: OPERATORS[3], isSelf: true }
  ];

  return (
    <div className="relative w-full h-[700px] bg-[#1a2a3a] overflow-hidden font-sans text-white select-none flex flex-col">
      {/* Background Grid */}
      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
      
      {/* Top Navigation */}
      <div className="h-16 flex items-center justify-center gap-4 z-30 bg-black/40 backdrop-blur-sm border-b border-white/5">
        <button className="px-6 py-2 bg-yellow-500 text-black font-black uppercase tracking-tighter italic">Lobby</button>
        <button className="px-6 py-2 hover:bg-white/10 font-black uppercase tracking-tighter italic transition-colors">Leaderboards</button>
        <button className="px-6 py-2 hover:bg-white/10 font-black uppercase tracking-tighter italic transition-colors">Stats</button>
      </div>

      {/* Main Lobby Area */}
      <div className="flex-1 relative flex items-center justify-center gap-12 px-12">
        <div className="absolute top-8 left-8">
          <h2 className="text-4xl font-black uppercase italic tracking-tighter">Battle Royale</h2>
        </div>

        {squad.map((member, i) => (
          <div key={member.id} className="relative flex flex-col items-center group">
            {/* Platform */}
            <div className="absolute -bottom-4 w-48 h-12 bg-black/40 rounded-[100%] border-2 border-white/10 flex items-center justify-center">
              <div className={`w-40 h-8 rounded-[100%] blur-md ${member.isSelf ? 'bg-cyan-500/40' : 'bg-white/10'}`} />
            </div>

            {/* Character Info */}
            <div className="absolute -top-16 text-center w-48">
              <div className="flex items-center justify-center gap-1 mb-1">
                {member.isLeader && <div className="w-3 h-3 bg-yellow-500 rounded-sm rotate-45 mb-1" />}
                <span className="font-black text-sm uppercase tracking-tighter">{member.name}</span>
              </div>
              <span className={`text-xs font-bold uppercase ${member.status === 'Ready' ? 'text-green-500' : 'text-red-500'}`}>
                {member.status}
              </span>
            </div>

            {/* Character Model Placeholder */}
            <motion.div 
              whileHover={{ scale: 1.05 }}
              onClick={() => onSelectPlayer(member.operator)}
              className="relative z-10 w-48 h-80 cursor-pointer"
            >
              <img 
                src={member.operator.image} 
                alt={member.name}
                className={`w-full h-full object-contain drop-shadow-2xl transition-all ${member.isSelf ? 'brightness-110' : 'brightness-75 group-hover:brightness-100'}`}
                referrerPolicy="no-referrer"
              />
              {member.isSelf && (
                <div className="absolute inset-0 bg-cyan-500/20 blur-2xl -z-10 rounded-full animate-pulse" />
              )}
            </motion.div>
          </div>
        ))}

        {/* Right Side Controls */}
        <div className="absolute bottom-8 right-8 flex flex-col gap-4 w-64">
          <div className="bg-black/60 backdrop-blur-md border border-white/10 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black uppercase text-white/40">Match Type</span>
              <div className="flex items-center gap-2">
                <ChevronLeft className="w-4 h-4 text-white/40" />
                <span className="text-sm font-black uppercase italic">Squad</span>
                <ChevronRight className="w-4 h-4 text-white/40" />
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-black uppercase text-white/40">Squad Fill</span>
              <div className="flex items-center gap-2">
                <ChevronLeft className="w-4 h-4 text-white/40" />
                <span className="text-sm font-black uppercase italic">Fill</span>
                <ChevronRight className="w-4 h-4 text-white/40" />
              </div>
            </div>
          </div>

          <button 
            onClick={onReady}
            className="w-full py-4 bg-gradient-to-r from-slate-200 to-white text-black font-black text-2xl uppercase italic tracking-tighter rounded shadow-[0_0_30px_rgba(255,255,255,0.2)] hover:scale-105 transition-transform"
          >
            Ready
          </button>
        </div>

        {/* Chat Area */}
        <div className="absolute bottom-8 left-8 w-80">
          <div className="bg-black/40 backdrop-blur-sm p-4 rounded-lg border border-white/5 h-32 overflow-hidden flex flex-col justify-end gap-1">
            <div className="text-[10px] font-bold"><span className="text-white/40">[2:56 PM]</span> <span className="text-green-500">Party: [Epic] Frost left the party.</span></div>
            <div className="text-[10px] font-bold"><span className="text-white/40">[2:56 PM]</span> <span className="text-green-500">Party: [Epic] Frost joined the party.</span></div>
            <div className="text-[10px] font-bold"><span className="text-white/40">[2:56 PM]</span> <span className="text-green-500">Party: spinalfluid joined the party.</span></div>
          </div>
          <div className="mt-2 flex items-center gap-2 bg-black/60 px-4 py-2 rounded border border-white/10">
            <span className="text-[10px] font-black uppercase text-green-500">Party</span>
            <span className="text-[10px] font-bold text-white/40">Enter to chat or "/" for options</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export const CyberStrikeWorldSelection: React.FC<{ onBack: () => void, onSelect: (world: World) => void }> = ({ onBack, onSelect }) => {
  return (
    <div className="relative w-full h-[700px] bg-[#050505] overflow-hidden font-sans text-white select-none flex flex-col">
      {/* Header */}
      <div className="h-20 bg-black/80 border-b border-white/5 flex items-center justify-between px-8 z-30">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="w-10 h-10 hover:bg-white/10 rounded-full flex items-center justify-center transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-4xl font-black tracking-tighter italic uppercase">Select World</h1>
        </div>
        <div className="flex items-center gap-2 bg-red-600/20 px-4 py-1 rounded border border-red-600/40">
          <Globe className="w-4 h-4 text-red-500" />
          <span className="text-xs font-black uppercase tracking-widest">Sector Selection</span>
        </div>
      </div>

      <div className="flex-1 flex p-8 gap-8">
        {WORLDS.map((world) => (
          <motion.button 
            key={world.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => onSelect(world)}
            className="flex-1 relative rounded-2xl overflow-hidden border border-white/10 group bg-black/40"
          >
            <img 
              src={world.image} 
              alt={world.name} 
              className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-60 group-hover:scale-110 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            
            <div className="absolute inset-0 p-8 flex flex-col justify-end">
              <div className="flex items-center gap-2 mb-2">
                <MapIcon className="w-5 h-5 text-red-500" />
                <span className="text-xs font-black uppercase tracking-[0.3em] text-red-500">World {world.id}</span>
              </div>
              <h2 className="text-3xl font-black uppercase italic tracking-tighter mb-4 group-hover:text-red-500 transition-colors">{world.name}</h2>
              <p className="text-sm text-white/60 leading-relaxed font-mono italic mb-6">
                {world.description}
              </p>
              <div className="flex gap-2">
                <div className="w-8 h-8 rounded border border-white/20" style={{ backgroundColor: world.theme.wall }} />
                <div className="w-8 h-8 rounded border border-white/20" style={{ backgroundColor: world.theme.floor }} />
                <div className="w-8 h-8 rounded border border-white/20" style={{ backgroundColor: world.theme.accent }} />
              </div>
            </div>

            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="bg-red-600 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Select</div>
            </div>
          </motion.button>
        ))}
      </div>

      {/* Background Ambience */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-red-600/5 blur-[120px] -z-10" />
    </div>
  );
};

export const CyberStrikeOperatorDetails: React.FC<{ 
  operator: Operator, 
  onBack: () => void,
  onSelect: (operator: Operator) => void
}> = ({ operator, onBack, onSelect }) => {
  const [selectedOp, setSelectedOp] = React.useState(operator);

  return (
    <div className="relative w-full h-[700px] bg-[#050505] overflow-hidden font-sans text-white select-none flex">
      {/* Sidebar */}
      <div className="w-20 bg-black/80 border-r border-white/5 flex flex-col items-center py-8 gap-6 z-30">
        <div className="w-10 h-10 bg-red-600 rounded flex items-center justify-center mb-4">
          <Shield className="w-6 h-6" />
        </div>
        <button className="w-10 h-10 hover:bg-white/10 rounded flex items-center justify-center transition-colors"><Gamepad2 className="w-6 h-6 text-white/40" /></button>
        <button className="w-10 h-10 bg-red-600/20 border border-red-600/40 rounded flex items-center justify-center transition-colors"><Users className="w-6 h-6 text-red-500" /></button>
        <button className="w-10 h-10 hover:bg-white/10 rounded flex items-center justify-center transition-colors"><Mail className="w-6 h-6 text-white/40" /></button>
        <button className="w-10 h-10 hover:bg-white/10 rounded flex items-center justify-center transition-colors"><Settings className="w-6 h-6 text-white/40" /></button>
        
        <div className="mt-auto flex flex-col gap-4">
          <button className="w-10 h-10 hover:bg-white/10 rounded flex items-center justify-center transition-colors"><Power className="w-6 h-6 text-white/40" /></button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative">
        {/* Top Header */}
        <div className="h-16 flex items-center justify-center gap-12 border-b border-white/5 bg-black/40 backdrop-blur-sm z-20">
          <button className="text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white transition-colors">Campaign</button>
          <button className="text-[10px] font-black uppercase tracking-widest text-red-500 border-b-2 border-red-500 h-full px-4">Operators</button>
          <button className="text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white transition-colors">Loadout</button>
          <button className="text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white transition-colors">Missions</button>
          <button className="text-[10px] font-black uppercase tracking-widest text-white/40 hover:text-white transition-colors">Multiplayer</button>
        </div>

        <div className="flex-1 flex p-12 gap-12 relative">
          {/* Operator List */}
          <div className="flex flex-col gap-3 z-20">
            {OPERATORS.map((op) => (
              <button 
                key={op.id}
                onClick={() => setSelectedOp(op)}
                className={`w-16 h-16 rounded-lg border-2 overflow-hidden transition-all ${selectedOp.id === op.id ? 'border-red-600 scale-110 shadow-[0_0_20px_rgba(220,38,38,0.4)]' : 'border-white/10 hover:border-white/40'}`}
              >
                <img src={op.thumbnail} alt={op.codename} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>

          {/* Center Portrait */}
          <div className="flex-1 flex flex-col items-center justify-center relative z-10">
            <div className="relative w-80 h-80 mb-8">
              <div className="absolute inset-0 border-2 border-red-600/20 rounded-xl" />
              <div className="absolute -top-2 -left-2 w-8 h-8 border-t-2 border-l-2 border-red-600" />
              <div className="absolute -bottom-2 -right-2 w-8 h-8 border-b-2 border-r-2 border-red-600" />
              <img 
                src={selectedOp.image} 
                alt={selectedOp.codename} 
                className="w-full h-full object-cover rounded-lg shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-4 right-4 bg-red-600/80 backdrop-blur-sm px-3 py-1 rounded text-[8px] font-black uppercase tracking-widest">
                Tech Unit
              </div>
            </div>

            <div className="text-center">
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/40 mb-2 block">Codename</span>
              <h2 className="text-5xl font-black uppercase italic tracking-tighter mb-1">{selectedOp.codename}</h2>
              <p className="text-sm text-white/60 font-mono italic">{selectedOp.name}</p>
            </div>

            <div className="flex gap-4 mt-8">
              <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col items-center min-w-[80px]">
                <span className="text-lg font-black">{selectedOp.stats.damage}</span>
                <span className="text-[8px] font-black uppercase text-white/40">Dmg</span>
              </div>
              <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col items-center min-w-[80px]">
                <span className="text-lg font-black">{selectedOp.stats.armor}</span>
                <span className="text-[8px] font-black uppercase text-white/40">Arm</span>
              </div>
              <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col items-center min-w-[80px]">
                <span className="text-lg font-black">{selectedOp.stats.speed}</span>
                <span className="text-[8px] font-black uppercase text-white/40">Spd</span>
              </div>
              <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col items-center min-w-[80px]">
                <span className="text-lg font-black">{selectedOp.stats.accuracy}</span>
                <span className="text-[8px] font-black uppercase text-white/40">Acc</span>
              </div>
            </div>
          </div>

          {/* Stats & Select */}
          <div className="w-80 flex flex-col gap-8 z-20">
            <div className="bg-black/60 backdrop-blur-md border border-white/10 p-8 rounded-2xl flex-1">
              <div className="flex items-center gap-2 mb-6">
                <Activity className="w-4 h-4 text-red-500" />
                <h3 className="text-xs font-black uppercase tracking-widest">Combat Statistics</h3>
              </div>
              
              <div className="space-y-6">
                {[
                  { label: 'Damage Output', value: selectedOp.stats.damage, icon: <Zap className="w-3 h-3" /> },
                  { label: 'Armor Rating', value: selectedOp.stats.armor, icon: <Shield className="w-3 h-3" /> },
                  { label: 'Movement Speed', value: selectedOp.stats.speed, icon: <Activity className="w-3 h-3" /> },
                  { label: 'Accuracy', value: selectedOp.stats.accuracy, icon: <Target className="w-3 h-3" /> }
                ].map((stat) => (
                  <div key={stat.label}>
                    <div className="flex justify-between items-center mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-red-500">{stat.icon}</span>
                        <span className="text-[10px] font-bold uppercase text-white/60">{stat.label}</span>
                      </div>
                      <span className="text-[10px] font-black">{stat.value} <span className="text-white/20">/ 200</span></span>
                    </div>
                    <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(stat.value / 200) * 100}%` }}
                        className="h-full bg-gradient-to-r from-red-600 to-red-400"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <button 
                onClick={() => onSelect(selectedOp)}
                className="w-full mt-12 py-4 bg-red-600 hover:bg-red-700 text-white font-black uppercase tracking-widest rounded-xl shadow-[0_0_30px_rgba(220,38,38,0.3)] transition-all active:scale-95"
              >
                Select Operator
              </button>
            </div>

            <div className="bg-black/60 backdrop-blur-md border border-white/10 p-6 rounded-2xl">
              <div className="flex items-center gap-2 mb-4">
                <Info className="w-4 h-4 text-red-500" />
                <h3 className="text-[10px] font-black uppercase tracking-widest">Operator Profile</h3>
              </div>
              <p className="text-[11px] text-white/60 leading-relaxed font-mono italic">
                {selectedOp.description}
              </p>
            </div>
          </div>
        </div>

        {/* Back Button */}
        <button 
          onClick={onBack}
          className="absolute top-8 left-8 z-30 flex items-center gap-2 text-white/40 hover:text-white transition-colors group"
        >
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span className="text-[10px] font-black uppercase tracking-widest">Back to Squad</span>
        </button>
      </div>

      {/* Background Ambience */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-red-600/5 blur-[120px] -z-10" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-red-600/5 blur-[120px] -z-10" />
    </div>
  );
};
