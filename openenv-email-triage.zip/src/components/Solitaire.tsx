import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Spade, Heart, Diamond, Club, RotateCcw, Trophy, Timer, Hash, Lightbulb, Undo2, User, Star, CheckCircle2, Circle, ChevronRight } from 'lucide-react';

type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';
type Card = { id: string; value: number; suit: Suit; isFaceUp: boolean };

const SUITS: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
const VALUES = Array.from({ length: 13 }, (_, i) => i + 1);

interface Goal {
  id: number;
  text: string;
  reward: number;
  completed: boolean;
}

export default function Solitaire() {
  const [deck, setDeck] = useState<Card[]>([]);
  const [piles, setPiles] = useState<Card[][]>(Array(7).fill([]));
  const [stock, setStock] = useState<Card[]>([]);
  const [waste, setWaste] = useState<Card[]>([]);
  const [foundations, setFoundations] = useState<Card[][]>(Array(4).fill([]));
  const [score, setScore] = useState(300);
  const [time, setTime] = useState(90); // 1:30
  const [isGameOver, setIsGameOver] = useState(false);
  const [showGoals, setShowGoals] = useState(false);
  
  const [goals, setGoals] = useState<Goal[]>([
    { id: 1, text: "Have two columns cleared within 60 moves and then win any deal", reward: 75, completed: true },
    { id: 2, text: "Make a run of four cards with only diamonds and then win any deal", reward: 200, completed: false },
    { id: 3, text: "Move five diamonds into the Foundation before any other suit", reward: 150, completed: false },
  ]);

  useEffect(() => {
    initializeGame();
    const timer = setInterval(() => setTime(t => t > 0 ? t - 1 : 0), 1000);
    return () => clearInterval(timer);
  }, []);

  const initializeGame = () => {
    const newDeck: Card[] = [];
    SUITS.forEach(suit => {
      VALUES.forEach(value => {
        newDeck.push({ id: `${suit}-${value}`, value, suit, isFaceUp: false });
      });
    });

    // Shuffle
    for (let i = newDeck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newDeck[i], newDeck[j]] = [newDeck[j], newDeck[i]];
    }

    const newPiles: Card[][] = Array(7).fill([]).map((_, i) => {
      const pile = newDeck.splice(0, i + 1);
      pile[pile.length - 1].isFaceUp = true;
      return pile;
    });

    setPiles(newPiles);
    setStock(newDeck);
    setWaste([]);
    setFoundations(Array(4).fill([]));
    setScore(300);
    setTime(90);
    setIsGameOver(false);
  };

  const getSuitIcon = (suit: Suit, size = 16) => {
    switch (suit) {
      case 'spades': return <Spade size={size} className="text-[#1a1a1a]" />;
      case 'hearts': return <Heart size={size} className="text-[#ff4d4d]" />;
      case 'diamonds': return <Diamond size={size} className="text-[#ff4d4d]" />;
      case 'clubs': return <Club size={size} className="text-[#1a1a1a]" />;
    }
  };

  const formatValue = (val: number) => {
    if (val === 1) return 'A';
    if (val === 11) return 'J';
    if (val === 12) return 'Q';
    if (val === 13) return 'K';
    return val.toString();
  };

  const CardView = ({ card, onClick, className = "" }: { card: Card; onClick?: () => void; className?: string }) => (
    <motion.div
      layoutId={card.id}
      onClick={onClick}
      className={`relative w-28 h-40 lg:w-48 lg:h-72 rounded-[2.5rem] border transition-all cursor-pointer shadow-2xl ${
        card.isFaceUp 
          ? "bg-white border-white/20" 
          : "bg-[#1a1a1a] border-white/10"
      } ${className}`}
    >
      {card.isFaceUp ? (
        <div className="flex flex-col h-full p-6 justify-between">
          <div className="flex flex-col items-start leading-none">
            <span className={`text-4xl lg:text-6xl font-black ${card.suit === 'hearts' || card.suit === 'diamonds' ? 'text-[#ff4d4d]' : 'text-[#1a1a1a]'}`}>
              {formatValue(card.value)}
            </span>
            {getSuitIcon(card.suit, 32)}
          </div>
          <div className="flex justify-center opacity-10">
            {getSuitIcon(card.suit, 100)}
          </div>
          <div className="flex flex-col items-end leading-none rotate-180">
            <span className={`text-4xl lg:text-6xl font-black ${card.suit === 'hearts' || card.suit === 'diamonds' ? 'text-[#ff4d4d]' : 'text-[#1a1a1a]'}`}>
              {formatValue(card.value)}
            </span>
            {getSuitIcon(card.suit, 32)}
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-center h-full">
          <div className="w-24 h-24 rounded-full border border-white/5 flex items-center justify-center bg-white/5">
            <div className="w-12 h-12 rounded-full bg-white/5" />
          </div>
        </div>
      )}
    </motion.div>
  );

  const GoalsOverlay = () => (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 bg-black/90 backdrop-blur-3xl z-50 flex items-center justify-center p-8"
    >
      <div className="max-w-md w-full flex flex-col gap-12">
        <div className="text-center">
          <h2 className="text-6xl font-black text-white tracking-tighter mb-4">Daily goals</h2>
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-white/5 rounded-full border border-white/10">
            <Timer size={18} className="text-[#ff6b2b]" />
            <span className="text-xl font-black text-[#ff6b2b] tabular-nums">13:30:20</span>
          </div>
        </div>

        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="w-32 h-32 rounded-full bg-[#d4ff00] flex items-center justify-center shadow-[0_0_50px_rgba(212,255,0,0.3)]">
              <Star className="text-black fill-black" size={48} />
            </div>
            <div className="absolute -right-4 top-1/2 -translate-y-1/2 text-8xl font-black text-[#d4ff00] tracking-tighter">300</div>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          {goals.map((goal) => (
            <div 
              key={goal.id} 
              className={`p-6 rounded-[2.5rem] border transition-all flex items-center gap-6 ${
                goal.completed 
                  ? "bg-white/10 border-white/20" 
                  : "bg-white/5 border-white/5 opacity-60"
              }`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                goal.completed ? "bg-[#d4ff00]" : "border-2 border-white/10"
              }`}>
                {goal.completed ? <CheckCircle2 className="text-black" size={24} /> : <Circle className="text-white/10" size={24} />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white/80 leading-tight mb-2">{goal.text}</p>
                <div className="flex items-center gap-2">
                  <Star size={14} className="text-[#d4ff00] fill-[#d4ff00]" />
                  <span className="text-sm font-black text-[#d4ff00]">{goal.reward}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button 
          onClick={() => setShowGoals(false)}
          className="w-full py-6 bg-white/5 hover:bg-white/10 rounded-[2.5rem] border border-white/10 text-white font-black uppercase tracking-widest transition-all"
        >
          Continue
        </button>
      </div>
    </motion.div>
  );

  return (
    <div className="flex flex-col h-full bg-[#010103] text-white overflow-hidden relative font-sans">
      {/* Immersive Background Lines */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1200px] h-[1200px] border border-white/5 rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] border border-white/5 rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-white/5 rounded-full" />
      </div>

      <AnimatePresence>
        {showGoals && <GoalsOverlay />}
      </AnimatePresence>

      {/* Header */}
      <div className="flex justify-between items-center p-8 relative z-10">
        <button 
          onClick={() => setShowGoals(true)}
          className="w-14 h-14 bg-[#5b21b6] rounded-2xl flex items-center justify-center border border-white/10 shadow-xl hover:scale-105 transition-all"
        >
          <User className="text-white" size={24} />
        </button>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 px-6 py-3 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-xl">
            <Timer size={18} className="text-[#ff6b2b]" />
            <span className="text-xl font-black text-[#ff6b2b] tabular-nums">
              {Math.floor(time / 60)}:{(time % 60).toString().padStart(2, '0')}
            </span>
          </div>
          <div className="flex items-center gap-3 px-6 py-3 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-xl">
            <Star size={18} className="text-[#d4ff00] fill-[#d4ff00]" />
            <span className="text-xl font-black text-[#d4ff00] tabular-nums">{score}</span>
          </div>
        </div>
      </div>

      {/* Daily Goal Ticker */}
      <div className="px-8 mb-8 relative z-10">
        <div className="max-w-[1600px] mx-auto bg-white/5 border border-white/10 rounded-3xl p-8 flex items-center justify-between group cursor-pointer hover:bg-white/10 transition-all">
          <p className="text-2xl font-medium text-white/60">Move the Jack of <span className="text-[#ff4d4d]">♦</span> to the Tableau within 3:20 minutes</p>
          <ChevronRight size={24} className="text-white/20 group-hover:text-white transition-all" />
        </div>
      </div>

      {/* Game Board */}
      <div className="flex-1 p-4 lg:p-12 flex flex-col gap-12 lg:gap-24 relative z-10 overflow-y-auto custom-scrollbar">
        {/* Top Row: Stock, Foundations */}
        <div className="flex justify-between max-w-[1800px] mx-auto w-full">
          <div className="flex gap-4 lg:gap-12">
            {/* Stock */}
            <div className="relative group">
              {stock.length > 0 ? (
                <CardView card={stock[stock.length - 1]} onClick={() => {
                  const newStock = [...stock];
                  const card = newStock.pop()!;
                  card.isFaceUp = true;
                  setWaste([...waste, card]);
                  setStock(newStock);
                }} />
              ) : (
                <div 
                  onClick={() => {
                    setStock(waste.reverse().map(c => ({ ...c, isFaceUp: false })));
                    setWaste([]);
                  }}
                  className="w-28 h-40 lg:w-48 lg:h-72 rounded-[2.5rem] border border-dashed border-white/10 flex items-center justify-center cursor-pointer hover:bg-white/5 group"
                >
                  <RotateCcw className="text-white/20 group-hover:rotate-180 transition-transform duration-500" size={64} />
                </div>
              )}
            </div>

            {/* Waste */}
            <div className="relative">
              {waste.length > 0 ? (
                <CardView card={waste[waste.length - 1]} />
              ) : (
                <div className="w-28 h-40 lg:w-48 lg:h-72 rounded-[2.5rem] border border-dashed border-white/10" />
              )}
            </div>
          </div>

          {/* Foundations */}
          <div className="flex gap-4 lg:gap-12">
            {foundations.map((foundation, i) => (
              <div key={i} className="relative">
                {foundation.length > 0 ? (
                  <CardView card={foundation[foundation.length - 1]} />
                ) : (
                  <div className="w-28 h-40 lg:w-48 lg:h-72 rounded-[2.5rem] border border-dashed border-white/10 flex items-center justify-center bg-white/5">
                    <div className="opacity-10">
                      {getSuitIcon(SUITS[i], 80)}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Piles */}
        <div className="flex justify-between max-w-[1800px] mx-auto w-full gap-4 lg:gap-12">
          {piles.map((pile, i) => (
            <div key={i} className="flex-1 flex flex-col items-center relative min-h-[1200px]">
              {pile.length === 0 ? (
                <div className="w-28 h-40 lg:w-48 lg:h-72 rounded-[2.5rem] border border-dashed border-white/5 bg-white/5" />
              ) : (
                <div className="relative w-full flex flex-col items-center">
                  {pile.map((card, cardIndex) => (
                    <div 
                      key={card.id} 
                      className="absolute w-full flex justify-center" 
                      style={{ top: cardIndex * 65 }}
                    >
                      <CardView card={card} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Footer Controls */}
      <div className="p-12 flex justify-center gap-8 relative z-10">
        <button className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all active:scale-90">
          <RotateCcw className="text-white/40" size={28} />
        </button>
        <button className="w-24 h-24 rounded-full bg-white/5 border border-white/20 flex items-center justify-center hover:bg-[#d4ff00] group transition-all active:scale-90 shadow-2xl">
          <Lightbulb className="text-[#d4ff00] group-hover:text-black transition-colors" size={36} />
        </button>
        <button className="w-20 h-20 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-all active:scale-90">
          <Undo2 className="text-white/40" size={28} />
        </button>
      </div>
    </div>
  );
}
