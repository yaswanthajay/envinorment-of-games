import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Settings, 
  Info, 
  Shield, 
  Zap, 
  Cpu, 
  Globe, 
  Github, 
  Twitter, 
  Linkedin,
  Mail,
  ExternalLink,
  QrCode
} from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  icon: React.ReactNode;
  color: string;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, icon, color }) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-8">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-md"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="relative w-full max-w-2xl bg-[#0a0a0f] border border-white/10 rounded-[2.5rem] overflow-hidden shadow-[0_0_50px_rgba(0,0,0,1)]"
        >
          {/* Header */}
          <div className="p-8 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center text-white shadow-lg`}>
                {icon}
              </div>
              <div>
                <h2 className="text-xl font-black uppercase tracking-tighter italic text-white">{title}</h2>
                <span className="text-[10px] font-mono text-white/20 uppercase tracking-[0.3em]">Nexus_System_Protocol</span>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-white hover:bg-white/10 transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
            {children}
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

export const SettingsModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void;
  difficulty: string;
  setDifficulty: (d: string) => void;
}> = ({ isOpen, onClose, difficulty, setDifficulty }) => {
  const difficulties = ['EASY', 'MEDIUM', 'HARD', 'INSANE'];

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title="System Settings" 
      icon={<Settings className="w-6 h-6" />}
      color="from-cyan-500 to-blue-600"
    >
      <div className="space-y-8">
        <section>
          <h3 className="text-xs font-black uppercase tracking-widest text-white/40 mb-4 flex items-center gap-2">
            <Zap className="w-3 h-3 text-cyan-400" />
            Neural_Difficulty_Level
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {difficulties.map((d) => (
              <button
                key={d}
                onClick={() => setDifficulty(d)}
                className={`py-4 rounded-2xl border transition-all text-[10px] font-black tracking-widest uppercase ${
                  difficulty === d 
                    ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.2)]' 
                    : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
          <p className="mt-4 text-[9px] text-white/20 italic leading-relaxed">
            * Adjusting difficulty will recalibrate the AI core's processing power and response time.
          </p>
        </section>

        <section>
          <h3 className="text-xs font-black uppercase tracking-widest text-white/40 mb-4 flex items-center gap-2">
            <Cpu className="w-3 h-3 text-fuchsia-400" />
            System_Optimization
          </h3>
          <div className="space-y-4">
            {[
              { label: 'Hardware Acceleration', enabled: true },
              { label: 'Neural Flux Rendering', enabled: true },
              { label: 'Quantum Audio Engine', enabled: false },
            ].map((opt, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                <span className="text-[10px] font-bold text-white/60 uppercase tracking-widest">{opt.label}</span>
                <div className={`w-10 h-5 rounded-full p-1 transition-colors ${opt.enabled ? 'bg-cyan-500' : 'bg-white/10'}`}>
                  <div className={`w-3 h-3 rounded-full bg-white transition-transform ${opt.enabled ? 'translate-x-5' : 'translate-x-0'}`} />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </Modal>
  );
};

export const CreatorModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      title="Architect Profile" 
      icon={<Info className="w-6 h-6" />}
      color="from-fuchsia-500 to-purple-600"
    >
      <div className="space-y-8">
        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row items-center gap-8 p-6 bg-white/5 rounded-[2rem] border border-white/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-fuchsia-500/10 blur-[60px] rounded-full -mr-16 -mt-16" />
          
          <div className="w-32 h-32 rounded-full border-4 border-fuchsia-500/50 p-1.5 relative z-10">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Toukir" 
              alt="Toukir Ahamed" 
              className="w-full h-full rounded-full bg-fuchsia-500/10"
              referrerPolicy="no-referrer"
            />
          </div>
          
          <div className="text-center sm:text-left relative z-10">
            <span className="text-[10px] font-black text-fuchsia-400 uppercase tracking-[0.3em] mb-2 block">Hi there !!</span>
            <h3 className="text-3xl font-black text-white tracking-tighter mb-2 italic">I'm <span className="text-fuchsia-500">Toukir Ahamed</span></h3>
            <p className="text-sm text-white/60 font-medium leading-relaxed">
              Full-stack Software Developer <br className="hidden sm:block" />
              & <span className="text-cyan-400">AI Integration Specialist</span>
            </p>
          </div>
        </div>

        {/* Expertise */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="p-6 bg-white/5 rounded-[2rem] border border-white/5">
            <h4 className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-4">Core Expertise</h4>
            <p className="text-xs text-white/80 leading-relaxed italic">
              "Interactive UI Animations with GSAP & Framer Motion. Discover smooth scroll effects, engaging card transitions, and dynamic SVG animations."
            </p>
          </div>
          <div className="p-6 bg-white/5 rounded-[2rem] border border-white/5 flex flex-col items-center justify-center gap-4">
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-white/40 hover:text-cyan-400 transition-colors">
                <Globe className="w-5 h-5" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-white/40 hover:text-fuchsia-400 transition-colors">
                <Github className="w-5 h-5" />
              </div>
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-white/40 hover:text-blue-400 transition-colors">
                <Linkedin className="w-5 h-5" />
              </div>
            </div>
            <a 
              href="https://pigeonic.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-[10px] font-black text-cyan-400 uppercase tracking-widest flex items-center gap-2 hover:underline"
            >
              pigeonic.com <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Tech Stack Icons Mock */}
        <div className="flex flex-wrap justify-center gap-8 py-4 border-y border-white/5">
          {['GSAP', 'Framer', 'React', 'Tailwind'].map((tech, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-white/20 hover:text-white transition-all hover:scale-110">
                <Zap className="w-6 h-6" />
              </div>
              <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">{tech}</span>
            </div>
          ))}
        </div>

        {/* QR Section */}
        <div className="flex items-center justify-between p-6 bg-gradient-to-br from-fuchsia-500/10 to-cyan-500/10 rounded-[2rem] border border-white/5">
          <div className="max-w-[60%]">
            <h4 className="text-sm font-black text-white uppercase tracking-tighter mb-2">Connect with the Architect</h4>
            <p className="text-[10px] text-white/40 leading-relaxed italic">
              Scan the code to view the full portfolio and interactive case studies.
            </p>
          </div>
          <div className="w-20 h-20 bg-white p-1.5 rounded-2xl shadow-xl">
            <img 
              src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://pigeonic.com" 
              alt="QR Code" 
              className="w-full h-full"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </div>
    </Modal>
  );
};
