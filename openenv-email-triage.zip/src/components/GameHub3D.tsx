import React, { useRef, useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Text, Sphere, MeshDistortMaterial, Stars, OrbitControls, Torus, MeshWobbleMaterial, Sparkles, Points, PointMaterial, Html } from '@react-three/drei';
import * as THREE from 'three';
import { motion as motion3d } from 'framer-motion';

function CoreParticles() {
  const points = useMemo(() => {
    const p = new Float32Array(2000 * 3);
    for (let i = 0; i < 2000; i++) {
      const r = 2.5 + Math.random() * 2;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      p[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      p[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      p[i * 3 + 2] = r * Math.cos(phi);
    }
    return p;
  }, []);

  const ref = useRef<THREE.Points>(null);
  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y += 0.002;
      ref.current.rotation.z += 0.001;
    }
  });

  return (
    <Points ref={ref} positions={points} stride={3}>
      <PointMaterial
        transparent
        color="#06b6d4"
        size={0.05}
        sizeAttenuation={true}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </Points>
  );
}

interface GameNodeProps {
  position: [number, number, number];
  title: string;
  description: string;
  difficulty: string;
  color: string;
  onClick: () => void;
  isActive: boolean;
}

function GameNode({ position, title, description, difficulty, color, onClick, isActive }: GameNodeProps) {
  const mesh = useRef<THREE.Mesh>(null);
  const ring = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (mesh.current) {
      mesh.current.rotation.y += 0.01;
      mesh.current.position.y = position[1] + Math.sin(t + position[0]) * 0.2;
      
      // Reactive scale
      const targetScale = hovered ? 1.3 : 1;
      mesh.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.1);
    }
    if (ring.current) {
      ring.current.rotation.x += 0.02;
      ring.current.rotation.y += 0.01;
      ring.current.scale.setScalar(hovered ? 1.2 : 1);
    }
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={1}>
      <group position={position} onClick={onClick} onPointerOver={() => setHovered(true)} onPointerOut={() => setHovered(false)}>
        <Sphere ref={mesh} args={[0.8, 32, 32]}>
          <MeshDistortMaterial
            color={hovered ? '#fff' : color}
            speed={hovered ? 5 : 3}
            distort={hovered ? 0.6 : 0.4}
            radius={1}
            emissive={color}
            emissiveIntensity={hovered ? 4 : 0.5}
          />
        </Sphere>
        
        {/* Orbital Ring */}
        <Torus ref={ring} args={[1.2, 0.02, 16, 100]}>
          <meshBasicMaterial color={color} transparent opacity={hovered ? 0.8 : 0.3} />
        </Torus>

        {hovered && (
          <group>
            <Torus args={[1.4, 0.01, 16, 100]} rotation={[Math.PI / 2, 0, 0]}>
              <meshBasicMaterial color="#fff" transparent opacity={0.5} />
            </Torus>
            <Sparkles count={20} scale={2} size={2} speed={0.5} color={color} />
            
            <Html distanceFactor={10} position={[1.5, 1.5, 0]} pointerEvents="none">
              <motion.div
                initial={{ opacity: 0, scale: 0.8, x: -20 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                className="w-80 bg-black/80 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 shadow-[0_0_50px_rgba(0,0,0,0.5)] overflow-hidden relative"
              >
                {/* Background Glow */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/20 blur-[60px] rounded-full -mr-16 -mt-16" />
                
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 rounded-full border-2 border-cyan-500/50 p-1 overflow-hidden">
                      <img 
                        src="https://api.dicebear.com/7.x/avataaars/svg?seed=Toukir" 
                        alt="Creator" 
                        className="w-full h-full rounded-full bg-cyan-500/10"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="text-white font-black text-lg tracking-tight leading-none mb-1">Toukir Ahamed</h4>
                      <p className="text-cyan-400/60 text-[10px] uppercase tracking-widest font-bold">AI Integration Specialist</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h3 className="text-white font-black text-xl uppercase italic tracking-tighter mb-1">{title}</h3>
                      <p className="text-white/40 text-[10px] leading-relaxed italic line-clamp-2">{description}</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                        <span className="text-[8px] font-bold text-white/20 uppercase block mb-1">Difficulty</span>
                        <span className={`text-xs font-black tracking-widest ${
                          difficulty === 'INSANE' ? 'text-red-500' : 
                          difficulty === 'HARD' ? 'text-amber-500' : 
                          'text-cyan-400'
                        }`}>{difficulty}</span>
                      </div>
                      <div className="bg-white/5 rounded-xl p-3 border border-white/5">
                        <span className="text-[8px] font-bold text-white/20 uppercase block mb-1">Win Rate</span>
                        <span className="text-xs font-black text-white tracking-widest">64.2%</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-white/5">
                      <div className="flex gap-2">
                        <div className="w-6 h-6 rounded-lg bg-white/5 flex items-center justify-center">
                          <div className="w-3 h-3 bg-cyan-400 rounded-full blur-[2px]" />
                        </div>
                        <div className="w-6 h-6 rounded-lg bg-white/5 flex items-center justify-center">
                          <div className="w-3 h-3 bg-fuchsia-400 rounded-full blur-[2px]" />
                        </div>
                      </div>
                      <div className="w-10 h-10 bg-white p-1 rounded-lg opacity-80">
                        <img 
                          src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://pigeonic.com" 
                          alt="QR" 
                          className="w-full h-full"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </Html>
          </group>
        )}

        <Text
          position={[0, -1.5, 0]}
          fontSize={0.25}
          color={hovered ? "#06b6d4" : "white"}
          font="https://fonts.gstatic.com/s/inter/v12/UcCO3FwrK3iLTeHuS_fvQtMwCp50KnMw2boKoduKmMEVuLyfAZ9hjp-Ek-_EeA.woff"
          anchorX="center"
          anchorY="middle"
        >
          {(title || "").toUpperCase()}
        </Text>
      </group>
    </Float>
  );
}

interface GameHub3DProps {
  onSelectGame: (id: string) => void;
  onOpenList: () => void;
  games: any[];
}

export default function GameHub3D({ onSelectGame, onOpenList, games }: GameHub3DProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredGames = useMemo(() => {
    return games.filter(game => 
      game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.description.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [games, searchQuery]);

  const nodes = useMemo(() => {
    return filteredGames.map((game, i) => {
      const angle = (i / filteredGames.length) * Math.PI * 2;
      const radius = 6;
      return {
        ...game,
        position: [Math.cos(angle) * radius, Math.sin(angle) * radius * 0.5, Math.sin(angle) * radius] as [number, number, number]
      };
    });
  }, [filteredGames]);

  return (
    <div className="w-full h-[600px] lg:h-[800px] xl:h-[900px] relative cursor-pointer">
      <Canvas camera={{ position: [0, 0, 12], fov: 50 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        
        <group>
          {nodes.map((node) => (
            <GameNode
              key={node.id}
              position={node.position}
              title={node.title}
              description={node.description}
              difficulty={node.difficulty}
              color={node.color.includes('cyan') ? '#06b6d4' : node.color.includes('fuchsia') ? '#d946ef' : node.color.includes('amber') ? '#f59e0b' : '#10b981'}
              onClick={() => onSelectGame(node.id)}
              isActive={false}
            />
          ))}
        </group>

        {/* Central Core */}
        <group>
          <Float speed={5} rotationIntensity={2} floatIntensity={2}>
            <Sphere args={[2, 64, 64]}>
              <MeshWobbleMaterial
                color="#06b6d4"
                speed={1}
                factor={0.6}
                transparent
                opacity={0.15}
                wireframe
              />
            </Sphere>
            <Sphere args={[1.8, 64, 64]}>
              <MeshDistortMaterial
                color="#d946ef"
                speed={4}
                distort={0.3}
                transparent
                opacity={0.2}
              />
            </Sphere>
          </Float>

          {/* Complex Orbital Rings */}
          {[...Array(3)].map((_, i) => (
            <Float key={i} speed={2 + i} rotationIntensity={2}>
              <Torus args={[3 + i * 0.5, 0.01, 16, 100]} rotation={[Math.random() * Math.PI, Math.random() * Math.PI, 0]}>
                <meshBasicMaterial color={i % 2 === 0 ? "#06b6d4" : "#d946ef"} transparent opacity={0.2} />
              </Torus>
            </Float>
          ))}

          <CoreParticles />
          <Sparkles count={100} scale={10} size={2} speed={0.2} color="#06b6d4" />
          <Sparkles count={50} scale={8} size={4} speed={0.4} color="#d946ef" />
        </group>

        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
      </Canvas>
      
      <div className="absolute inset-0 flex flex-col items-center justify-start pt-12 pointer-events-none">
        <div className="text-center mb-8">
          <h2 className="text-8xl font-black tracking-tighter italic text-white/5 uppercase select-none">Nexus Core</h2>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="pointer-events-auto w-full max-w-md px-6 mb-12"
        >
          <div className="relative group">
            <div className="absolute inset-0 bg-cyan-500/20 blur-xl rounded-2xl opacity-0 group-focus-within:opacity-100 transition-opacity" />
            <input
              type="text"
              placeholder="SEARCH NEURAL NODES..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/40 backdrop-blur-xl border border-white/10 rounded-2xl px-6 py-4 text-white font-mono text-xs tracking-widest outline-none focus:border-cyan-500/50 transition-all placeholder:text-white/20"
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse delay-75" />
            </div>
          </div>
        </motion.div>
        
        <div className="flex-1" />

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="pointer-events-auto mb-12"
        >
          <button 
            onClick={onOpenList}
            className="bg-white/10 backdrop-blur-xl border border-white/20 text-white px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-[0.3em] hover:bg-white hover:text-black transition-all shadow-[0_0_30px_rgba(255,255,255,0.1)]"
          >
            Open All Games
          </button>
        </motion.div>
      </div>
    </div>
  );
}
