import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Coins, 
  Users, 
  ChevronRight,
  Play,
  Grid3X3,
  Activity,
  Settings,
  Key,
  Plus
} from 'lucide-react';

interface Game {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  difficulty: string;
}

interface GameListMobileProps {
  games: Game[];
  onSelectGame: (id: string) => void;
  onBack?: () => void;
}

const GameListMobile: React.FC<GameListMobileProps> = ({ games, onSelectGame, onBack }) => {
  const [view, setView] = useState<'public' | 'code'>('public');
  const [roomCode, setRoomCode] = useState(['', '', '', '', '', '']);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredGames = games.filter(game => 
    game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    game.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCodeInput = (index: number, value: string) => {
    if (value.length > 1) value = value[0];
    const newCode = [...roomCode];
    newCode[index] = value;
    setRoomCode(newCode);
    
    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.getElementById(`code-${index + 1}`);
      nextInput?.focus();
    }
  };

  const publicRooms = [
    { id: '1', title: 'Movie Buffs Arena', category: 'Movie', team: '4v4', players: 6, maxPlayers: 8, cost: 200, icon: '🎬' },
    { id: '2', title: 'Guess the Creator', category: 'Influencer', team: '3v3', players: 3, maxPlayers: 6, cost: 180, icon: '🤳' },
    { id: '3', title: 'Blockbuster Showdown', category: 'Movie', team: '3v3', players: 5, maxPlayers: 6, cost: 120, icon: '🍿' },
    { id: '4', title: 'Guess the Step', category: 'Dance', team: '4v4', players: 7, maxPlayers: 8, cost: 120, icon: '💃' },
  ];

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0a0f]/40 lg:bg-transparent rounded-[2.5rem] lg:rounded-none overflow-hidden lg:overflow-visible shadow-2xl lg:shadow-none border-4 lg:border-none border-white/5 relative text-white">
      {/* Status Bar Mock - Hidden on Desktop */}
      <div className="h-10 flex lg:hidden justify-between items-center px-10 pt-4 z-10">
        <span className="text-[10px] font-bold text-white/40 tracking-widest">9:41</span>
        <div className="flex gap-1.5 items-center">
          <div className="w-4 h-2.5 border border-white/30 rounded-[2px]" />
          <div className="w-3 h-3 bg-white/30 rounded-full" />
        </div>
      </div>

      {/* Top Header */}
      <div className="px-6 lg:px-0 py-6 lg:py-8 flex justify-between items-center z-10">
        <div className="flex items-center gap-6">
          <button 
            onClick={onBack}
            className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          </button>
          <div>
            <h2 className="text-xl lg:text-3xl font-black uppercase tracking-[0.2em] text-white italic">
              {view === 'public' ? 'Nexus Game Library' : 'Join with Code'}
            </h2>
            <p className="text-[10px] lg:text-xs font-mono text-cyan-400/60 uppercase tracking-[0.3em] mt-1">
              Sector_07 // Neural_Nodes_Available
            </p>
          </div>
        </div>
        <div className="bg-white/5 border border-white/10 px-6 py-3 rounded-2xl flex items-center gap-4 shadow-lg">
          <div className="flex flex-col items-end">
            <span className="text-[8px] font-bold text-white/20 uppercase tracking-widest leading-none mb-1">Credits</span>
            <span className="text-lg font-black text-cyan-400 leading-none">800</span>
          </div>
          <div className="w-10 h-10 bg-amber-400 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(251,191,36,0.3)]">
            <Coins className="w-6 h-6 text-amber-900" />
          </div>
        </div>
      </div>

      {/* Tabs and Search */}
      <div className="px-6 lg:px-0 mb-8 flex flex-col lg:flex-row gap-6 items-center">
        <div className="flex gap-4 w-full lg:w-auto">
          <button 
            onClick={() => setView('public')}
            className={`flex-1 lg:flex-none lg:px-12 py-4 rounded-2xl text-[10px] lg:text-xs font-black uppercase tracking-widest transition-all ${
              view === 'public' ? 'bg-cyan-500 text-black shadow-[0_0_30px_rgba(6,182,212,0.4)]' : 'bg-white/5 text-white/40 border border-white/10 hover:border-white/20'
            }`}
          >
            All Games
          </button>
          <button 
            onClick={() => setView('code')}
            className={`flex-1 lg:flex-none lg:px-12 py-4 rounded-2xl text-[10px] lg:text-xs font-black uppercase tracking-widest transition-all ${
              view === 'code' ? 'bg-fuchsia-500 text-white shadow-[0_0_30px_rgba(217,70,239,0.4)]' : 'bg-white/5 text-white/40 border border-white/10 hover:border-white/20'
            }`}
          >
            Private Code
          </button>
        </div>

        {view === 'public' && (
          <div className="w-full lg:flex-1">
            <div className="relative group">
              <div className="absolute inset-0 bg-cyan-500/10 blur-xl rounded-2xl opacity-0 group-focus-within:opacity-100 transition-opacity" />
              <input
                type="text"
                placeholder="SEARCH NEURAL NODES..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-xs lg:text-sm font-mono text-white outline-none focus:border-cyan-500/50 transition-all placeholder:text-white/20"
              />
            </div>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar px-6 lg:px-0 pb-12">
        <AnimatePresence mode="wait">
          {view === 'public' ? (
            <motion.div 
              key="public"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8"
            >
              {filteredGames.map((game) => (
                <motion.div
                  key={game.id}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="bg-white/5 border border-white/10 rounded-[2.5rem] p-8 relative group overflow-hidden hover:border-cyan-500/30 transition-all flex flex-col h-full"
                >
                  {/* Card Background Effects */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 blur-[60px] rounded-full -mr-16 -mt-16 group-hover:bg-cyan-500/10 transition-colors" />
                  
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                        {game.icon}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-[8px] font-bold uppercase tracking-widest text-white/20">Node_Type</span>
                        <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Game Node</span>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border ${
                      game.difficulty === 'INSANE' ? 'text-red-500 border-red-500/30 bg-red-500/10' : 
                      game.difficulty === 'HARD' ? 'text-amber-500 border-amber-500/30 bg-amber-500/10' : 
                      'text-cyan-400 border-cyan-400/30 bg-cyan-400/10'
                    }`}>{game.difficulty}</span>
                  </div>

                  <h3 className="text-xl font-black mb-3 tracking-tight text-white group-hover:text-cyan-400 transition-colors uppercase italic">{game.title}</h3>
                  <p className="text-xs text-white/40 mb-8 italic leading-relaxed flex-grow">{game.description}</p>

                  <div className="flex justify-between items-center pt-6 border-t border-white/5">
                    <div className="flex flex-col gap-2">
                      <span className="text-[8px] font-bold text-white/20 uppercase tracking-widest">Active_Players</span>
                      <div className="flex items-center -space-x-3">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className="w-8 h-8 rounded-xl border-2 border-[#0a0a0f] overflow-hidden shadow-lg">
                            <img 
                              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${game.id + i}`} 
                              alt="Player" 
                              className="w-full h-full bg-white/10"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        ))}
                        <div className="w-8 h-8 rounded-xl border-2 border-[#0a0a0f] bg-white/5 flex items-center justify-center text-[10px] font-bold text-white/40">
                          +12
                        </div>
                      </div>
                    </div>
                    <button 
                      onClick={() => onSelectGame(game.id)}
                      className="bg-cyan-500 text-black px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-white transition-all shadow-xl shadow-cyan-500/20 active:scale-95"
                    >
                      Initialize
                    </button>
                  </div>
                </motion.div>
              ))}
              {filteredGames.length === 0 && (
                <div className="col-span-full text-center py-24 bg-white/5 rounded-[3rem] border border-dashed border-white/10">
                  <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Plus className="w-10 h-10 text-white/10 rotate-45" />
                  </div>
                  <p className="text-white/20 text-sm font-mono uppercase tracking-[0.3em]">No neural nodes found in this sector</p>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="code"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col items-center justify-center py-24 bg-white/5 rounded-[3rem] border border-white/10 relative overflow-hidden"
            >
              {/* Background Glow */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-fuchsia-500/5 blur-[120px] rounded-full pointer-events-none" />

              <div className="w-32 h-32 bg-fuchsia-500/10 border border-fuchsia-500/20 rounded-[3rem] flex items-center justify-center mb-10 shadow-[0_0_60px_rgba(217,70,239,0.1)] relative group">
                <Key className="w-12 h-12 text-fuchsia-400 group-hover:rotate-12 transition-transform" />
              </div>

              <h3 className="text-3xl lg:text-4xl font-black uppercase tracking-[0.3em] mb-4 text-white italic">Enter Room Code</h3>
              <p className="text-xs lg:text-sm text-white/40 font-medium uppercase tracking-[0.4em] mb-16">Ask your friend for the 6-digit key</p>

              <div className="flex gap-4 mb-16">
                {roomCode.map((digit, i) => (
                  <input
                    key={i}
                    id={`code-${i}`}
                    type="text"
                    value={digit}
                    onChange={(e) => handleCodeInput(i, e.target.value)}
                    className="w-14 h-20 lg:w-16 lg:h-24 bg-white/5 border border-white/10 rounded-2xl text-center font-black text-3xl lg:text-4xl focus:border-fuchsia-500 focus:bg-fuchsia-500/10 outline-none transition-all text-fuchsia-400 shadow-lg"
                  />
                ))}
              </div>

              <button className="w-full max-w-md bg-fuchsia-500 text-white py-6 rounded-[2.5rem] font-black uppercase tracking-[0.4em] text-lg hover:bg-white hover:text-black transition-all shadow-[0_30px_60px_rgba(217,70,239,0.3)] active:scale-95">
                Join Room
              </button>
              
              <p className="mt-10 text-xs font-bold text-fuchsia-400/60 uppercase tracking-[0.3em] animate-pulse">
                Room found! Tap join room to enter.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom Nav Mock - Hidden on Desktop */}
      <div className="h-24 lg:hidden bg-white/5 border-t border-white/5 flex items-center justify-around px-8 backdrop-blur-xl">
        <div className="flex flex-col items-center gap-1 group cursor-pointer">
          <div className="w-10 h-10 bg-cyan-500 rounded-2xl flex items-center justify-center text-black shadow-lg shadow-cyan-500/20">
            <Grid3X3 className="w-5 h-5" />
          </div>
          <span className="text-[8px] font-black uppercase tracking-widest text-cyan-400">Lobby</span>
        </div>
        <div className="flex flex-col items-center gap-1 group cursor-pointer opacity-30 hover:opacity-100 transition-opacity">
          <div className="w-10 h-10 flex items-center justify-center text-white">
            <Activity className="w-5 h-5" />
          </div>
          <span className="text-[8px] font-black uppercase tracking-widest">Stats</span>
        </div>
        <div className="flex flex-col items-center gap-1 group cursor-pointer opacity-30 hover:opacity-100 transition-opacity">
          <div className="w-10 h-10 flex items-center justify-center text-white">
            <Settings className="w-5 h-5" />
          </div>
          <span className="text-[8px] font-black uppercase tracking-widest">Config</span>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 0px; }
      `}} />
    </div>
  );
};

export default GameListMobile;
