import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getNumberQuestQuestion } from '../services/aiService';
import { Hash, HelpCircle, Target, Zap, Trophy, RefreshCw, Loader2, Lightbulb, CheckCircle2, XCircle } from 'lucide-react';

export default function NumberQuest({ difficulty = "MEDIUM" }: { difficulty?: string }) {
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'RESULT'>('START');
  const [currentQuestion, setCurrentQuestion] = useState<{ question: string, answer: number, hint: string, explanation: string } | null>(null);
  const [userGuess, setUserGuess] = useState("");
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [feedback, setFeedback] = useState<{ correct: boolean, message: string } | null>(null);

  const fetchQuestion = async () => {
    setIsLoading(true);
    const question = await getNumberQuestQuestion(difficulty);
    if (question) {
      setCurrentQuestion(question);
      setGameState('PLAYING');
      setUserGuess("");
      setShowHint(false);
      setFeedback(null);
    }
    setIsLoading(false);
  };

  const handleGuess = () => {
    if (!userGuess || !currentQuestion) return;
    
    const guessNum = parseInt(userGuess);
    const isCorrect = guessNum === currentQuestion.answer;
    
    setFeedback({
      correct: isCorrect,
      message: isCorrect ? "Neural Link Established! Correct Answer." : "Frequency Mismatch. Incorrect Answer."
    });
    
    if (isCorrect) {
      setScore(s => s + 10);
    }
    setAttempts(a => a + 1);
    setGameState('RESULT');
  };

  const nextQuestion = () => {
    fetchQuestion();
  };

  const resetGame = () => {
    setScore(0);
    setAttempts(0);
    setGameState('START');
  };

  return (
    <div className="relative w-full max-w-4xl mx-auto h-[600px] bg-black/40 rounded-[2.5rem] border border-white/10 overflow-hidden backdrop-blur-md flex flex-col">
      {/* Background: World of Numbers */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
        {[...Array(50)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 800, 
              y: Math.random() * 600,
              opacity: 0,
              scale: 0.5
            }}
            animate={{ 
              y: [null, Math.random() * 600],
              opacity: [0, 0.5, 0],
              scale: [0.5, 1.2, 0.5]
            }}
            transition={{ 
              duration: 5 + Math.random() * 10, 
              repeat: Infinity,
              ease: "linear"
            }}
            className="absolute text-white font-mono text-4xl font-bold"
          >
            {Math.floor(Math.random() * 100)}
          </motion.div>
        ))}
      </div>

      {/* HUD Header */}
      <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5 z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center border border-blue-500/30">
            <Hash className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xl font-black text-white tracking-tighter uppercase italic">Number Quest</h2>
            <p className="text-[10px] text-blue-400/60 font-mono uppercase tracking-widest">Mathematical Nexus v2.1</p>
          </div>
        </div>
        <div className="flex gap-6">
          <div className="text-right">
            <p className="text-[8px] text-white/40 uppercase font-bold tracking-widest">Neural Score</p>
            <p className="text-xl font-black text-white font-mono">{score}</p>
          </div>
          <div className="text-right">
            <p className="text-[8px] text-white/40 uppercase font-bold tracking-widest">Attempts</p>
            <p className="text-xl font-black text-white font-mono">{attempts}</p>
          </div>
        </div>
      </div>

      {/* Main Interaction Zone */}
      <div className="flex-1 relative flex flex-col items-center justify-center p-8 z-10">
        <AnimatePresence mode="wait">
          {gameState === 'START' && (
            <motion.div 
              key="start"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.1 }}
              className="text-center space-y-8"
            >
              <div className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto border border-blue-500/20 animate-pulse">
                <Target className="w-12 h-12 text-blue-400" />
              </div>
              <div className="space-y-2">
                <h3 className="text-4xl font-black text-white uppercase tracking-tighter italic">Enter the Numeric Void</h3>
                <p className="text-white/40 max-w-md mx-auto">The Nexus Mind will challenge your mathematical and logical precision. Every answer is a number hidden in the void.</p>
              </div>
              <button
                onClick={fetchQuestion}
                disabled={isLoading}
                className="group relative px-12 py-4 bg-blue-500 text-black font-black rounded-full hover:bg-blue-400 transition-all uppercase tracking-widest text-sm flex items-center gap-3 mx-auto overflow-hidden"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5" />}
                <span>Initialize Quest</span>
                <motion.div 
                  className="absolute inset-0 bg-white/20 translate-x-[-100%]"
                  whileHover={{ translateX: '100%' }}
                  transition={{ duration: 0.5 }}
                />
              </button>
            </motion.div>
          )}

          {gameState === 'PLAYING' && currentQuestion && (
            <motion.div 
              key="playing"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full max-w-2xl space-y-8"
            >
              <div className="bg-white/5 border border-white/10 p-8 rounded-3xl backdrop-blur-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4">
                  <HelpCircle className="w-6 h-6 text-white/10" />
                </div>
                <p className="text-[10px] text-blue-400 font-bold uppercase tracking-[0.3em] mb-4">Neural Challenge // Intercepted</p>
                <h4 className="text-2xl lg:text-3xl font-serif italic text-white leading-tight">
                  {currentQuestion.question}
                </h4>
              </div>

              <div className="space-y-4">
                <div className="flex gap-4">
                  <input
                    type="number"
                    value={userGuess}
                    onChange={(e) => setUserGuess(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleGuess()}
                    placeholder="Enter Numeric Answer..."
                    className="flex-1 bg-black/40 border border-white/10 rounded-2xl px-6 py-4 text-white font-mono text-xl focus:outline-none focus:border-blue-500/50 transition-all"
                  />
                  <button
                    onClick={handleGuess}
                    className="px-8 py-4 bg-blue-500 text-black font-black rounded-2xl hover:bg-blue-400 transition-all uppercase tracking-widest text-sm"
                  >
                    Submit
                  </button>
                </div>
                
                <div className="flex justify-between items-center px-2">
                  <button 
                    onClick={() => setShowHint(!showHint)}
                    className="text-[10px] text-blue-400/60 hover:text-blue-400 flex items-center gap-2 uppercase tracking-widest transition-colors"
                  >
                    <Lightbulb className="w-3 h-3" />
                    {showHint ? "Hide Neural Hint" : "Request Neural Hint"}
                  </button>
                  <span className="text-[10px] text-white/20 uppercase tracking-widest">Difficulty: {difficulty}</span>
                </div>

                <AnimatePresence>
                  {showHint && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="bg-blue-500/5 border border-blue-500/20 p-4 rounded-xl text-xs text-blue-300/80 italic"
                    >
                      Hint: {currentQuestion.hint}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}

          {gameState === 'RESULT' && currentQuestion && feedback && (
            <motion.div 
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center space-y-8 w-full max-w-xl"
            >
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto border-2 ${feedback.correct ? 'bg-emerald-500/10 border-emerald-500/50' : 'bg-red-500/10 border-red-500/50'}`}>
                {feedback.correct ? <CheckCircle2 className="w-10 h-10 text-emerald-400" /> : <XCircle className="w-10 h-10 text-red-400" />}
              </div>
              
              <div className="space-y-4">
                <h3 className={`text-3xl font-black uppercase italic tracking-tighter ${feedback.correct ? 'text-emerald-400' : 'text-red-400'}`}>
                  {feedback.message}
                </h3>
                <div className="bg-white/5 border border-white/10 p-6 rounded-2xl space-y-2">
                  <p className="text-white/60 text-sm leading-relaxed">{currentQuestion.explanation}</p>
                  <p className="text-xs font-mono text-white/20">Correct Answer: <span className="text-white">{currentQuestion.answer}</span></p>
                </div>
              </div>

              <div className="flex gap-4 justify-center">
                <button
                  onClick={nextQuestion}
                  className="px-8 py-3 bg-white/10 text-white font-bold rounded-full hover:bg-white/20 transition-all uppercase tracking-widest text-xs flex items-center gap-2"
                >
                  <RefreshCw className="w-4 h-4" />
                  Next Quest
                </button>
                <button
                  onClick={resetGame}
                  className="px-8 py-3 bg-red-500/10 text-red-400 font-bold rounded-full hover:bg-red-500/20 transition-all uppercase tracking-widest text-xs"
                >
                  End Session
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer Metrics */}
      <div className="p-4 border-t border-white/10 bg-black/20 flex justify-between items-center px-8 z-10">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
          <span className="text-[8px] text-white/40 uppercase tracking-[0.2em] font-bold">Neural Link Active</span>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <Trophy className="w-3 h-3 text-amber-400" />
            <span className="text-[10px] text-white/60 font-mono">{score} PTS</span>
          </div>
        </div>
      </div>
    </div>
  );
}
