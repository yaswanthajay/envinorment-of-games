import React from 'react';
import { motion } from 'motion/react';
import { 
  Play, 
  Info, 
  Shield, 
  Target, 
  Zap, 
  ChevronRight,
  Gamepad2
} from 'lucide-react';

interface GameInstructionsProps {
  game: {
    title: string;
    description: string;
    difficulty: string;
    color: string;
    icon: React.ReactNode;
  };
  onStart: () => void;
  onBack: () => void;
}

const GameInstructions: React.FC<GameInstructionsProps> = ({ game, onStart, onBack }) => {
  const getRules = (title: string) => {
    switch (title) {
      case 'Tic-Tac-Toe':
        return [
          "Classic game of X and O on a 3x3 grid.",
          "Get three in a row (horizontal, vertical, or diagonal) to win.",
          "The AI will try to block your moves."
        ];
      case 'Mind Reader':
        return [
          "The Nexus Mind attempts to predict your subconscious patterns.",
          "Choose LEFT or RIGHT to navigate the neural paths.",
          "If the AI predicts your move, it gains a point. If you deviate, you score.",
          "Maintain your neural stability and try to outsmart the machine.",
          "High sync rates indicate the AI has successfully mapped your cognition."
        ];
      case 'Number Quest':
        return [
          "Enter the numeric void and analyze the AI's challenge.",
          "Every question has a single integer as its correct answer.",
          "Type your numeric guess and submit it to the Nexus Mind.",
          "Request a 'Neural Hint' if the pattern is too complex.",
          "Maintain high accuracy to earn more neural points."
        ];
      case 'Riddle Master':
        return [
          "The AI will give you a challenging riddle to solve.",
          "Type your answer in the text box.",
          "You can ask for hints or images if you get stuck."
        ];
      case 'Grandmaster Chess':
        return [
          "Classic Chess rules apply: Checkmate the opponent's King to win.",
          "Special moves: Castling, En Passant, and Pawn Promotion are supported.",
          "Play vs AI: Challenge the Stockfish engine with multiple difficulty levels.",
          "Play Online: Real-time multiplayer matchmaking with Elo ratings.",
          "Timers: Manage your time carefully. If your clock hits zero, you lose.",
          "Move History: Track all moves in the sidebar for tactical analysis."
        ];
      case 'Word Guess':
        return [
          "Guess the hidden word by choosing letters.",
          "Each wrong guess brings you closer to losing.",
          "Use the clues provided by the AI to help you."
        ];
      case 'Memory Match':
        return [
          "Watch the sequence of patterns carefully.",
          "Repeat the sequence exactly to progress.",
          "The patterns get longer and faster as you go."
        ];
      case 'Poker':
        return [
          "Standard poker hand rankings apply.",
          "Bet, call, or fold against the AI opponent.",
          "Try to win the most chips by the end of the game."
        ];
      case 'Traffic Manager':
        return [
          "Manage a complex 8-sector city intersection with turning lanes.",
          "Click the numbered sectors (1-8) to toggle traffic signals.",
          "Odd numbers (1,3,5,7) control turns; Even numbers (2,4,6,8) control straight paths.",
          "Select difficulty from EASY to INSANE (EXPERT) for varying challenges.",
          "Clear vehicles to earn points. Emergency vehicles are high priority.",
          "If any sector reaches its congestion limit, the system fails!"
        ];
      case 'Business Tycoon':
        return [
          "Invest in businesses and manage your resources.",
          "Compete with AI rivals for market dominance.",
          "Build the most profitable empire to win."
        ];
      case 'Emergency Hero':
        return [
          "Respond to disasters and allocate emergency resources.",
          "Prioritize tasks to save as many lives as possible.",
          "Manage limited time and personnel effectively."
        ];
      case 'Tactical Shooter':
        return [
          "Lead your squad through tactical missions.",
          "Neutralize threats and complete objectives.",
          "Use cover and strategy to ensure mission success."
        ];
      default:
        return [
          "Follow the instructions on the screen to play.",
          "Complete the goal to win the game.",
          "The game gets harder as you play better."
        ];
    }
  };

  const rules = getRules(game.title);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="max-w-2xl mx-auto w-full"
    >
      <div className="glass-panel border-2 border-white/10 rounded-[2.5rem] p-8 sm:p-12 relative overflow-hidden">
        {/* Background Glow */}
        <div className={`absolute top-0 right-0 w-64 h-64 bg-gradient-to-br ${game.color} opacity-10 blur-[80px] rounded-full`} />
        
        <div className="relative z-10">
          <div className="flex items-center gap-6 mb-8">
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${game.color} flex items-center justify-center shadow-lg`}>
              {game.icon}
            </div>
            <div>
              <h2 className="text-3xl font-black tracking-tighter uppercase italic text-white">{game.title}</h2>
              <div className="flex items-center gap-2 mt-1">
                <Shield className="w-3 h-3 text-cyan-400" />
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest">Protocol Initialized // {game.difficulty}</span>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-xs font-bold tracking-[0.3em] text-white/40 uppercase mb-4 flex items-center gap-2">
                <Info className="w-4 h-4" /> Mission Objective
              </h3>
              <p className="text-lg text-white/80 font-serif italic leading-relaxed">
                {game.description}
              </p>
            </div>

            <div>
              <h3 className="text-xs font-bold tracking-[0.3em] text-white/40 uppercase mb-4 flex items-center gap-2">
                <Target className="w-4 h-4" /> Operational Rules
              </h3>
              <ul className="space-y-4">
                {rules.map((rule, i) => (
                  <motion.li 
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + i * 0.1 }}
                    className="flex items-start gap-3 text-sm text-white/60 font-mono"
                  >
                    <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,1)]" />
                    {rule}
                  </motion.li>
                ))}
              </ul>
            </div>

            <div className="pt-8 flex flex-col sm:flex-row gap-4">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onStart}
                className={`flex-1 py-4 rounded-2xl bg-gradient-to-r ${game.color} text-white font-black tracking-widest uppercase flex items-center justify-center gap-3 shadow-lg hover:shadow-cyan-500/20 transition-all`}
              >
                <Play className="w-5 h-5 fill-current" />
                Initialize Game
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onBack}
                className="px-8 py-4 rounded-2xl bg-white/5 border border-white/10 text-white/60 font-bold tracking-widest uppercase hover:bg-white/10 transition-all"
              >
                Abort
              </motion.button>
            </div>
          </div>
        </div>

        {/* HUD Elements */}
        <div className="absolute bottom-4 right-8 opacity-20">
          <Gamepad2 className="w-24 h-24 text-white" />
        </div>
      </div>
    </motion.div>
  );
};

export default GameInstructions;
