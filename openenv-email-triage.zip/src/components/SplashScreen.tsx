import React from 'react';
import { motion } from 'motion/react';
import { Play, Shield, Zap, Cpu } from 'lucide-react';

interface SplashScreenProps {
  onStart: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#0a0a1a] p-4 overflow-hidden">
      {/* Immersive Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a3a] via-[#0a0a1a] to-[#1a1a3a]" />
      <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-purple-600/20 blur-[120px] rounded-full animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-blue-600/20 blur-[120px] rounded-full animate-pulse" />
      
      {/* Floating Decorative Elements */}
      <motion.div 
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute top-20 right-20 w-32 h-32 border border-white/10 rounded-full"
      />
      <motion.div 
        animate={{ rotate: -360 }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-20 left-20 w-48 h-48 border border-white/5 rounded-full"
      />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-[400px] lg:max-w-4xl lg:aspect-auto lg:min-h-[600px] bg-white/5 backdrop-blur-2xl rounded-[3.5rem] relative shadow-[0_40px_100px_rgba(0,0,0,0.5)] border border-white/10 overflow-hidden flex flex-col lg:flex-row lg:items-center lg:p-12"
      >
        {/* Status Bar Mock - Hidden on Desktop */}
        <div className="h-10 flex lg:hidden justify-between items-center px-10 pt-4">
          <span className="text-[10px] font-bold text-white/40">9:41</span>
          <div className="flex gap-1.5 items-center">
            <div className="w-4 h-2.5 border border-white/30 rounded-[2px]" />
            <div className="w-3 h-3 bg-white/30 rounded-full" />
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex flex-col items-center justify-center px-8 text-center pt-10 lg:pt-0">
          <h1 className="text-4xl lg:text-6xl font-black text-white mb-12 tracking-tight leading-tight uppercase italic">
            Nexus<br/>Interface
          </h1>

          {/* Robot Character Visual */}
          <motion.div
            animate={{ 
              y: [0, -15, 0],
              rotate: [0, 2, -2, 0]
            }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="relative w-56 h-56 lg:w-64 lg:h-64 mb-12"
          >
            {/* Robot Body */}
            <div className="absolute inset-0 bg-white rounded-full shadow-[0_20px_40px_rgba(0,0,0,0.3)] flex items-center justify-center overflow-hidden">
              <div className="w-full h-full bg-gradient-to-b from-white to-gray-100 p-8">
                {/* Eyes/Face */}
                <div className="flex justify-center gap-6 mt-10 lg:mt-12">
                  <div className="w-6 h-6 lg:w-8 lg:h-8 bg-[#5d5fef] rounded-full animate-pulse" />
                  <div className="w-6 h-6 lg:w-8 lg:h-8 bg-[#5d5fef] rounded-full animate-pulse" />
                </div>
                {/* Mouth */}
                <div className="w-12 h-2 lg:w-16 lg:h-3 bg-[#5d5fef]/20 rounded-full mx-auto mt-4" />
              </div>
            </div>
            {/* Arms */}
            <div className="absolute -left-4 top-1/2 -translate-y-1/2 w-10 h-16 lg:w-12 lg:h-20 bg-white rounded-full shadow-lg transform -rotate-12" />
            <div className="absolute -right-4 top-1/2 -translate-y-1/2 w-10 h-16 lg:w-12 lg:h-20 bg-white rounded-full shadow-lg transform rotate-12" />
            {/* Glow */}
            <div className="absolute inset-0 bg-purple-500/20 blur-3xl -z-10 rounded-full" />
          </motion.div>

          {/* Version Pill */}
          <div className="bg-white/10 backdrop-blur-md px-6 py-2 rounded-full border border-white/10 mb-8">
            <span className="text-[10px] lg:text-xs font-black text-white/60 uppercase tracking-[0.3em]">System_Core_V2.5</span>
          </div>

          <p className="text-white/50 text-xs lg:text-sm font-medium leading-relaxed max-w-[250px] lg:max-w-[300px] italic">
            Initializing neural interface...<br/>Ready for synaptic connection.
          </p>
        </div>

        {/* Footer Action */}
        <div className="p-8 pb-12 lg:pb-16">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onStart}
            className="w-full bg-white text-black py-5 rounded-2xl font-black text-sm lg:text-base tracking-[0.2em] uppercase shadow-xl transition-all flex items-center justify-center hover:bg-cyan-400 transition-colors"
          >
            Initialize System
          </motion.button>
        </div>

        {/* Home Indicator - Hidden on Desktop */}
        <div className="h-1 w-24 bg-white/20 rounded-full mx-auto mb-4 lg:hidden" />
      </motion.div>
    </div>
  );
};

export default SplashScreen;
