import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  TrafficCone, 
  Zap, 
  Heart,
  Activity, 
  AlertTriangle, 
  Truck, 
  Car, 
  Play, 
  Pause, 
  RefreshCw, 
  Cpu,
  User,
  Info,
  Lightbulb,
  Trophy,
  XCircle,
  MessageSquare,
  Navigation,
  ShieldAlert,
  Timer,
  Building2,
  Trees,
  ArrowUp,
  ArrowUpRight,
  Plus,
  Crosshair
} from 'lucide-react';
import { sounds } from '../lib/sounds';
import { GoogleGenAI } from "@google/genai";
import confetti from 'canvas-confetti';

interface Vehicle {
  id: string;
  roadId: number; // 1-8 (1,3,5,7 are turns; 2,4,6,8 are straight)
  progress: number; // 0 to 100
  type: 'car' | 'bus' | 'emergency';
  speed: number;
  isStopped: boolean;
  color: string;
  lane: number;
}

interface Sector {
  id: number;
  name: string;
  state: 'GREEN' | 'RED';
  congestion: number;
  vehicles: Vehicle[];
  isTurn: boolean;
}

const VEHICLE_COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899', '#ffffff', '#94a3b8'];

export default function TrafficSimulator({ difficulty: initialDifficulty = "EASY" }: { difficulty?: string }) {
  const [difficulty, setDifficulty] = useState(initialDifficulty);
  const [sectors, setSectors] = useState<Sector[]>([
    { id: 1, name: 'North Turn', state: 'RED', congestion: 0, vehicles: [], isTurn: true },
    { id: 2, name: 'North Straight', state: 'RED', congestion: 0, vehicles: [], isTurn: false },
    { id: 3, name: 'East Turn', state: 'RED', congestion: 0, vehicles: [], isTurn: true },
    { id: 4, name: 'East Straight', state: 'RED', congestion: 0, vehicles: [], isTurn: false },
    { id: 5, name: 'South Turn', state: 'RED', congestion: 0, vehicles: [], isTurn: true },
    { id: 6, name: 'South Straight', state: 'RED', congestion: 0, vehicles: [], isTurn: false },
    { id: 7, name: 'West Turn', state: 'RED', congestion: 0, vehicles: [], isTurn: true },
    { id: 8, name: 'West Straight', state: 'RED', congestion: 0, vehicles: [], isTurn: false },
  ]);

  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [winStatus, setWinStatus] = useState<'WIN' | 'LOSE' | null>(null);
  const [showInstructions, setShowInstructions] = useState(true);
  const [aiFeedback, setAiFeedback] = useState<string>("");
  const [isGeneratingFeedback, setIsGeneratingFeedback] = useState(false);
  const [timeElapsed, setTimeElapsed] = useState(0);
  
  const gameLoopRef = useRef<number | null>(null);
  const lastSpawnRef = useRef<number>(0);

  const difficultySettings = {
    'EASY': { spawnRate: 2500, congestionRate: 0.3, maxCongestion: 100 },
    'MEDIUM': { spawnRate: 1800, congestionRate: 0.8, maxCongestion: 100 },
    'HARD': { spawnRate: 1200, congestionRate: 1.5, maxCongestion: 90 },
    'EXPERT': { spawnRate: 600, congestionRate: 3.5, maxCongestion: 80 }, // INSANE
  }[difficulty.toUpperCase()] || { spawnRate: 2500, congestionRate: 0.3, maxCongestion: 100 };

  const toggleSector = (id: number) => {
    if (isGameOver || !isPlaying) return;
    sounds.playClick();
    setSectors(prev => prev.map(s => 
      s.id === id 
        ? { ...s, state: s.state === 'GREEN' ? 'RED' : 'GREEN' }
        : s
    ));
  };

  const spawnVehicle = useCallback(() => {
    const sectorId = Math.floor(Math.random() * 8) + 1;
    const typeRoll = Math.random();
    const type: Vehicle['type'] = typeRoll > 0.95 ? 'emergency' : typeRoll > 0.8 ? 'bus' : 'car';
    
    const newVehicle: Vehicle = {
      id: Math.random().toString(36).substr(2, 9),
      roadId: sectorId,
      progress: 0,
      type,
      speed: (type === 'emergency' ? 1.6 : type === 'bus' ? 0.6 : 1.0) * (difficulty === 'EXPERT' ? 1.3 : 1),
      isStopped: false,
      color: type === 'emergency' ? '#ff0000' : VEHICLE_COLORS[Math.floor(Math.random() * VEHICLE_COLORS.length)],
      lane: Math.floor(Math.random() * 2)
    };

    setSectors(prev => prev.map(s => 
      s.id === sectorId 
        ? { ...s, vehicles: [...s.vehicles, newVehicle] }
        : s
    ));
  }, [difficulty]);

  const generateFeedback = async (status: 'WIN' | 'LOSE') => {
    setIsGeneratingFeedback(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const prompt = `
        The player just finished a Traffic Manager game on ${difficulty} difficulty.
        Status: ${status}
        Final Score: ${score}
        Time Survived: ${Math.floor(timeElapsed)}s
        
        Provide a short, intense analysis of their traffic management skills. 
        If they played on INSANE (EXPERT), be very critical or highly impressed.
        Keep it under 100 words. Use a professional but high-stakes tone.
      `;
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
      });
      setAiFeedback(response.text || "Simulation concluded. Data archived.");
    } catch (error) {
      setAiFeedback("The AI is currently analyzing the gridlock. Stand by.");
    } finally {
      setIsGeneratingFeedback(false);
    }
  };

  const endGame = (status: 'WIN' | 'LOSE') => {
    setIsPlaying(false);
    setIsGameOver(true);
    setWinStatus(status);
    sounds.playGameOver(status === 'WIN');
    if (status === 'WIN') confetti();
    generateFeedback(status);
  };

  const updateGame = useCallback(() => {
    if (!isPlaying || isGameOver) return;

    const now = Date.now();
    if (now - lastSpawnRef.current > difficultySettings.spawnRate) {
      spawnVehicle();
      lastSpawnRef.current = now;
    }

    setSectors(prev => {
      let gameOverTriggered = false;
      const updatedSectors = prev.map(sector => {
        const stopLine = 35; 
        let newCongestion = sector.congestion;
        
        const updatedVehicles = sector.vehicles.map((v, idx) => {
          let canMove = true;
          
          if (sector.state === 'RED' && v.progress >= stopLine && v.progress < stopLine + 5) {
            canMove = false;
          }

          if (idx > 0) {
            const vehicleInFront = sector.vehicles[idx - 1];
            if (vehicleInFront.progress - v.progress < 12) {
              canMove = false;
            }
          }

          if (canMove) {
            return { ...v, progress: v.progress + v.speed, isStopped: false };
          } else {
            return { ...v, isStopped: true };
          }
        }).filter(v => {
          if (v.progress >= 100) {
            setScore(s => s + (v.type === 'emergency' ? 150 : v.type === 'bus' ? 50 : 25));
            return false;
          }
          return true;
        });

        const stoppedCount = updatedVehicles.filter(v => v.isStopped).length;
        if (stoppedCount > 2) {
          newCongestion += difficultySettings.congestionRate;
        } else {
          newCongestion = Math.max(0, newCongestion - 1.5);
        }

        if (newCongestion >= difficultySettings.maxCongestion) {
          gameOverTriggered = true;
        }

        return { ...sector, vehicles: updatedVehicles, congestion: newCongestion };
      });

      if (gameOverTriggered) {
        endGame('LOSE');
      }

      return updatedSectors;
    });

    setTimeElapsed(prev => prev + 0.016);
    gameLoopRef.current = requestAnimationFrame(updateGame);
  }, [isPlaying, isGameOver, spawnVehicle, difficultySettings, difficulty]);

  useEffect(() => {
    if (isPlaying) {
      gameLoopRef.current = requestAnimationFrame(updateGame);
    } else {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    }
    return () => { if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current); };
  }, [isPlaying, updateGame]);

  const resetGame = () => {
    setSectors(prev => prev.map(s => ({ ...s, state: 'RED', congestion: 0, vehicles: [] })));
    setScore(0);
    setTimeElapsed(0);
    setIsGameOver(false);
    setWinStatus(null);
    setIsPlaying(true);
  };

  return (
    <div className="p-4 sm:p-8 bg-[#1a1c1e] rounded-[3rem] border border-white/5 shadow-[0_0_100px_rgba(0,0,0,0.5)] relative overflow-hidden h-[900px] max-h-[95vh] flex flex-col font-sans">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(59,130,246,0.05),transparent)] pointer-events-none" />
      
      <AnimatePresence>
        {isGameOver && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[110] bg-black/95 backdrop-blur-3xl p-12 flex flex-col items-center justify-center text-center"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              className="max-w-xl w-full space-y-10"
            >
              <div className={`w-32 h-32 rounded-full mx-auto flex items-center justify-center border-4 ${winStatus === 'WIN' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-red-500/10 border-red-500/30 text-red-400'}`}>
                {winStatus === 'WIN' ? <Trophy className="w-16 h-16" /> : <ShieldAlert className="w-16 h-16" />}
              </div>

              <div className="space-y-4">
                <h2 className="text-6xl font-black uppercase italic tracking-tighter text-white">
                  {winStatus === 'WIN' ? 'Grid Master' : 'System Overload'}
                </h2>
                <div className="flex justify-center gap-8">
                  <div className="text-left">
                    <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest block">Score</span>
                    <span className="text-3xl font-black text-cyan-400 font-mono">{score.toLocaleString()}</span>
                  </div>
                  <div className="text-left">
                    <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest block">Survival</span>
                    <span className="text-3xl font-black text-white font-mono">{Math.floor(timeElapsed)}s</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 rounded-[2.5rem] p-8 border border-white/10 space-y-6 text-left relative overflow-hidden">
                <div className="flex items-center gap-3 text-cyan-400 relative z-10">
                  <MessageSquare className="w-5 h-5" />
                  <span className="text-xs font-black uppercase tracking-[0.2em]">Post-Simulation Tactical Review</span>
                </div>
                
                {isGeneratingFeedback ? (
                  <div className="space-y-3 py-6 relative z-10">
                    <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        animate={{ x: ['-100%', '100%'] }}
                        transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                        className="h-full w-1/2 bg-cyan-500"
                      />
                    </div>
                    <p className="text-[10px] text-white/20 uppercase font-black tracking-widest animate-pulse">Neural network analyzing grid patterns...</p>
                  </div>
                ) : (
                  <p className="text-lg text-white/80 leading-relaxed italic font-serif relative z-10">
                    "{aiFeedback}"
                  </p>
                )}
                <div className="absolute top-0 right-0 p-4 opacity-5">
                  <Cpu className="w-32 h-32" />
                </div>
              </div>

              <button 
                onClick={resetGame}
                className="w-full py-6 bg-white text-black rounded-3xl font-black uppercase tracking-[0.3em] hover:bg-cyan-400 transition-all active:scale-95 shadow-[0_20px_50px_rgba(0,0,0,0.3)]"
              >
                Re-Initialize Grid
              </button>
            </motion.div>
          </motion.div>
        )}

        {showInstructions && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[100] bg-[#0f1113]/98 backdrop-blur-3xl p-12 flex flex-col items-center justify-center text-center"
          >
            <div className="w-24 h-24 bg-cyan-500/10 rounded-[2rem] flex items-center justify-center mb-10 border border-cyan-500/20 shadow-[0_0_50px_rgba(6,182,212,0.1)]">
              <Navigation className="w-12 h-12 text-cyan-400" />
            </div>
            
            <h3 className="text-5xl font-black text-white italic tracking-tighter uppercase mb-8">CitySim: Tactical Traffic</h3>
            
            <div className="grid grid-cols-2 gap-4 mb-12 w-full max-w-2xl">
              {['EASY', 'MEDIUM', 'HARD', 'EXPERT'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setDifficulty(lvl)}
                  className={`p-6 rounded-3xl border-2 transition-all flex flex-col items-start gap-2 ${
                    difficulty === lvl 
                      ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_30px_rgba(6,182,212,0.2)]' 
                      : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'
                  }`}
                >
                  <span className="text-xs font-black tracking-[0.2em]">{lvl === 'EXPERT' ? 'INSANE' : lvl}</span>
                  <span className="text-[10px] opacity-60 text-left">
                    {lvl === 'EASY' && 'Standard flow, high tolerance.'}
                    {lvl === 'MEDIUM' && 'Increased density, normal logic.'}
                    {lvl === 'HARD' && 'Critical volume, low margin for error.'}
                    {lvl === 'EXPERT' && 'MAXIMUM CHAOS. SYSTEM OVERLOAD.'}
                  </span>
                </button>
              ))}
            </div>

            <button 
              onClick={() => {
                setShowInstructions(false);
                setIsPlaying(true);
              }}
              className="bg-cyan-500 text-black px-20 py-6 rounded-3xl font-black uppercase tracking-[0.4em] hover:bg-white transition-all shadow-[0_20px_40px_rgba(6,182,212,0.3)]"
            >
              Start Simulation
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Navigation / Stats */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-10 relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 shadow-inner">
            <Plus className="w-8 h-8 text-red-500" />
          </div>
          <div>
            <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic flex items-center gap-3">
              CitySim <span className="text-cyan-400">v2.4</span>
            </h2>
            <div className="flex items-center gap-3">
              <div className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest border ${
                difficulty === 'EXPERT' ? 'bg-red-500/20 border-red-500/50 text-red-400 animate-pulse' : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
              }`}>
                {difficulty === 'EXPERT' ? 'INSANE MODE' : `${difficulty} MODE`}
              </div>
              <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Sector_88 // Central_Hub</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-8 bg-white/5 p-4 rounded-[2rem] border border-white/10">
          <div className="flex flex-col items-start px-4">
            <span className="text-[8px] font-bold text-white/20 uppercase tracking-widest">Total_Score</span>
            <span className="text-3xl font-black text-cyan-400 font-mono tracking-tighter">{score.toLocaleString()}</span>
          </div>
          <div className="w-px h-10 bg-white/10" />
          <div className="flex flex-col items-start px-4">
            <span className="text-[8px] font-bold text-white/20 uppercase tracking-widest">System_Time</span>
            <span className="text-3xl font-black text-white font-mono tracking-tighter">{Math.floor(timeElapsed)}s</span>
          </div>
          <button 
            onClick={() => setIsPlaying(!isPlaying)}
            className="w-14 h-14 bg-white/10 hover:bg-white rounded-2xl transition-all flex items-center justify-center group"
          >
            {isPlaying ? <Pause className="w-6 h-6 text-white group-hover:text-black" /> : <Play className="w-6 h-6 text-white group-hover:text-black" />}
          </button>
        </div>
      </div>

      {/* Main Simulation Grid */}
      <div className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-10 relative z-10">
        {/* High-Fidelity City Environment */}
        <div className="xl:col-span-8 bg-[#242628] rounded-[3.5rem] border-[12px] border-[#1e2022] relative overflow-hidden shadow-2xl flex items-center justify-center min-h-[550px]">
          
          {/* Urban Details (Grass, Parking, Buildings) */}
          <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-[160px] p-8">
            {/* Top Left: Hospital/Emergency Zone */}
            <div className="bg-[#2d3a2d] rounded-[3rem] border-4 border-[#1e2a1e] relative flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
              <div className="flex flex-col items-center gap-2">
                <div className="w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(239,68,68,0.3)]">
                  <Plus className="w-10 h-10 text-white" />
                </div>
                <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">HOSPITAL_ZONE</span>
              </div>
              {/* Parking Lot */}
              <div className="absolute bottom-4 right-4 w-24 h-16 border border-white/10 rounded-lg grid grid-cols-4 gap-1 p-1">
                {[...Array(8)].map((_, i) => <div key={i} className="border-r border-white/20 h-full" />)}
              </div>
            </div>
            {/* Top Right: Office Complex */}
            <div className="bg-[#2d2f31] rounded-[3rem] border-4 border-[#1e2022] relative flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/asfalt-dark.png')]" />
              <Building2 className="w-20 h-20 text-white/5" />
              <div className="absolute top-6 left-6 flex gap-2">
                <Trees className="w-6 h-6 text-emerald-900/40" />
                <Trees className="w-4 h-4 text-emerald-900/30 mt-2" />
              </div>
            </div>
            {/* Bottom Left: Park / Green Space */}
            <div className="bg-[#344a34] rounded-[3rem] border-4 border-[#243624] relative flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.05),transparent)]" />
              <div className="grid grid-cols-3 gap-8">
                <Trees className="w-10 h-10 text-emerald-950/40" />
                <Trees className="w-12 h-12 text-emerald-950/60" />
                <Trees className="w-8 h-8 text-emerald-950/30" />
              </div>
            </div>
            {/* Bottom Right: Commercial Hub */}
            <div className="bg-[#2d2f31] rounded-[3rem] border-4 border-[#1e2022] relative flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
              <div className="flex flex-col items-center gap-4">
                <div className="w-20 h-12 bg-cyan-500/10 rounded-xl border border-cyan-500/20 flex items-center justify-center">
                  <span className="text-[10px] font-black text-cyan-400">NEXUS_MALL</span>
                </div>
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-amber-500/20" />
                  <div className="w-3 h-3 rounded-full bg-cyan-500/20" />
                </div>
              </div>
            </div>
          </div>

          {/* Advanced Road Network */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {/* Horizontal Multi-Lane Road */}
            <div className="absolute w-full h-[140px] bg-[#313335] border-y-[6px] border-[#3d3f41] flex flex-col justify-center items-center gap-1">
              <div className="w-full h-px border-t-2 border-dashed border-white/10" />
              <div className="w-full h-px border-t-2 border-dashed border-yellow-500/30" />
              <div className="w-full h-px border-t-2 border-dashed border-white/10" />
              
              {/* Complex Crosswalks */}
              <div className="absolute left-[calc(50%-140px)] h-full w-12 flex flex-col justify-between py-2">
                {[...Array(8)].map((_, i) => <div key={i} className="h-2 w-full bg-white/20" />)}
              </div>
              <div className="absolute right-[calc(50%-140px)] h-full w-12 flex flex-col justify-between py-2">
                {[...Array(8)].map((_, i) => <div key={i} className="h-2 w-full bg-white/20" />)}
              </div>
            </div>
            
            {/* Vertical Multi-Lane Road */}
            <div className="absolute h-full w-[140px] bg-[#313335] border-x-[6px] border-[#3d3f41] flex justify-center items-center gap-1">
              <div className="h-full w-px border-l-2 border-dashed border-white/10" />
              <div className="h-full w-px border-l-2 border-dashed border-yellow-500/30" />
              <div className="h-full w-px border-l-2 border-dashed border-white/10" />
              
              {/* Complex Crosswalks */}
              <div className="absolute top-[calc(50%-140px)] w-full h-12 flex justify-between px-2">
                {[...Array(8)].map((_, i) => <div key={i} className="w-2 h-full bg-white/20" />)}
              </div>
              <div className="absolute bottom-[calc(50%-140px)] w-full h-12 flex justify-between px-2">
                {[...Array(8)].map((_, i) => <div key={i} className="w-2 h-full bg-white/20" />)}
              </div>
            </div>
            
            {/* Intersection Hub */}
            <div className="absolute w-[140px] h-[140px] bg-[#313335] flex items-center justify-center">
              {/* Skid Marks / Wear */}
              <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/diagmonds-light.png')]" />
              <Crosshair className="w-10 h-10 text-white/5" />
            </div>
          </div>

          {/* Vehicles Layer */}
          <div className="absolute inset-0 pointer-events-none">
            {sectors.map(sector => (
              <div key={sector.id} className="absolute inset-0">
                {sector.vehicles.map(v => {
                  let x = 50;
                  let y = 50;
                  let rotation = 0;
                  
                  // Road mapping logic
                  if (sector.id === 1 || sector.id === 2) { // North
                    y = v.progress; rotation = 180;
                    x = 50 + (sector.isTurn ? -5 : 5);
                  }
                  else if (sector.id === 3 || sector.id === 4) { // East
                    x = 100 - v.progress; rotation = 270;
                    y = 50 + (sector.isTurn ? -5 : 5);
                  }
                  else if (sector.id === 5 || sector.id === 6) { // South
                    y = 100 - v.progress; rotation = 0;
                    x = 50 + (sector.isTurn ? 5 : -5);
                  }
                  else if (sector.id === 7 || sector.id === 8) { // West
                    x = v.progress; rotation = 90;
                    y = 50 + (sector.isTurn ? 5 : -5);
                  }

                  return (
                    <motion.div
                      key={v.id}
                      initial={false}
                      animate={{ left: `${x}%`, top: `${y}%`, rotate: rotation }}
                      transition={{ duration: 0.016, ease: "linear" }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-lg shadow-2xl border border-black/30 ${
                        v.type === 'emergency' ? 'w-8 h-12' : v.type === 'bus' ? 'w-9 h-18' : 'w-7 h-11'
                      }`}
                      style={{ backgroundColor: v.color }}
                    >
                      {/* High-Detail Vehicle Features */}
                      <div className="absolute top-1 left-1 right-1 h-3 bg-black/50 rounded-sm" /> {/* Windshield */}
                      <div className="absolute bottom-1 left-1 right-1 h-1 bg-black/20 rounded-full" /> {/* Rear Bumper */}
                      
                      {v.type === 'emergency' && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="absolute -top-3 w-full flex justify-between px-1">
                            <div className="w-2 h-2 bg-blue-500 rounded-full animate-ping shadow-[0_0_15px_#3b82f6]" />
                            <div className="w-2 h-2 bg-red-500 rounded-full animate-ping delay-150 shadow-[0_0_15px_#ef4444]" />
                          </div>
                          <Plus className="w-5 h-5 text-white/80" />
                        </div>
                      )}

                      {/* Headlights (Glow) */}
                      <div className="absolute -top-2 left-0 w-full flex justify-between px-1">
                        <div className="w-2 h-2 bg-white rounded-full blur-[2px] shadow-[0_0_10px_white]" />
                        <div className="w-2 h-2 bg-white rounded-full blur-[2px] shadow-[0_0_10px_white]" />
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Tactical Overlay (Arrows & Numbers) */}
          <div className="absolute inset-0 pointer-events-none">
            {/* North Arrows */}
            <div className="absolute top-[calc(50%-180px)] left-[calc(50%-45px)] flex flex-col items-center gap-1 opacity-40">
              <div className="flex items-center gap-8">
                <div className="flex flex-col items-center">
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded mb-1">1</span>
                  <ArrowUpRight className="w-6 h-6 text-emerald-400 rotate-45" />
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded mb-1">2</span>
                  <ArrowUp className="w-6 h-6 text-orange-400" />
                </div>
              </div>
            </div>
            {/* East Arrows */}
            <div className="absolute right-[calc(50%-180px)] top-[calc(50%-45px)] flex items-center gap-1 opacity-40">
              <div className="flex flex-col gap-8">
                <div className="flex items-center gap-2">
                  <ArrowUpRight className="w-6 h-6 text-emerald-400 rotate-[135deg]" />
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded">3</span>
                </div>
                <div className="flex items-center gap-2">
                  <ArrowUp className="w-6 h-6 text-orange-400 rotate-90" />
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded">4</span>
                </div>
              </div>
            </div>
            {/* South Arrows */}
            <div className="absolute bottom-[calc(50%-180px)] right-[calc(50%-45px)] flex flex-col items-center gap-1 opacity-40">
              <div className="flex items-center gap-8">
                <div className="flex flex-col items-center">
                  <ArrowUp className="w-6 h-6 text-orange-400 rotate-180" />
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded mt-1">6</span>
                </div>
                <div className="flex flex-col items-center">
                  <ArrowUpRight className="w-6 h-6 text-emerald-400 rotate-[225deg]" />
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded mt-1">5</span>
                </div>
              </div>
            </div>
            {/* West Arrows */}
            <div className="absolute left-[calc(50%-180px)] bottom-[calc(50%-45px)] flex items-center gap-1 opacity-40">
              <div className="flex flex-col gap-8">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded">8</span>
                  <ArrowUp className="w-6 h-6 text-orange-400 rotate-[270deg]" />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-white bg-black/60 px-2 rounded">7</span>
                  <ArrowUpRight className="w-6 h-6 text-emerald-400 rotate-[315deg]" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Advanced Tactical Control Panel */}
        <div className="xl:col-span-4 flex flex-col gap-8 max-h-[750px] overflow-y-auto pr-2 custom-scrollbar">
          <div className="bg-white/5 rounded-[3rem] border border-white/10 p-8 flex flex-col gap-8 shadow-2xl">
            <div className="flex justify-between items-center">
              <h3 className="text-xs font-black text-white/30 uppercase tracking-[0.4em] flex items-center gap-3">
                <Cpu className="w-5 h-5" /> Neural Grid Control
              </h3>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-[8px] font-black text-red-400 uppercase tracking-widest">Live_Sync</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {sectors.map((sector) => (
                <button
                  key={sector.id}
                  onClick={() => toggleSector(sector.id)}
                  className={`relative p-5 rounded-[2rem] border-2 transition-all flex flex-col gap-4 group overflow-hidden ${
                    sector.state === 'GREEN' 
                      ? 'bg-emerald-500/10 border-emerald-500/40 shadow-[0_10px_30px_rgba(16,185,129,0.1)]' 
                      : 'bg-red-500/10 border-red-500/40 shadow-[0_10px_30px_rgba(239,68,68,0.1)]'
                  }`}
                >
                  <div className="flex justify-between items-start relative z-10">
                    <div className="flex flex-col items-start">
                      <span className="text-[8px] font-black text-white/30 uppercase tracking-[0.2em]">Vector_{sector.id}</span>
                      <span className="text-xs font-black text-white uppercase italic tracking-tighter">{sector.name}</span>
                    </div>
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 ${
                      sector.state === 'GREEN' ? 'bg-emerald-500 text-black' : 'bg-red-500 text-white'
                    }`}>
                      <span className="text-lg font-black">{sector.id}</span>
                    </div>
                  </div>

                  <div className="space-y-2 relative z-10">
                    <div className="flex justify-between items-center">
                      <span className="text-[8px] font-black text-white/20 uppercase tracking-widest">Load_Factor</span>
                      <span className={`text-[10px] font-mono font-black ${sector.congestion > 70 ? 'text-red-400' : 'text-cyan-400'}`}>
                        {Math.round(sector.congestion)}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden border border-white/5">
                      <motion.div 
                        animate={{ width: `${sector.congestion}%` }}
                        className={`h-full transition-colors ${sector.congestion > 70 ? 'bg-red-500 shadow-[0_0_15px_#ef4444]' : 'bg-cyan-500 shadow-[0_0_15px_#06b6d4]'}`}
                      />
                    </div>
                  </div>

                  <div className={`absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity bg-gradient-to-br ${
                    sector.state === 'GREEN' ? 'from-emerald-500' : 'from-red-500'
                  }`} />
                </button>
              ))}
            </div>

            <div className="bg-black/40 rounded-[2rem] p-6 border border-white/5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Timer className="w-5 h-5 text-cyan-400" />
                  <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Neural_Load</span>
                </div>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className={`w-1 h-3 rounded-full ${i < 3 ? 'bg-cyan-500' : 'bg-white/10'}`} />
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Zap className="w-5 h-5 text-amber-400" />
                  <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Grid_Stability</span>
                </div>
                <span className="text-[10px] font-mono font-black text-emerald-400">99.8%</span>
              </div>
            </div>
          </div>

          <div className="flex-1 bg-white/5 rounded-[3rem] border border-white/10 p-8 flex flex-col gap-6 shadow-2xl">
            <h3 className="text-xs font-black text-white/30 uppercase tracking-[0.4em] flex items-center gap-3">
              <Activity className="w-5 h-5" /> Real-Time Telemetry
            </h3>
            <div className="flex-1 space-y-4 overflow-y-auto custom-scrollbar pr-4">
              {sectors.flatMap(s => s.vehicles).sort((a, b) => b.progress - a.progress).slice(0, 8).map((v, i) => (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={v.id} 
                  className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shadow-inner" style={{ backgroundColor: `${v.color}20`, color: v.color }}>
                      {v.type === 'emergency' ? <ShieldAlert className="w-5 h-5" /> : 
                       v.type === 'bus' ? <Truck className="w-5 h-5" /> : 
                       <Car className="w-5 h-5" />}
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[11px] font-black text-white uppercase tracking-tighter">
                        {v.type.toUpperCase()} // V_{v.roadId}
                      </span>
                      <span className="text-[8px] text-white/30 uppercase font-black tracking-widest">Inbound_Vector</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-xs font-mono font-black text-white/60">{Math.round(v.progress)}%</span>
                    <div className="w-12 h-1 bg-white/5 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-white/20" style={{ width: `${v.progress}%` }} />
                    </div>
                  </div>
                </motion.div>
              ))}
              {sectors.every(s => s.vehicles.length === 0) && (
                <div className="flex flex-col items-center justify-center h-full text-white/10 gap-4">
                  <Navigation className="w-12 h-12 opacity-10" />
                  <span className="text-xs font-black uppercase tracking-[0.3em]">No Active Vectors Detected</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
