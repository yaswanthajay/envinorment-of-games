import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Rocket, TrendingUp, AlertTriangle, Coins, Zap, History } from 'lucide-react';

export default function CrashGame() {
  const [multiplier, setMultiplier] = useState(1.00);
  const [isFlying, setIsFlying] = useState(false);
  const [isCrashed, setIsCrashed] = useState(false);
  const [bet, setBet] = useState(100);
  const [credits, setCredits] = useState(5000);
  const [history, setHistory] = useState<number[]>([]);
  const [cashedOut, setCashedOut] = useState<number | null>(null);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const crashPointRef = useRef<number>(0);

  const startFlight = () => {
    if (isFlying || credits < bet) return;
    
    setCredits(prev => prev - bet);
    setIsFlying(true);
    setIsCrashed(false);
    setMultiplier(1.00);
    setCashedOut(null);
    
    // Generate a random crash point with a house edge
    // Using a simple formula for crash games: 99 / (100 - random(0-99))
    const rand = Math.random() * 100;
    crashPointRef.current = Math.max(1.01, 99 / (100 - rand));
    
    let currentMult = 1.00;
    timerRef.current = setInterval(() => {
      currentMult += 0.01 * (currentMult * 0.5); // Accelerating growth
      setMultiplier(Number(currentMult.toFixed(2)));
      
      if (currentMult >= crashPointRef.current) {
        crash();
      }
    }, 100);
  };

  const crash = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsFlying(false);
    setIsCrashed(true);
    setHistory(prev => [multiplier, ...prev].slice(0, 10));
  };

  const cashOut = () => {
    if (!isFlying || cashedOut || isCrashed) return;
    
    const winAmount = Math.floor(bet * multiplier);
    setCredits(prev => prev + winAmount);
    setCashedOut(multiplier);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div className="flex flex-col h-full gap-8 p-8 relative overflow-hidden bg-[#050505]">
      {/* Immersive Space Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,#06b6d420,transparent_70%)]" />
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30" />
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyan-500/5 rounded-full blur-[120px]" 
        />
      </div>

      <div className="flex justify-between items-center bg-black/40 p-6 rounded-3xl border border-white/10 backdrop-blur-xl relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-cyan-500/20 rounded-2xl flex items-center justify-center border border-cyan-500/30">
            <Rocket className="text-cyan-400" />
          </div>
          <div>
            <h2 className="text-2xl font-black uppercase tracking-tighter italic">Nexus Crash</h2>
            <p className="text-[8px] font-mono text-white/30 uppercase tracking-[0.4em]">Node_Omega // Velocity_Protocol</p>
          </div>
        </div>

        <div className="flex gap-8">
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-black text-white/30 uppercase tracking-widest mb-1">Credits</span>
            <div className="flex items-center gap-2">
              <Coins className="text-amber-400" size={16} />
              <span className="text-2xl font-black tabular-nums">${credits.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-8 relative z-10">
        {/* Main Display */}
        <div className="flex-1 bg-black/60 rounded-[3rem] border border-white/10 p-12 flex flex-col items-center justify-center relative overflow-hidden">
          {/* Grid Lines */}
          <div className="absolute inset-0 opacity-5 pointer-events-none" 
            style={{ 
              backgroundImage: 'linear-gradient(rgba(6, 182, 212, 0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(6, 182, 212, 0.2) 1px, transparent 1px)',
              backgroundSize: '40px 40px'
            }} 
          />

          <AnimatePresence>
            {isCrashed && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center bg-red-500/10 backdrop-blur-md z-20"
              >
                <AlertTriangle className="text-red-500 w-24 h-24 mb-4 animate-bounce" />
                <h3 className="text-6xl font-black text-red-500 uppercase italic tracking-tighter">CRASHED!</h3>
                <p className="text-2xl font-black text-white/60 mt-2">at {multiplier}x</p>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="relative flex flex-col items-center">
            <motion.div 
              animate={isFlying ? { 
                y: [0, -20, 0],
                rotate: [0, 2, -2, 0]
              } : {}}
              transition={{ repeat: Infinity, duration: 2 }}
              className={`text-[12rem] font-black tracking-tighter tabular-nums leading-none ${
                isCrashed ? 'text-red-500/20' : cashedOut ? 'text-emerald-400' : 'text-white'
              }`}
            >
              {multiplier.toFixed(2)}<span className="text-4xl">x</span>
            </motion.div>
            
            {cashedOut && (
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                className="absolute -bottom-12 bg-emerald-500 text-black px-6 py-2 rounded-full font-black uppercase tracking-widest text-sm shadow-[0_0_30px_rgba(16,185,129,0.4)]"
              >
                Cashed Out @ {cashedOut}x
              </motion.div>
            )}
          </div>

          {/* Rocket Animation */}
          <div className="absolute bottom-24 left-24 right-24 h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              animate={isFlying ? { 
                width: `${Math.min(multiplier * 10, 100)}%` 
              } : { width: '0%' }}
              className="h-full bg-cyan-500 shadow-[0_0_20px_rgba(6,182,212,0.5)]" 
            />
          </div>

          <motion.div 
            animate={isFlying ? {
              x: Math.min(multiplier * 20, 400),
              y: -Math.min(multiplier * 20, 400),
              rotate: -45
            } : { x: 0, y: 0, rotate: -45 }}
            className="absolute bottom-32 left-32"
          >
            <Rocket 
              size={48} 
              className={`${isCrashed ? 'text-red-500/20' : 'text-cyan-400'} ${isFlying ? 'animate-pulse' : ''}`} 
            />
            {isFlying && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 w-1 h-24 bg-gradient-to-t from-transparent to-cyan-500/50 blur-sm" />
            )}
          </motion.div>
        </div>

        {/* Controls & History */}
        <div className="w-full lg:w-80 flex flex-col gap-6">
          <div className="bg-black/40 p-8 rounded-[2rem] border border-white/10 backdrop-blur-xl">
            <div className="flex items-center gap-3 mb-6">
              <Zap className="text-cyan-400" size={16} />
              <span className="text-[10px] font-black uppercase tracking-widest">Betting Terminal</span>
            </div>

            <div className="flex flex-col gap-4 mb-8">
              <div className="flex flex-col gap-2">
                <span className="text-[10px] font-black text-white/20 uppercase tracking-widest">Bet Amount</span>
                <div className="flex items-center gap-2 bg-black/40 p-4 rounded-2xl border border-white/10">
                  <Coins size={16} className="text-amber-400" />
                  <input 
                    type="number" 
                    value={bet}
                    onChange={(e) => setBet(Number(e.target.value))}
                    disabled={isFlying}
                    className="bg-transparent border-none outline-none text-xl font-black w-full tabular-nums"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[50, 100, 500, 1000].map(val => (
                  <button 
                    key={val}
                    onClick={() => setBet(val)}
                    disabled={isFlying}
                    className="py-2 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/10 transition-all"
                  >
                    ${val}
                  </button>
                ))}
              </div>
            </div>

            {!isFlying ? (
              <button 
                onClick={startFlight}
                disabled={credits < bet}
                className="w-full py-6 bg-cyan-500 text-black font-black rounded-[2rem] hover:bg-white transition-all uppercase tracking-widest text-sm shadow-[0_0_40px_rgba(6,182,212,0.4)] active:scale-95 disabled:opacity-50"
              >
                LAUNCH_ROCKET
              </button>
            ) : (
              <button 
                onClick={cashOut}
                disabled={!!cashedOut || isCrashed}
                className="w-full py-6 bg-emerald-500 text-black font-black rounded-[2rem] hover:bg-white transition-all uppercase tracking-widest text-sm shadow-[0_0_40px_rgba(16,185,129,0.4)] active:scale-95 disabled:opacity-50"
              >
                CASH_OUT @ {(multiplier * bet).toFixed(0)}
              </button>
            )}
          </div>

          <div className="flex-1 bg-black/40 p-8 rounded-[2rem] border border-white/10 backdrop-blur-xl">
            <div className="flex items-center gap-3 mb-6">
              <History className="text-white/40" size={16} />
              <span className="text-[10px] font-black uppercase tracking-widest text-white/40">Recent Crashes</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {history.map((h, i) => (
                <div 
                  key={i} 
                  className={`px-3 py-1 rounded-lg text-[10px] font-black tabular-nums border ${
                    h >= 2 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'
                  }`}
                >
                  {h.toFixed(2)}x
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
