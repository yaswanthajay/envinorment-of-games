import React, { useState } from 'react';
import CyberStrike from './CyberStrike';
import { 
  CyberStrikeLobby, 
  CyberStrikeModeSelection, 
  CyberStrikeSquadLobby, 
  CyberStrikeOperatorDetails,
  CyberStrikeWorldSelection,
  Operator,
  OPERATORS,
  World,
  WORLDS
} from './CyberStrikeUI';

export default function CyberStrikeContainer({ difficulty }: { difficulty: string }) {
  const [view, setView] = useState<'LOBBY' | 'MODES' | 'WORLDS' | 'SQUAD' | 'OPERATORS' | 'GAME'>('LOBBY');
  const [selectedMode, setSelectedMode] = useState<string | null>(null);
  const [selectedOperator, setSelectedOperator] = useState<Operator>(OPERATORS[0]);
  const [selectedWorld, setSelectedWorld] = useState<World>(WORLDS[0]);

  const handlePlay = () => {
    setView('MODES');
  };

  const handleSelectMode = () => {
    setView('MODES');
  };

  const handleStartWorlds = (mode: string) => {
    setSelectedMode(mode);
    setView('WORLDS');
  };

  const handleSelectWorld = (world: World) => {
    setSelectedWorld(world);
    setView('SQUAD');
  };

  const handleStartGame = () => {
    setView('GAME');
  };

  const handleSelectPlayer = (op: Operator) => {
    setSelectedOperator(op);
    setView('OPERATORS');
  };

  const handleBackToLobby = () => {
    setView('LOBBY');
  };

  const handleBackToSquad = () => {
    setView('SQUAD');
  };

  if (view === 'LOBBY') {
    return (
      <CyberStrikeLobby 
        onPlay={handlePlay} 
        onSelectMode={handleSelectMode}
        userName="AJAY_0X92F"
        currency={99999}
      />
    );
  }

  if (view === 'MODES') {
    return (
      <CyberStrikeModeSelection 
        onBack={handleBackToLobby}
        onStart={handleStartWorlds}
      />
    );
  }

  if (view === 'WORLDS') {
    return (
      <CyberStrikeWorldSelection 
        onBack={() => setView('MODES')}
        onSelect={handleSelectWorld}
      />
    );
  }

  if (view === 'SQUAD') {
    return (
      <CyberStrikeSquadLobby 
        onBack={() => setView('MODES')}
        onReady={handleStartGame}
        onSelectPlayer={handleSelectPlayer}
      />
    );
  }

  if (view === 'OPERATORS') {
    return (
      <CyberStrikeOperatorDetails 
        operator={selectedOperator}
        onBack={handleBackToSquad}
        onSelect={(op) => {
          setSelectedOperator(op);
          setView('SQUAD');
        }}
      />
    );
  }

  return <CyberStrike difficulty={difficulty} operator={selectedOperator} world={selectedWorld} />;
}
