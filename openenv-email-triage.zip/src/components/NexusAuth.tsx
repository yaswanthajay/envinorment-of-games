import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShieldCheck, 
  Cpu, 
  Scan, 
  Fingerprint, 
  Phone, 
  Mail, 
  ChevronRight, 
  Lock, 
  Eye, 
  User, 
  Sparkles,
  Camera,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { sounds } from '../lib/sounds';

interface NexusAuthProps {
  onAuthenticated: (user: { name: string, method: string }) => void;
}

export default function NexusAuth({ onAuthenticated }: NexusAuthProps) {
  const [view, setView] = useState<'WELCOME' | 'SIGNUP' | 'LOGIN' | 'SCANNING' | 'SUCCESS' | 'GOOGLE_ACCOUNTS'>('WELCOME');
  const [method, setMethod] = useState<'GOOGLE' | 'PHONE' | 'FACE' | null>(null);
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);

  const mockAccounts = [
    { name: 'Ajay Bhavanasi', email: 'bhavanasiyaswanthajay@gmail.com', avatar: 'AB' },
    { name: 'Nexus Guest', email: 'guest@nexus.ai', avatar: 'NG' }
  ];

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setView('SCANNING');
      startScanning();
    } catch (err) {
      setError("Camera access denied. Please enable it for biometric verification.");
      setTimeout(() => setError(null), 3000);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const startScanning = () => {
    setScanProgress(0);
    const interval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            stopCamera();
            setView('SUCCESS');
            setTimeout(() => {
              onAuthenticated({ name: selectedAccount || "Nexus_User_01", method: method || 'BIOMETRIC' });
            }, 1500);
          }, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 50);
  };

  const handleMockAuth = (authMethod: 'GOOGLE' | 'PHONE') => {
    sounds.playAction();
    setMethod(authMethod);
    if (authMethod === 'GOOGLE') {
      setView('GOOGLE_ACCOUNTS');
    } else {
      setView('LOGIN');
    }
  };

  const selectAccount = (accountName: string) => {
    setSelectedAccount(accountName);
    setView('SCANNING');
    startScanning();
  };

  return (
    <div className="fixed inset-0 z-[200] bg-[#050505] flex items-center justify-center p-6 overflow-hidden">
      {/* Background Atmosphere */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-500/10 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-cyan-500/10 blur-[120px] rounded-full animate-pulse" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay" />
      </div>

      <AnimatePresence mode="wait">
        {view === 'WELCOME' && (
          <motion.div 
            key="welcome"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="w-full max-w-4xl grid lg:grid-cols-2 gap-12 items-center relative z-10"
          >
            {/* Left: Robot Guardian */}
            <div className="relative flex justify-center items-center">
              <motion.div 
                animate={{ y: [0, -20, 0] }}
                transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                className="relative"
              >
                {/* Robot Head */}
                <div className="w-64 h-64 bg-slate-900 rounded-[3rem] border-2 border-indigo-500/30 relative shadow-[0_0_50px_rgba(99,102,241,0.2)] flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-b from-indigo-500/10 to-transparent" />
                  
                  {/* Eyes */}
                  <div className="flex gap-8 relative z-10">
                    <motion.div 
                      animate={{ scaleY: [1, 0.1, 1] }}
                      transition={{ repeat: Infinity, duration: 3, times: [0, 0.95, 1] }}
                      className="w-12 h-4 bg-cyan-400 rounded-full shadow-[0_0_20px_rgba(34,211,238,0.8)]" 
                    />
                    <motion.div 
                      animate={{ scaleY: [1, 0.1, 1] }}
                      transition={{ repeat: Infinity, duration: 3, times: [0, 0.95, 1] }}
                      className="w-12 h-4 bg-cyan-400 rounded-full shadow-[0_0_20px_rgba(34,211,238,0.8)]" 
                    />
                  </div>

                  {/* Scanning Line */}
                  <motion.div 
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                    className="absolute left-0 right-0 h-[2px] bg-cyan-400/50 shadow-[0_0_10px_rgba(34,211,238,0.5)] z-20"
                  />
                </div>

                {/* Floating Particles */}
                {Array.from({ length: 8 }).map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ 
                      x: [0, Math.random() * 100 - 50],
                      y: [0, Math.random() * 100 - 50],
                      opacity: [0, 1, 0]
                    }}
                    transition={{ repeat: Infinity, duration: 2 + Math.random() * 2 }}
                    className="absolute w-1 h-1 bg-cyan-400 rounded-full"
                    style={{ 
                      top: '50%', 
                      left: '50%',
                    }}
                  />
                ))}
              </motion.div>

              <div className="absolute -bottom-12 text-center">
                <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase leading-none">Nexus Guardian</h1>
                <p className="text-[10px] font-bold text-indigo-400/60 uppercase tracking-[0.4em] mt-2">Security_Protocol_v4.2</p>
              </div>
            </div>

            {/* Right: Auth Options */}
            <div className="space-y-8">
              <div className="space-y-2">
                <h2 className="text-5xl font-black text-white tracking-tighter uppercase leading-none italic">Access Portal</h2>
                <p className="text-white/40 font-serif italic text-lg">Verify your identity to enter the gaming collective.</p>
              </div>

              <div className="grid gap-4">
                <button 
                  onClick={() => handleMockAuth('GOOGLE')}
                  className="group flex items-center justify-between p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-indigo-500/50 transition-all text-left"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <span className="block text-sm font-black text-white uppercase tracking-widest">Google Nexus</span>
                      <span className="text-[10px] text-white/40 uppercase font-bold tracking-widest">Instant Sync Access</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-indigo-400 transition-colors" />
                </button>

                <button 
                  onClick={() => handleMockAuth('PHONE')}
                  className="group flex items-center justify-between p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-cyan-500/50 transition-all text-left"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Phone className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <span className="block text-sm font-black text-white uppercase tracking-widest">Mobile Link</span>
                      <span className="text-[10px] text-white/40 uppercase font-bold tracking-widest">Secure OTP Verification</span>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-cyan-400 transition-colors" />
                </button>

                <button 
                  onClick={() => {
                    setMethod('FACE');
                    startCamera();
                  }}
                  className="group flex items-center justify-between p-6 bg-indigo-500/20 border border-indigo-500/30 rounded-2xl hover:bg-indigo-500/30 hover:border-indigo-400 transition-all text-left shadow-[0_0_30px_rgba(99,102,241,0.1)]"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-indigo-500/30 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Scan className="w-6 h-6 text-indigo-400" />
                    </div>
                    <div>
                      <span className="block text-sm font-black text-indigo-400 uppercase tracking-widest">Biometric Scan</span>
                      <span className="text-[10px] text-indigo-400/60 uppercase font-bold tracking-widest">Neural Face Recognition</span>
                    </div>
                  </div>
                  <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
                </button>
              </div>

              <div className="flex items-center gap-4 pt-4">
                <div className="h-[1px] flex-1 bg-white/10" />
                <span className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Legacy Access</span>
                <div className="h-[1px] flex-1 bg-white/10" />
              </div>

              <div className="flex justify-center gap-8">
                <button 
                  onClick={() => setView('LOGIN')}
                  className="text-[10px] font-black text-white/40 uppercase tracking-widest hover:text-white transition-colors"
                >
                  Existing Account
                </button>
                <button 
                  onClick={() => setView('SIGNUP')}
                  className="text-[10px] font-black text-indigo-400 uppercase tracking-widest hover:text-indigo-300 transition-colors"
                >
                  Create Identity
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {view === 'GOOGLE_ACCOUNTS' && (
          <motion.div 
            key="google-accounts"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="w-full max-w-md bg-white/5 backdrop-blur-2xl p-10 rounded-[3rem] border border-white/10 shadow-2xl relative z-10"
          >
            <button 
              onClick={() => setView('WELCOME')}
              className="absolute top-8 left-8 text-white/20 hover:text-white transition-colors"
            >
              <ChevronRight className="w-6 h-6 rotate-180" />
            </button>

            <div className="text-center mb-10">
              <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/20">
                <Mail className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">Choose Account</h3>
              <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mt-1">to continue to Nexus Hub</p>
            </div>

            <div className="space-y-4">
              {mockAccounts.map((account, i) => (
                <button
                  key={i}
                  onClick={() => selectAccount(account.name)}
                  className="w-full flex items-center gap-4 p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:border-indigo-500/50 transition-all text-left group"
                >
                  <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold border border-indigo-500/30 group-hover:bg-indigo-500/30 transition-colors">
                    {account.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="block text-sm font-bold text-white truncate">{account.name}</span>
                    <span className="block text-xs text-white/40 truncate">{account.email}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-indigo-400 transition-colors" />
                </button>
              ))}

              <button
                onClick={() => setView('SIGNUP')}
                className="w-full flex items-center gap-4 p-4 bg-transparent border border-dashed border-white/10 rounded-2xl hover:bg-white/5 hover:border-white/20 transition-all text-left group"
              >
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-white/40 border border-white/10">
                  <User className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold text-white/60 group-hover:text-white transition-colors">Use another account</span>
              </button>
            </div>

            <p className="mt-8 text-[10px] text-white/20 text-center leading-relaxed">
              To continue, Google will share your name, email address, language preference, and profile picture with Nexus Hub.
            </p>
          </motion.div>
        )}

        {view === 'SCANNING' && (
          <motion.div 
            key="scanning"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center space-y-12 relative z-10"
          >
            <div className="relative">
              {/* Camera Feed or Placeholder */}
              <div className="w-80 h-80 lg:w-[500px] lg:h-[500px] bg-slate-900 rounded-full border-4 border-indigo-500/30 relative overflow-hidden shadow-[0_0_100px_rgba(99,102,241,0.3)]">
                {method === 'FACE' ? (
                  <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    className="w-full h-full object-cover grayscale brightness-125 contrast-125"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-indigo-500/5">
                    <Cpu className="w-32 h-32 text-indigo-500/20 animate-pulse" />
                  </div>
                )}
                
                {/* Scanning HUD Overlay */}
                <div className="absolute inset-0 pointer-events-none">
                  {/* Grid Lines */}
                  <div className="absolute inset-0 bg-[linear-gradient(rgba(99,102,241,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(99,102,241,0.1)_1px,transparent_1px)] bg-[size:40px_40px]" />
                  
                  {/* Scanning Bar */}
                  <motion.div 
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
                    className="absolute left-0 right-0 h-[4px] bg-indigo-400 shadow-[0_0_30px_rgba(99,102,241,0.8)] z-20"
                  />

                  {/* Corner Brackets */}
                  <div className="absolute top-10 left-10 w-12 h-12 border-t-2 border-l-2 border-indigo-400" />
                  <div className="absolute top-10 right-10 w-12 h-12 border-t-2 border-r-2 border-indigo-400" />
                  <div className="absolute bottom-10 left-10 w-12 h-12 border-b-2 border-l-2 border-indigo-400" />
                  <div className="absolute bottom-10 right-10 w-12 h-12 border-b-2 border-r-2 border-indigo-400" />

                  {/* Target Circle */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <motion.div 
                      animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.6, 0.3] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                      className="w-48 h-48 border border-indigo-400/50 rounded-full"
                    />
                  </div>
                </div>
              </div>

              {/* Progress Ring */}
              <svg className="absolute -inset-8 w-[calc(100%+64px)] h-[calc(100%+64px)] -rotate-90 pointer-events-none">
                <circle
                  cx="50%"
                  cy="50%"
                  r="48%"
                  fill="none"
                  stroke="rgba(99,102,241,0.1)"
                  strokeWidth="2"
                />
                <motion.circle
                  cx="50%"
                  cy="50%"
                  r="48%"
                  fill="none"
                  stroke="#6366f1"
                  strokeWidth="4"
                  strokeDasharray="100 100"
                  strokeDashoffset={100 - scanProgress}
                  strokeLinecap="round"
                  className="transition-all duration-100"
                />
              </svg>
            </div>

            <div className="text-center space-y-4">
              <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">
                {method === 'FACE' ? 'Analyzing Biometrics' : 'Synchronizing Identity'}
              </h3>
              <div className="flex items-center justify-center gap-4">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.4em]">Progress: {scanProgress}%</span>
                <div className="w-32 h-1 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    animate={{ width: `${scanProgress}%` }}
                    className="h-full bg-indigo-500"
                  />
                </div>
              </div>
              <p className="text-white/20 text-[10px] uppercase font-bold tracking-widest animate-pulse">Do not move during neural mapping...</p>
            </div>
          </motion.div>
        )}

        {view === 'SUCCESS' && (
          <motion.div 
            key="success"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center space-y-8 relative z-10"
          >
            <div className="w-32 h-32 bg-emerald-500/20 rounded-full flex items-center justify-center border-2 border-emerald-500/50 shadow-[0_0_50px_rgba(16,185,129,0.3)]">
              <CheckCircle2 className="w-16 h-16 text-emerald-400" />
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-5xl font-black text-white uppercase italic tracking-tighter">Identity Verified</h3>
              <p className="text-emerald-400/60 font-mono text-xs uppercase tracking-[0.4em]">Welcome to the Nexus, User_01</p>
            </div>
          </motion.div>
        )}

        {(view === 'LOGIN' || view === 'SIGNUP') && (
          <motion.div 
            key="form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="w-full max-w-md bg-white/5 backdrop-blur-2xl p-10 rounded-[3rem] border border-white/10 shadow-2xl relative z-10"
          >
            <button 
              onClick={() => setView('WELCOME')}
              className="absolute top-8 left-8 text-white/20 hover:text-white transition-colors"
            >
              <ChevronRight className="w-6 h-6 rotate-180" />
            </button>

            <div className="text-center mb-10">
              <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-indigo-500/20">
                {view === 'LOGIN' ? <Lock className="w-8 h-8 text-indigo-400" /> : <User className="w-8 h-8 text-indigo-400" />}
              </div>
              <h3 className="text-3xl font-black text-white uppercase italic tracking-tighter">
                {view === 'LOGIN' ? 'Secure Login' : 'New Identity'}
              </h3>
              <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mt-1">Nexus_Protocol_v4.2</p>
            </div>

            <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setView('SCANNING'); startScanning(); }}>
              {view === 'SIGNUP' && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-white/40 uppercase tracking-widest ml-4">Display Name</label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20" />
                    <input 
                      type="text" 
                      placeholder="NEXUS_WARRIOR"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-white/10 focus:outline-none focus:border-indigo-500/50 transition-all font-mono uppercase"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <label className="text-[10px] font-black text-white/40 uppercase tracking-widest ml-4">
                  {method === 'PHONE' ? 'Phone Number' : 'Nexus ID / Email'}
                </label>
                <div className="relative">
                  {method === 'PHONE' ? <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20" /> : <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20" />}
                  <input 
                    type={method === 'PHONE' ? 'tel' : 'email'} 
                    placeholder={method === 'PHONE' ? '+1 (555) 000-0000' : 'USER@NEXUS.AI'}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white placeholder:text-white/10 focus:outline-none focus:border-indigo-500/50 transition-all font-mono uppercase"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-white/40 uppercase tracking-widest ml-4">Access Key</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20" />
                  <input 
                    type="password" 
                    placeholder="••••••••"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-12 text-white placeholder:text-white/10 focus:outline-none focus:border-indigo-500/50 transition-all font-mono"
                  />
                  <button type="button" className="absolute right-4 top-1/2 -translate-y-1/2 text-white/20 hover:text-white transition-colors">
                    <Eye className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <button 
                type="submit"
                className="w-full py-5 bg-indigo-500 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all active:scale-95 shadow-[0_0_30px_rgba(99,102,241,0.3)] mt-4"
              >
                {view === 'LOGIN' ? 'Authorize Access' : 'Initialize Identity'}
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Error Toast */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-red-500/90 backdrop-blur-xl px-8 py-4 rounded-2xl border border-red-400/50 flex items-center gap-4 shadow-2xl z-[300]"
          >
            <AlertCircle className="w-6 h-6 text-white" />
            <span className="text-sm font-black text-white uppercase tracking-widest">{error}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
