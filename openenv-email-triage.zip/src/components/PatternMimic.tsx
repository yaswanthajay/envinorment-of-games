import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Zap, 
  Cpu, 
  RefreshCw, 
  Activity, 
  Brain, 
  Shield, 
  Target, 
  Diamond, 
  Route, 
  Box,
  Lock,
  Unlock,
  AlertTriangle
} from 'lucide-react';

const BUTTON_CONFIG = [
  { id: 0, color: 'from-cyan-400 to-blue-600', shadow: 'shadow-cyan-500/50', icon: <Zap className="w-8 h-8" />, freq: 261.63 }, // C4
  { id: 1, color: 'from-fuchsia-400 to-purple-600', shadow: 'shadow-fuchsia-500/50', icon: <Cpu className="w-8 h-8" />, freq: 293.66 }, // D4
  { id: 2, color: 'from-emerald-400 to-teal-600', shadow: 'shadow-emerald-500/50', icon: <Brain className="w-8 h-8" />, freq: 329.63 }, // E4
  { id: 3, color: 'from-amber-400 to-orange-600', shadow: 'shadow-amber-500/50', icon: <Shield className="w-8 h-8" />, freq: 349.23 }, // F4
  { id: 4, color: 'from-rose-400 to-red-600', shadow: 'shadow-rose-500/50', icon: <Target className="w-8 h-8" />, freq: 392.00 }, // G4
  { id: 5, color: 'from-indigo-400 to-blue-800', shadow: 'shadow-indigo-500/50', icon: <Diamond className="w-8 h-8" />, freq: 440.00 }, // A4
  { id: 6, color: 'from-lime-400 to-green-600', shadow: 'shadow-lime-500/50', icon: <Route className="w-8 h-8" />, freq: 493.88 }, // B4
  { id: 7, color: 'from-sky-400 to-cyan-600', shadow: 'shadow-sky-500/50', icon: <Box className="w-8 h-8" />, freq: 523.25 }, // C5
  { id: 8, color: 'from-pink-400 to-rose-600', shadow: 'shadow-pink-500/50', icon: <Activity className="w-8 h-8" />, freq: 587.33 }, // D5
];

export default function PatternMimic({ difficulty = "MEDIUM" }: { difficulty?: string }) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userSequence, setUserSequence] = useState<number[]>([]);
  const [isAiTurn, setIsAiTurn] = useState(true);
  const [activeButton, setActiveButton] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [status, setStatus] = useState<"PLAYING" | "LOST">("PLAYING");
  const [highScore, setHighScore] = useState(0);
  
  const audioCtx = useRef<AudioContext | null>(null);

  const playTone = useCallback((freq: number, type: OscillatorType = 'sine', duration = 0.3) => {
    if (!audioCtx.current) {
      audioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    
    const ctx = audioCtx.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + duration);
  }, []);

  const playFailSound = useCallback(() => {
    if (!audioCtx.current) {
      audioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioCtx.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.5);
    
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  }, []);

  const speedMap: Record<string, number> = {
    'EASY': 1000,
    'MEDIUM': 700,
    'HARD': 500,
    'INSANE': 300
  };
  const speed = speedMap[difficulty.toUpperCase()] || 700;

  const playSequence = useCallback(async (seq: number[]) => {
    setIsAiTurn(true);
    await new Promise(r => setTimeout(r, 800)); // Initial delay
    for (const id of seq) {
      setActiveButton(id);
      playTone(BUTTON_CONFIG[id].freq);
      await new Promise(r => setTimeout(r, speed));
      setActiveButton(null);
      await new Promise(r => setTimeout(r, 150));
    }
    setIsAiTurn(false);
  }, [speed, playTone]);

  const nextRound = useCallback(async (currentSeq: number[]) => {
    const next = Math.floor(Math.random() * 9);
    const newSeq = [...currentSeq, next];
    setSequence(newSeq);
    setUserSequence([]);
    await playSequence(newSeq);
  }, [playSequence]);

  useEffect(() => {
    nextRound([]);
  }, [nextRound]);

  const handleUserClick = (id: number) => {
    if (isAiTurn || status === "LOST") return;

    setActiveButton(id);
    playTone(BUTTON_CONFIG[id].freq);
    setTimeout(() => setActiveButton(null), 200);

    const nextUserSeq = [...userSequence, id];
    setUserSequence(nextUserSeq);

    if (id !== sequence[userSequence.length]) {
      setStatus("LOST");
      playFailSound();
      if (score > highScore) setHighScore(score);
      return;
    }

    if (nextUserSeq.length === sequence.length) {
      setScore(s => s + 1);
      setTimeout(() => nextRound(sequence), 800);
    }
  };

  const reset = () => {
    setSequence([]);
    setUserSequence([]);
    setScore(0);
    setStatus("PLAYING");
    nextRound([]);
  };

  return (
    <div className="max-w-xl mx-auto p-10 bg-black/80 backdrop-blur-2xl rounded-[3rem] border border-white/10 shadow-[0_0_100px_rgba(255,255,255,0.05)] relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-500 to-transparent opacity-50" />
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-fuchsia-500 to-transparent opacity-50" />
      
      <div className="flex justify-between items-end mb-10 relative z-10">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/20 rounded-lg border border-cyan-500/30">
              <Activity className="w-5 h-5 text-cyan-400" />
            </div>
            <h2 className="text-3xl font-black text-white tracking-tighter uppercase italic leading-none">Pattern Mimic</h2>
          </div>
          <p className="text-[10px] text-white/30 uppercase tracking-[0.4em] font-bold pl-1">Neural Synchronization Protocol</p>
        </div>
        
        <div className="flex gap-8">
          <div className="text-right">
            <p className="text-[9px] text-white/40 uppercase font-bold tracking-widest mb-1">High Score</p>
            <p className="text-xl font-black text-white/60 leading-none">{highScore}</p>
          </div>
          <div className="text-right">
            <p className="text-[9px] text-cyan-400 uppercase font-bold tracking-widest mb-1">Current Depth</p>
            <p className="text-4xl font-black text-cyan-400 leading-none drop-shadow-[0_0_10px_rgba(34,211,238,0.5)]">{score}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-10 relative z-10">
        {BUTTON_CONFIG.map((btn) => (
          <motion.button
            key={btn.id}
            whileHover={{ scale: isAiTurn ? 1 : 1.05 }}
            whileTap={{ scale: isAiTurn ? 1 : 0.9 }}
            onClick={() => handleUserClick(btn.id)}
            disabled={isAiTurn}
            className={`aspect-square rounded-3xl border-2 transition-all duration-300 flex items-center justify-center relative group
              ${activeButton === btn.id 
                ? `bg-gradient-to-br ${btn.color} border-white/40 shadow-[0_0_30px_rgba(255,255,255,0.3)] ${btn.shadow}` 
                : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10'}`}
          >
            <div className={`transition-all duration-300 ${activeButton === btn.id ? 'text-white scale-110' : 'text-white/20 group-hover:text-white/40'}`}>
              {btn.icon}
            </div>
            
            {/* Active Glow Effect */}
            <AnimatePresence>
              {activeButton === btn.id && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1.2 }}
                  exit={{ opacity: 0, scale: 1.5 }}
                  className="absolute inset-0 rounded-3xl bg-white/20 blur-xl pointer-events-none"
                />
              )}
            </AnimatePresence>
          </motion.button>
        ))}
      </div>

      <div className="bg-white/5 p-6 rounded-2xl border border-white/10 flex items-center justify-between relative z-10">
        <div className="flex items-center gap-4">
          <div className={`p-2 rounded-full ${isAiTurn ? 'bg-cyan-500/20' : 'bg-emerald-500/20'}`}>
            {isAiTurn ? <Lock className="w-4 h-4 text-cyan-400" /> : <Unlock className="w-4 h-4 text-emerald-400" />}
          </div>
          <div className="space-y-0.5">
            <p className={`text-[10px] uppercase font-black tracking-widest ${isAiTurn ? 'text-cyan-400' : 'text-emerald-400'}`}>
              {isAiTurn ? "AI Transmitting" : "User Input Active"}
            </p>
            <p className="text-[9px] text-white/30 uppercase tracking-wider font-bold">
              {isAiTurn ? "Memorize the sequence" : "Repeat the pattern exactly"}
            </p>
          </div>
        </div>
        <button 
          onClick={reset} 
          className="p-3 hover:bg-white/10 rounded-xl transition-all group border border-transparent hover:border-white/10"
          title="Reset Sequence"
        >
          <RefreshCw className="w-5 h-5 text-white/40 group-hover:text-white group-hover:rotate-180 transition-all duration-500" />
        </button>
      </div>

      {/* Game Over Overlay */}
      <AnimatePresence>
        {status === "LOST" && (
          <motion.div 
            initial={{ opacity: 0, backdropFilter: "blur(0px)" }}
            animate={{ opacity: 1, backdropFilter: "blur(20px)" }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/80 z-50 p-12"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="text-center space-y-8"
            >
              <div className="inline-flex p-4 bg-red-500/20 rounded-full border border-red-500/30 mb-4">
                <AlertTriangle className="w-12 h-12 text-red-500" />
              </div>
              <div>
                <h3 className="text-7xl font-black text-white mb-2 uppercase italic tracking-tighter leading-none">
                  SYNC FAILED
                </h3>
                <p className="text-red-400/60 uppercase tracking-[0.5em] text-[10px] font-black">
                  Neural Pattern Mismatch Detected
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-4 max-w-xs mx-auto">
                <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                  <p className="text-[9px] text-white/40 uppercase font-bold tracking-widest mb-1">Final Depth</p>
                  <p className="text-3xl font-black text-white">{score}</p>
                </div>
                <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
                  <p className="text-[9px] text-white/40 uppercase font-bold tracking-widest mb-1">Best Depth</p>
                  <p className="text-3xl font-black text-white">{highScore}</p>
                </div>
              </div>

              <button 
                onClick={reset} 
                className="w-full py-5 bg-white text-black font-black rounded-2xl hover:bg-cyan-400 transition-all uppercase tracking-[0.2em] text-sm shadow-[0_20px_40px_rgba(0,0,0,0.3)]"
              >
                Re-Initialize Link
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

