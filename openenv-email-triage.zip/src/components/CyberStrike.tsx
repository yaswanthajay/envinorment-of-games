import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Crosshair, 
  Shield, 
  Zap, 
  Target, 
  Skull, 
  Trophy,
  RefreshCw,
  Pause,
  Play,
  Plus,
  Bomb,
  RotateCcw,
  Eye,
  Coins,
  ShoppingCart,
  Gamepad2,
  Sword,
  Flame,
  Activity
} from 'lucide-react';
import { Operator, World } from './CyberStrikeUI';

type WeaponType = 'AK-47' | 'M4A1' | 'SNIPER' | 'SHOTGUN';
type EnemyType = 'GRUNT' | 'STRIKER' | 'TANK' | 'SNIPER';

interface Entity {
  id: string;
  type?: EnemyType;
  x: number;
  y: number;
  z: number; // Depth for pseudo-3D
  hp: number;
  maxHp: number;
  team: 'BLUE' | 'RED';
  weapon: WeaponType;
  isDead: boolean;
  lastShot: number;
  state: 'IDLE' | 'SHOOTING' | 'COVER';
  speed?: number;
  isBoss?: boolean;
}

interface Bullet {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  team: 'BLUE' | 'RED';
  damage: number;
}

const WEAPONS: Record<WeaponType, { damage: number, speed: number, cooldown: number, ammo: number, maxAmmo: number }> = {
  'AK-47': { damage: 25, speed: 15, cooldown: 120, ammo: 30, maxAmmo: 60 },
  'M4A1': { damage: 20, speed: 18, cooldown: 100, ammo: 30, maxAmmo: 90 },
  'SNIPER': { damage: 100, speed: 25, cooldown: 1500, ammo: 5, maxAmmo: 15 },
  'SHOTGUN': { damage: 50, speed: 12, cooldown: 800, ammo: 8, maxAmmo: 24 }
};

export default function CyberStrike({ difficulty, operator, world }: { difficulty: string, operator?: Operator, world?: World }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'START' | 'PLAYING' | 'WON' | 'LOST'>('START');
  const [level, setLevel] = useState(1);
  const [kills, setKills] = useState(0);
  const [levelKills, setLevelKills] = useState(0);
  const [money, setMoney] = useState(1000);
  const [inventory, setInventory] = useState<WeaponType[]>(['AK-47']);
  const [activeWeapon, setActiveWeapon] = useState<WeaponType>('AK-47');
  const [ammo, setAmmo] = useState(30);
  const [maxAmmo, setMaxAmmo] = useState(60);
  const [healthKits, setHealthKits] = useState(3);
  const [grenades, setGrenades] = useState(3);
  const [playerHp, setPlayerHp] = useState(100);
  const [maxHp, setMaxHp] = useState(100);
  const [isAiming, setIsAiming] = useState(false);
  const [isReloading, setIsReloading] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [showBuyMenu, setShowBuyMenu] = useState(false);
  const [rewardText, setRewardText] = useState<{x: number, y: number, text: string, id: number}[]>([]);
  
  const entitiesRef = useRef<Entity[]>([]);
  const bulletsRef = useRef<Bullet[]>([]);
  const grenadesRef = useRef<{x: number, y: number, z: number, vx: number, vy: number, vz: number, timer: number}[]>([]);
  const keysRef = useRef<Record<string, boolean>>({});
  const mousePosRef = useRef({ x: 0, y: 0 });
  const requestRef = useRef<number | null>(null);

  // Refs for game loop to avoid stale closures
  const ammoRef = useRef(30);
  const playerHpRef = useRef(100);
  const moneyRef = useRef(1000);
  const killsRef = useRef(0);
  const levelKillsRef = useRef(0);
  const levelRef = useRef(1);

  // Sync refs to state for HUD
  useEffect(() => {
    const interval = setInterval(() => {
      setAmmo(ammoRef.current);
      setPlayerHp(playerHpRef.current);
      setMoney(moneyRef.current);
      setKills(killsRef.current);
      setLevelKills(levelKillsRef.current);
      setLevel(levelRef.current);
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const initGame = useCallback(() => {
    // Use operator stats if available
    const baseHp = operator ? (operator.stats.armor / 2) + 100 : 100;
    const currentMaxHp = baseHp + (levelRef.current * 10);
    setMaxHp(currentMaxHp);
    playerHpRef.current = currentMaxHp;

    const player: Entity = {
      id: 'player',
      x: 400,
      y: 400,
      z: 100,
      hp: currentMaxHp,
      maxHp: currentMaxHp,
      team: 'BLUE',
      weapon: activeWeapon,
      isDead: false,
      lastShot: 0,
      state: 'IDLE'
    };

    const enemiesCount = 5 + levelRef.current * 3;
    const enemies: Entity[] = [...Array(enemiesCount)].map((_, i) => {
      const types: EnemyType[] = ['GRUNT', 'STRIKER', 'TANK', 'SNIPER'];
      const isBoss = levelRef.current % 5 === 0 && i === 0;
      const type = isBoss ? 'TANK' : (levelRef.current === 1 ? 'GRUNT' : types[Math.floor(Math.random() * Math.min(types.length, levelRef.current))]);
      
      let hp = 20 + levelRef.current * 10; // Reduced HP for early levels
      let weapon: WeaponType = 'AK-47';
      let speed = 1;

      if (isBoss) {
        hp *= 10;
        speed = 0.3;
        weapon = 'SNIPER';
      } else if (type === 'TANK') {
        hp *= 3;
        speed = 0.5;
        weapon = 'SHOTGUN';
      } else if (type === 'STRIKER') {
        hp *= 0.8;
        speed = 2;
        weapon = 'M4A1';
      } else if (type === 'SNIPER') {
        hp *= 0.6;
        speed = 0.7;
        weapon = 'SNIPER';
      }

      return {
        id: `enemy-${i}`,
        type,
        x: 100 + Math.random() * 600,
        y: 300 + Math.random() * 100,
        z: 400 + Math.random() * 600,
        hp,
        maxHp: hp,
        team: 'RED',
        weapon,
        isDead: false,
        lastShot: 0,
        state: 'IDLE',
        speed,
        isBoss
      };
    });

    entitiesRef.current = [player, ...enemies];
    bulletsRef.current = [];
    grenadesRef.current = [];
    levelKillsRef.current = 0;
    ammoRef.current = WEAPONS[activeWeapon].ammo;
    setGameState('PLAYING');
  }, [activeWeapon, operator]);

  const switchWeapon = useCallback((weapon: WeaponType) => {
    if (activeWeapon === weapon || isReloading) return;
    setActiveWeapon(weapon);
    ammoRef.current = WEAPONS[weapon].ammo;
    setMaxAmmo(WEAPONS[weapon].maxAmmo);
  }, [activeWeapon, isReloading]);

  const reload = useCallback(() => {
    if (isReloading || ammoRef.current === WEAPONS[activeWeapon].ammo) return;
    setIsReloading(true);
    setTimeout(() => {
      ammoRef.current = WEAPONS[activeWeapon].ammo;
      setIsReloading(false);
    }, 1500);
  }, [isReloading, activeWeapon]);

  const throwGrenade = useCallback(() => {
    if (grenades <= 0) return;
    const player = entitiesRef.current.find(e => e.id === 'player');
    if (!player) return;

    const targetX = mousePosRef.current.x;
    const targetY = mousePosRef.current.y;
    const angle = Math.atan2(targetY - player.y, targetX - player.x);
    
    grenadesRef.current.push({
      x: player.x,
      y: player.y - 40,
      z: player.z,
      vx: Math.cos(angle) * 8,
      vy: Math.sin(angle) * 8,
      vz: 15,
      timer: 2000
    });
    setGrenades(g => g - 1);
  }, [grenades]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.code] = true;
      if (e.code === 'KeyR') reload();
      if (e.code === 'KeyG') throwGrenade();
      if (e.code === 'KeyH') {
        if (healthKits > 0) {
          setPlayerHp(h => Math.min(maxHp, h + 50));
          setHealthKits(k => k - 1);
        }
      }
      if (e.code === 'KeyB') setShowBuyMenu(prev => !prev);
      if (e.code === 'Escape') setShowBuyMenu(false);
      if (e.code === 'KeyP') setIsPaused(prev => !prev);
      
      // Weapon Switching
      if (e.code === 'Digit1' && inventory.length >= 1) switchWeapon(inventory[0]);
      if (e.code === 'Digit2' && inventory.length >= 2) switchWeapon(inventory[1]);
      if (e.code === 'Digit3' && inventory.length >= 3) switchWeapon(inventory[2]);
      if (e.code === 'Digit4' && inventory.length >= 4) switchWeapon(inventory[3]);
    };
    const handleKeyUp = (e: KeyboardEvent) => keysRef.current[e.code] = false;
    const handleMouseMove = (e: MouseEvent) => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        mousePosRef.current = {
          x: e.clientX - rect.left,
          y: e.clientY - rect.top
        };
      }
    };
    const handleMouseDown = (e: MouseEvent) => {
      if (e.button === 0) keysRef.current['MOUSE_LEFT'] = true;
      if (e.button === 2) {
        keysRef.current['MOUSE_RIGHT'] = true;
        setIsAiming(true);
      }
    };
    const handleMouseUp = (e: MouseEvent) => {
      if (e.button === 0) keysRef.current['MOUSE_LEFT'] = false;
      if (e.button === 2) {
        keysRef.current['MOUSE_RIGHT'] = false;
        setIsAiming(false);
      }
    };
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('contextmenu', handleContextMenu);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [inventory, switchWeapon, reload, throwGrenade, healthKits, maxHp]);

  const update = useCallback((time: number) => {
    if (gameState !== 'PLAYING' || isPaused) {
      requestRef.current = requestAnimationFrame(update);
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    const entities = entitiesRef.current;
    const player = entities.find(e => e.id === 'player');
    if (!player || player.isDead) {
      setGameState('LOST');
      return;
    }

    // Player Movement (Horizontal only for this perspective)
    const baseSpeed = operator ? (operator.stats.speed / 50) + 3 : 4;
    const speed = baseSpeed + (keysRef.current['ShiftLeft'] ? 2 : 0);
    if (keysRef.current['KeyA'] || keysRef.current['ArrowLeft']) player.x -= speed;
    if (keysRef.current['KeyD'] || keysRef.current['ArrowRight']) player.x += speed;
    
    // Slight vertical movement for depth feel
    if (keysRef.current['KeyW'] || keysRef.current['ArrowUp']) player.y -= speed * 0.5;
    if (keysRef.current['KeyS'] || keysRef.current['ArrowDown']) player.y += speed * 0.5;
    
    player.x = Math.max(50, Math.min(canvas.width - 50, player.x));
    player.y = Math.max(canvas.height - 150, Math.min(canvas.height - 50, player.y));

    // Shooting
    if ((keysRef.current['MOUSE_LEFT'] || keysRef.current['Space']) && !isReloading) {
      const weapon = WEAPONS[player.weapon];
      const damageBoost = operator ? (operator.stats.damage / 200) * 10 : 0;
      if (time - player.lastShot > weapon.cooldown && ammoRef.current > 0) {
        const targetX = mousePosRef.current.x;
        const targetY = mousePosRef.current.y;
        const angle = Math.atan2(targetY - (player.y - 40), targetX - player.x);
        
        bulletsRef.current.push({
          x: player.x,
          y: player.y - 40,
          z: player.z,
          vx: Math.cos(angle) * weapon.speed,
          vy: Math.sin(angle) * weapon.speed,
          vz: 40, // Increased speed in Z
          team: 'BLUE',
          damage: weapon.damage + damageBoost
        });
        player.lastShot = time;
        ammoRef.current -= 1;
        if (ammoRef.current <= 0) reload();
      }
    }

    // Reload Key
    if (keysRef.current['KeyR']) reload();

    // Grenade Key
    if (keysRef.current['KeyG']) throwGrenade();

      // AI Logic
      entities.forEach(entity => {
        if (entity.id === 'player' || entity.isDead) return;

        const weapon = WEAPONS[entity.weapon];
        
        // Enemies are now static as requested, they only look at the player
        const angle = Math.atan2(player.y - entity.y, player.x - entity.x);

        // Shooting
      let shootCooldown = 2000 + Math.random() * 2000;
      if (entity.isBoss) shootCooldown = 1500;
      else if (entity.type === 'STRIKER') shootCooldown = 1000 + Math.random() * 1000;
      else if (entity.type === 'SNIPER') shootCooldown = 4000 + Math.random() * 2000;
      else if (entity.type === 'TANK') shootCooldown = 3000 + Math.random() * 1000;

      if (time - entity.lastShot > shootCooldown) {
        const angle = Math.atan2(player.y - entity.y, player.x - entity.x);
        
        if (entity.isBoss) {
          // Boss fires spread shot
          for (let i = -1; i <= 1; i++) {
            bulletsRef.current.push({
              x: entity.x,
              y: entity.y,
              z: entity.z,
              vx: Math.cos(angle + i * 0.2) * weapon.speed,
              vy: Math.sin(angle + i * 0.2) * weapon.speed,
              vz: -10,
              team: 'RED',
              damage: weapon.damage * 1.5
            });
          }
        } else {
          bulletsRef.current.push({
            x: entity.x,
            y: entity.y,
            z: entity.z,
            vx: Math.cos(angle) * weapon.speed,
            vy: Math.sin(angle) * weapon.speed,
            vz: -10,
            team: 'RED',
            damage: weapon.damage * (entity.type === 'SNIPER' ? 2 : 1)
          });
        }
        entity.lastShot = time;
      }
    });

    // Update Grenades
    grenadesRef.current = grenadesRef.current.filter(g => {
      g.x += g.vx;
      g.y += g.vy;
      g.z += g.vz;
      g.vz -= 0.5; // Gravity
      g.timer -= 16;

      if (g.timer <= 0) {
        // Explosion
        entities.forEach(entity => {
          if (!entity.isDead) {
            const dist = Math.hypot(entity.x - g.x, entity.y - g.y);
            const depthDist = Math.abs(entity.z - g.z);
            if (dist < 50 && depthDist < 150) {
              entity.hp -= 80;
              if (entity.id === 'player') playerHpRef.current = Math.max(0, entity.hp);
              if (entity.hp <= 0) {
                entity.isDead = true;
                if (entity.team === 'RED') {
                  killsRef.current += 1;
                  moneyRef.current += 500;
                }
              }
            }
          }
        });
        return false;
      }
      return true;
    });

    // Update Bullets
    bulletsRef.current = bulletsRef.current.filter(bullet => {
      bullet.x += bullet.vx;
      bullet.y += bullet.vy;
      bullet.z += bullet.vz;

      // Collision check
      for (const entity of entities) {
        if (!entity.isDead && entity.team !== bullet.team) {
          const dist = Math.hypot(entity.x - bullet.x, (entity.y - 40) - bullet.y);
          const depthDist = Math.abs(entity.z - bullet.z);
          
          if (dist < 50 && depthDist < 150) {
            entity.hp -= bullet.damage;
            if (entity.id === 'player') playerHpRef.current = Math.max(0, entity.hp);
            if (entity.hp <= 0) {
              entity.isDead = true;
              if (entity.team === 'RED') {
                killsRef.current += 1;
                levelKillsRef.current += 1;
                moneyRef.current += 200;
                // Reward: Health and Ammo
                playerHpRef.current = Math.min(maxHp, playerHpRef.current + 10);
                ammoRef.current = Math.min(WEAPONS[activeWeapon].ammo, ammoRef.current + 5);
                
                // Add floating reward text
                const newReward = { x: entity.x, y: entity.y - 50, text: '+HP +AMMO +200$', id: Date.now() };
                setRewardText(prev => [...prev, newReward]);
                setTimeout(() => {
                  setRewardText(prev => prev.filter(r => r.id !== newReward.id));
                }, 1000);
              }
            }
            return false;
          }
        }
      }

      return bullet.z > -100 && bullet.z < 1000;
    });

    // Win/Loss Check
    const enemiesAlive = entities.filter(e => e.team === 'RED' && !e.isDead).length;
    if (enemiesAlive === 0 && gameState === 'PLAYING') {
      levelRef.current += 1;
      setGameState('WON');
    }

    // Draw
    const ctx = canvas.getContext('2d');
    if (ctx) {
      const theme = world?.theme || {
        wall: '#d2b48c',
        floor: '#8b4513',
        ceiling: '#f5f5dc',
        accent: '#5d4037'
      };

      // Room Interior
      ctx.fillStyle = theme.wall;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      // Ceiling
      ctx.fillStyle = theme.ceiling;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(canvas.width, 0);
      ctx.lineTo(canvas.width - 100, 100);
      ctx.lineTo(100, 100);
      ctx.fill();

      // Floor
      ctx.fillStyle = theme.floor;
      ctx.beginPath();
      ctx.moveTo(0, canvas.height);
      ctx.lineTo(canvas.width, canvas.height);
      ctx.lineTo(canvas.width - 100, canvas.height - 150);
      ctx.lineTo(100, canvas.height - 150);
      ctx.fill();

      // Wall details (Posters/Windows)
      ctx.fillStyle = theme.accent;
      ctx.fillRect(200, 120, 80, 100); // Poster 1
      ctx.fillStyle = '#795548';
      ctx.fillRect(210, 130, 60, 80);
      
      ctx.fillStyle = theme.accent;
      ctx.fillRect(500, 120, 100, 120); // Window frame
      ctx.fillStyle = world?.id === '1' ? '#1a1a1a' : '#81d4fa'; // Darker for hallway
      ctx.fillRect(510, 130, 80, 100);

      // Bookshelves and Furniture
      ctx.fillStyle = theme.accent;
      ctx.fillRect(50, 150, 120, 400); // Left bookshelf
      ctx.fillRect(canvas.width - 170, 150, 120, 400); // Right bookshelf
      
      // Books on shelves
      ctx.fillStyle = world?.id === '2' ? '#cfd8dc' : '#b71c1c';
      for(let i=0; i<5; i++) ctx.fillRect(60, 170 + i*40, 100, 30);
      ctx.fillStyle = world?.id === '2' ? '#90a4ae' : '#0d47a1';
      for(let i=0; i<5; i++) ctx.fillRect(canvas.width - 160, 170 + i*40, 100, 30);
      
      // Door in the background
      ctx.fillStyle = theme.accent;
      ctx.fillRect(canvas.width / 2 - 50, 200, 100, 200);
      ctx.strokeStyle = '#fff';
      ctx.strokeRect(canvas.width / 2 - 50, 200, 100, 200);

      // Debris on floor
      ctx.fillStyle = theme.accent;
      for(let i=0; i<20; i++) {
        ctx.beginPath();
        ctx.arc(150 + Math.random() * 500, 550 + Math.random() * 100, 5 + Math.random() * 10, 0, Math.PI * 2);
        ctx.fill();
      }
      
      // Shadow under enemies
      entities.forEach(entity => {
        if (entity.isDead) return;
        const scale = 1 - (entity.z / 1200);
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.ellipse(entity.x, entity.y, 30 * scale, 10 * scale, 0, 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Entities (Sorted by depth)
      const sortedEntities = [...entities].sort((a, b) => b.z - a.z);
      sortedEntities.forEach(entity => {
        if (entity.isDead) return;

        const scale = 1 - (entity.z / 1200);
        const drawX = entity.x;
        const drawY = entity.y;

        ctx.save();
        ctx.translate(drawX, drawY);
        ctx.scale(scale, scale);

        if (entity.id === 'player') {
          // Player Character (Human holding gun)
          const mouseX = mousePosRef.current.x;
          const angle = Math.atan2(mousePosRef.current.y - entity.y, mousePosRef.current.x - entity.x);
          
          // Body
          ctx.fillStyle = '#1a237e'; // Blue tactical suit
          ctx.fillRect(-20, -70, 40, 70);
          
          // Head
          ctx.fillStyle = '#ffccbc'; // Skin tone
          ctx.beginPath();
          ctx.arc(0, -80, 15, 0, Math.PI * 2);
          ctx.fill();
          
          // Gun (Pointing towards mouse)
          ctx.save();
          ctx.translate(0, -45);
          ctx.rotate(angle);
          ctx.fillStyle = '#212121';
          ctx.fillRect(0, -5, 45, 10); // Barrel
          ctx.fillRect(0, 0, 15, 20); // Grip
          ctx.restore();
          
          // Helmet
          ctx.fillStyle = '#0d47a1';
          ctx.beginPath();
          ctx.arc(0, -82, 16, Math.PI, 0);
          ctx.fill();
        } else {
          // Enemy (Villains)
          let bodyColor = '#212121';
          let headSize = 18;
          let bodyWidth = 50;
          let bodyHeight = 85;

          if (entity.isBoss) {
            bodyColor = '#4a148c'; // Purple for boss
            bodyWidth = 100;
            bodyHeight = 140;
            headSize = 30;
          } else if (entity.type === 'TANK') {
            bodyColor = '#37474f';
            bodyWidth = 70;
            bodyHeight = 100;
            headSize = 22;
          } else if (entity.type === 'STRIKER') {
            bodyColor = '#b71c1c';
            bodyWidth = 40;
            bodyHeight = 75;
          } else if (entity.type === 'SNIPER') {
            bodyColor = '#1b5e20';
            bodyWidth = 45;
          }

          ctx.fillStyle = bodyColor;
          ctx.fillRect(-bodyWidth/2, -bodyHeight, bodyWidth, bodyHeight);
          ctx.fillStyle = '#d7ccc8'; // Skin
          ctx.beginPath();
          ctx.arc(0, -bodyHeight - 10, headSize, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#000'; // Mask
          ctx.fillRect(-headSize*0.8, -bodyHeight - 15, headSize*1.6, 10);
          // Gun
          ctx.fillStyle = '#333';
          ctx.fillRect(-bodyWidth*1.3, -bodyHeight*0.7, bodyWidth, 12);
          
          // Type Label
          ctx.fillStyle = entity.isBoss ? '#ffeb3b' : 'white';
          ctx.font = entity.isBoss ? 'bold 14px sans-serif' : 'bold 10px sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(entity.isBoss ? 'BOSS' : (entity.type || 'GRUNT'), 0, -bodyHeight - (entity.isBoss ? 45 : 35));
        }

        ctx.restore();

        // HP Bar
        const barWidth = 70 * scale;
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(drawX - barWidth/2, drawY - 130 * scale, barWidth, 8);
        ctx.fillStyle = entity.id === 'player' ? '#00e676' : '#ff006e';
        ctx.fillRect(drawX - barWidth/2, drawY - 130 * scale, (entity.hp / entity.maxHp) * barWidth, 8);
      });

      // Reward Text
      ctx.font = 'bold 16px sans-serif';
      ctx.textAlign = 'center';
      rewardText.forEach(reward => {
        ctx.fillStyle = '#00e676';
        ctx.fillText(reward.text, reward.x, reward.y);
      });

      // Crosshair
      const mouseX = mousePosRef.current.x;
      const mouseY = mousePosRef.current.y;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(mouseX, mouseY, 20, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(mouseX - 10, mouseY);
      ctx.lineTo(mouseX + 10, mouseY);
      ctx.moveTo(mouseX, mouseY - 10);
      ctx.lineTo(mouseX, mouseY + 10);
      ctx.stroke();
    }

    requestRef.current = requestAnimationFrame(update);
  }, [gameState, isPaused, activeWeapon, isReloading, isAiming, operator, world, switchWeapon, reload, throwGrenade, initGame]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(update);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [update]);

  return (
    <div className="relative w-full aspect-video bg-slate-900 rounded-3xl overflow-hidden border-4 border-white/10 shadow-2xl">
      {/* Top HUD - Level & Stats */}
      <div className="absolute top-6 left-6 z-20 flex flex-col gap-1">
        <div className="bg-black/80 backdrop-blur-md border border-white/20 px-4 py-3 rounded-xl flex items-center gap-4 shadow-2xl">
          <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center border border-red-500/50">
             <Trophy className="w-7 h-7 text-yellow-500" />
          </div>
          <div className="flex flex-col min-w-[120px]">
            <div className="flex justify-between items-center">
              <span className="text-[11px] font-black text-cyan-400 uppercase tracking-tighter">Level</span>
              <span className="text-lg font-black text-white">{level}</span>
            </div>
            <div className="h-px w-full bg-white/10 my-1" />
            <div className="flex justify-between items-center">
              <span className="text-[11px] font-black text-red-500 uppercase tracking-tighter">Villains Left</span>
              <span className="text-lg font-black text-white">{(5 + level * 3) - levelKills}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Top Center HUD - Weapon & Stats */}
      <div className="absolute top-6 left-1/2 -translate-x-1/2 z-20 flex items-center gap-4">
        <div className="bg-black/80 backdrop-blur-md border border-white/20 px-8 py-4 rounded-2xl flex items-center gap-8 shadow-2xl">
          <div className="flex flex-col items-center">
            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Kills</span>
            <span className="text-2xl font-black text-emerald-400">{kills}</span>
          </div>
          <div className="h-10 w-px bg-white/10" />
          <div className="flex flex-col items-center min-w-[100px]">
             <div className="text-[12px] font-black text-white uppercase mb-1 flex items-center gap-2">
               <Target className="w-4 h-4 text-cyan-400" />
               {activeWeapon}
             </div>
             <div className={`text-lg font-mono font-black ${ammo < 5 ? 'text-red-500 animate-pulse' : 'text-white'}`}>
               {isReloading ? 'RELOADING...' : `${ammo}/${WEAPONS[activeWeapon].maxAmmo}`}
             </div>
          </div>
          <div className="h-10 w-px bg-white/10" />
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-2">
              <Coins className="w-5 h-5 text-yellow-500" />
              <span className="text-xl font-black text-white">{money}</span>
            </div>
            <span className="text-[9px] font-black text-yellow-500/60 uppercase tracking-widest">Credits</span>
          </div>
        </div>
      </div>

      {/* Top Right - Pause */}
      <button 
        onClick={() => setIsPaused(!isPaused)}
        className={`absolute top-6 right-6 z-20 w-14 h-14 bg-black/80 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center transition-all shadow-2xl group ${
          isPaused ? 'bg-yellow-500 text-black border-yellow-400' : 'text-white hover:bg-white hover:text-black'
        }`}
      >
        {isPaused ? <Play className="w-7 h-7" /> : <Pause className="w-7 h-7 group-hover:scale-110 transition-transform" />}
      </button>

      {/* Bottom Center - Inventory Bar */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2 bg-black/40 backdrop-blur-md p-2 rounded-2xl border border-white/10">
        {inventory.map((w, i) => (
          <button
            key={w}
            onClick={() => switchWeapon(w)}
            className={`w-14 h-14 rounded-xl border-2 flex flex-col items-center justify-center transition-all relative ${
              activeWeapon === w ? 'bg-cyan-500 border-cyan-400 text-white shadow-[0_0_15px_rgba(34,211,238,0.4)]' : 'bg-white/5 border-white/10 text-white/40 hover:bg-white/10'
            }`}
          >
            <span className="text-[8px] font-black absolute top-1 left-1 opacity-50">{i + 1}</span>
            <Target className={`w-6 h-6 ${activeWeapon === w ? 'text-white' : 'text-white/20'}`} />
            <span className="text-[8px] font-black mt-1 uppercase truncate w-full px-1 text-center">{w}</span>
          </button>
        ))}
        {inventory.length < 4 && (
          <button
            onClick={() => setShowBuyMenu(true)}
            className="w-14 h-14 rounded-xl border-2 border-dashed border-white/10 flex items-center justify-center text-white/20 hover:border-white/20 hover:text-white/40 transition-all"
          >
            <Plus className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Left - Movement & Health */}
      <div className="absolute bottom-8 left-8 z-20 flex items-end gap-8">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 bg-black/60 px-3 py-1 rounded-full border border-white/10">
            <Activity className="w-4 h-4 text-red-500" />
            <div className="w-32 h-2 bg-white/10 rounded-full overflow-hidden">
              <motion.div 
                animate={{ width: `${(playerHp / maxHp) * 100}%` }}
                className="h-full bg-red-500"
              />
            </div>
          </div>
          <div className="w-32 h-32 bg-black/40 backdrop-blur-sm rounded-full border-4 border-white/10 flex items-center justify-center relative">
            <div className="w-20 h-20 bg-white/5 rounded-full border border-white/10 flex items-center justify-center">
              <Gamepad2 className="w-10 h-10 text-white/20" />
            </div>
            {/* Visual Joystick Handle */}
            <motion.div 
              animate={{ 
                x: (keysRef.current['KeyD'] || keysRef.current['ArrowRight']) ? 20 : (keysRef.current['KeyA'] || keysRef.current['ArrowLeft']) ? -20 : 0,
                y: (keysRef.current['KeyS'] || keysRef.current['ArrowDown']) ? 20 : (keysRef.current['KeyW'] || keysRef.current['ArrowUp']) ? -20 : 0
              }}
              className="absolute w-12 h-12 bg-white/20 rounded-full border border-white/40 shadow-xl" 
            />
          </div>
        </div>
        <button 
          onClick={() => {
            if (healthKits > 0) {
              setPlayerHp(h => Math.min(100, h + 50));
              setHealthKits(k => k - 1);
            }
          }}
          className="relative group"
        >
          <div className="w-20 h-20 bg-black/80 backdrop-blur-md border border-white/20 rounded-2xl flex items-center justify-center text-white group-hover:bg-emerald-500 transition-all shadow-2xl relative">
            <Plus className="w-10 h-10" />
            <span className="absolute top-1 left-1 text-[8px] font-bold text-white/30">H</span>
          </div>
          <div className="absolute -top-3 -right-3 w-8 h-8 bg-emerald-500 rounded-full flex items-center justify-center text-xs font-black text-white border-4 border-slate-900 shadow-lg">
            {healthKits}
          </div>
          <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-black text-white/40 uppercase">Heal</span>
        </button>
      </div>

      {/* Bottom Right - Combat Controls */}
      <div className="absolute bottom-8 right-8 z-20 flex items-end gap-6">
        <div className="flex flex-col gap-4">
          <button 
            onClick={() => setShowBuyMenu(!showBuyMenu)}
            className="w-16 h-16 bg-black/80 backdrop-blur-md border border-white/20 rounded-2xl flex items-center justify-center text-yellow-500 hover:bg-yellow-500 hover:text-black transition-all shadow-2xl relative"
          >
            <ShoppingCart className="w-8 h-8" />
            <span className="absolute top-1 left-1 text-[8px] font-bold text-white/30">B</span>
          </button>
          <button 
            onClick={() => setIsAiming(!isAiming)}
            className={`w-16 h-16 rounded-2xl border-2 flex items-center justify-center transition-all shadow-2xl relative ${
              isAiming ? 'bg-cyan-500 border-white text-white' : 'bg-black/80 border-white/20 text-white/40'
            }`}
          >
            <Eye className="w-8 h-8" />
            <span className="absolute top-1 left-1 text-[8px] font-bold text-white/30">R-CLICK</span>
          </button>
          <button 
            onClick={reload}
            className="w-16 h-16 bg-black/80 backdrop-blur-md border border-white/20 rounded-2xl flex items-center justify-center text-white/40 hover:text-white transition-all shadow-2xl relative"
          >
            <RotateCcw className={`w-8 h-8 ${isReloading ? 'animate-spin' : ''}`} />
            <span className="absolute top-1 left-1 text-[8px] font-bold text-white/30">R</span>
          </button>
        </div>
        
        <div className="flex flex-col gap-4 items-center">
          <button 
            onClick={throwGrenade}
            className="relative group"
          >
            <div className="w-20 h-20 bg-black/80 backdrop-blur-md border border-white/20 rounded-2xl flex items-center justify-center text-white group-hover:bg-orange-500 transition-all shadow-2xl relative">
              <Bomb className="w-10 h-10" />
              <span className="absolute top-1 left-1 text-[8px] font-bold text-white/30">G</span>
            </div>
            <div className="absolute -top-3 -right-3 w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-xs font-black text-white border-4 border-slate-900 shadow-lg">
              {grenades}
            </div>
          </button>

          <div className="relative flex items-center justify-center">
            {/* Outer Ring */}
            <div className="absolute w-36 h-36 border-4 border-white/5 rounded-full animate-spin-slow" />
            
            <button 
              onMouseDown={(e) => {
                if (e.button === 0) keysRef.current['MOUSE_LEFT'] = true;
              }}
              onMouseUp={(e) => {
                if (e.button === 0) keysRef.current['MOUSE_LEFT'] = false;
              }}
              className="w-28 h-28 bg-red-500/20 border-4 border-red-500/50 rounded-full flex items-center justify-center text-red-500 hover:bg-red-500 hover:text-white transition-all active:scale-90 shadow-[0_0_40px_rgba(239,68,68,0.3)] relative"
            >
              <Zap className="w-14 h-14" />
              <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[8px] font-bold text-white/30">L-CLICK / SPACE</span>
            </button>
          </div>
        </div>
      </div>

      {/* Buy Menu Overlay */}
      <AnimatePresence>
        {showBuyMenu && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="absolute inset-0 z-40 bg-black/60 backdrop-blur-md flex items-center justify-center p-8"
          >
            <div className="bg-slate-900 border border-white/10 rounded-3xl p-8 w-full max-w-2xl shadow-2xl">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Armory</h3>
                <button onClick={() => setShowBuyMenu(false)} className="text-white/40 hover:text-white">Close</button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {(Object.keys(WEAPONS) as WeaponType[]).map(w => (
                  <button 
                    key={w}
                    onClick={() => {
                      if (inventory.includes(w)) {
                        switchWeapon(w);
                        setShowBuyMenu(false);
                      } else if (money >= 1000) {
                        setInventory(prev => [...prev, w]);
                        switchWeapon(w);
                        setMoney(m => m - 1000);
                        setShowBuyMenu(false);
                      }
                    }}
                    className={`p-6 rounded-2xl border-2 flex flex-col items-start gap-2 transition-all ${
                      activeWeapon === w ? 'bg-cyan-500/20 border-cyan-500' : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex justify-between w-full items-center">
                      <span className="text-lg font-black text-white">{w}</span>
                      {inventory.includes(w) && <span className="text-[10px] bg-cyan-500 text-white px-2 py-1 rounded">OWNED</span>}
                    </div>
                    <span className="text-xs text-white/40 uppercase">
                      {inventory.includes(w) ? 'Switch to weapon' : 'Cost: 1000 Credits'}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Game Canvas */}
      <canvas 
        ref={canvasRef}
        width={800}
        height={450}
        className="w-full h-full cursor-none"
      />

      {/* Game States */}
      <AnimatePresence>
        {isPaused && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center"
          >
            <div className="bg-slate-900 border border-white/10 p-12 rounded-3xl text-center shadow-2xl">
              <Pause className="w-20 h-20 text-yellow-500 mx-auto mb-6 animate-pulse" />
              <h2 className="text-5xl font-black text-white uppercase italic mb-8">Mission Paused</h2>
              <button 
                onClick={() => setIsPaused(false)}
                className="px-12 py-4 bg-yellow-500 text-black font-black uppercase tracking-widest rounded-xl hover:scale-105 transition-all"
              >
                Resume Operation
              </button>
            </div>
          </motion.div>
        )}

        {gameState === 'START' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-12 text-center"
          >
            <div className="w-24 h-24 bg-red-600/20 rounded-3xl flex items-center justify-center border border-red-600/50 mb-6 shadow-[0_0_30px_rgba(220,38,38,0.3)]">
              <Flame className="w-12 h-12 text-red-500 animate-pulse" />
            </div>
            <h1 className="text-6xl font-black text-white italic uppercase tracking-tighter mb-4">Cyber Strike: Horde Mode</h1>
            {operator && (
              <div className="mb-6 flex items-center gap-4 bg-white/5 px-6 py-2 rounded-full border border-white/10">
                <img src={operator.thumbnail} alt={operator.codename} className="w-8 h-8 rounded-full border border-red-500" />
                <span className="text-sm font-black uppercase tracking-widest text-red-500">{operator.codename} Deployed</span>
              </div>
            )}
            <p className="text-white/40 font-serif italic text-lg max-w-md mb-8">
              Eliminate all villains in the sector. Each kill restores health and ammo. Survive as many levels as possible.
            </p>
            
            {/* Controls Help */}
            <div className="grid grid-cols-2 gap-x-12 gap-y-2 mb-10 text-left bg-white/5 p-6 rounded-2xl border border-white/10">
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Move</span>
                <span className="text-xs font-black text-cyan-400">WASD / ARROWS</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Shoot</span>
                <span className="text-xs font-black text-red-500">L-CLICK / SPACE</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Aim (ADS)</span>
                <span className="text-xs font-black text-cyan-400">R-CLICK</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Reload</span>
                <span className="text-xs font-black text-yellow-500">R</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Grenade</span>
                <span className="text-xs font-black text-orange-500">G</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Heal</span>
                <span className="text-xs font-black text-emerald-500">H</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Buy Menu</span>
                <span className="text-xs font-black text-yellow-500">B / ESC</span>
              </div>
              <div className="flex justify-between items-center gap-4">
                <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Sprint</span>
                <span className="text-xs font-black text-white">SHIFT</span>
              </div>
            </div>

            <button 
              onClick={initGame}
              className="px-16 py-5 bg-red-600 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all shadow-[0_0_30px_rgba(220,38,38,0.3)]"
            >
              Start Mission
            </button>
          </motion.div>
        )}

        {(gameState === 'WON' || gameState === 'LOST') && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-12 text-center"
          >
            <h2 className="text-6xl font-black text-white italic uppercase tracking-tighter mb-2">
              {gameState === 'WON' ? `Level ${level-1} Clear` : 'Mission Failed'}
            </h2>
            <p className="text-white/40 font-mono text-sm uppercase tracking-[0.4em] mb-8">
              Kills: {kills} | Level: {level}
            </p>
            <button 
              onClick={initGame}
              className="px-10 py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest hover:bg-cyan-500 hover:text-white transition-all"
            >
              {gameState === 'WON' ? 'Next Level' : 'Retry'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
