import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Diamond, Heart, Club, Spade, 
  Trophy, Coins, User, Settings, 
  LayoutDashboard, Play, Lock, 
  ChevronRight, Star, Zap, Shield, 
  MessageSquare, Users, Gift, 
  Home, Wallet, History, HelpCircle,
  TrendingUp, Rocket, Gem
} from 'lucide-react';
import QuantumPoker from './QuantumPoker';
import Solitaire from './Solitaire';
import Blackjack from './Blackjack';
import CrashGame from './CrashGame';
import MinesGame from './MinesGame';

type GameType = 'HUB' | 'POKER' | 'SOLITAIRE' | 'BLACKJACK' | 'CRASH' | 'MINES';

interface Level {
  id: number;
  title: string;
  description: string;
  stakes: number;
  difficulty: string;
  isLocked: boolean;
  reward: number;
  image: string;
}

const POKER_LEVELS: Level[] = [
  { id: 1, title: "Beginner's Table", description: "Learn the basics of probabilistic betting.", stakes: 100, difficulty: "EASY", isLocked: false, reward: 500, image: "https://picsum.photos/seed/poker1/800/600" },
  { id: 2, title: "High Roller's Lounge", description: "Test your skills against seasoned AI players.", stakes: 500, difficulty: "MEDIUM", isLocked: false, reward: 2500, image: "https://picsum.photos/seed/poker2/800/600" },
  { id: 3, title: "Nexus VIP", description: "Exclusive table for the hub's elite.", stakes: 2000, difficulty: "HARD", isLocked: true, reward: 10000, image: "https://picsum.photos/seed/poker3/800/600" },
  { id: 4, title: "Grandmaster's Void", description: "The ultimate challenge. No room for error.", stakes: 10000, difficulty: "GRANDMASTER", isLocked: true, reward: 50000, image: "https://picsum.photos/seed/poker4/800/600" },
];

const SOLITAIRE_LEVELS: Level[] = [
  { id: 1, title: "Classic Sort", description: "Standard solitaire with a digital twist.", stakes: 50, difficulty: "EASY", isLocked: false, reward: 200, image: "https://picsum.photos/seed/sol1/800/600" },
  { id: 2, title: "Entropy Mode", description: "Cards are shuffled with higher complexity.", stakes: 200, difficulty: "MEDIUM", isLocked: false, reward: 800, image: "https://picsum.photos/seed/sol2/800/600" },
  { id: 3, title: "Void Challenge", description: "Limited moves, high precision required.", stakes: 1000, difficulty: "HARD", isLocked: true, reward: 4000, image: "https://picsum.photos/seed/sol3/800/600" },
];

const BLACKJACK_LEVELS: Level[] = [
  { id: 1, title: "Neon Table", description: "Classic 21 with neon aesthetics.", stakes: 100, difficulty: "EASY", isLocked: false, reward: 200, image: "https://picsum.photos/seed/bj1/800/600" },
  { id: 2, title: "Cyber Dealer", description: "Face off against a high-speed AI dealer.", stakes: 500, difficulty: "MEDIUM", isLocked: false, reward: 1000, image: "https://picsum.photos/seed/bj2/800/600" },
  { id: 3, title: "The Vault", description: "High stakes, high pressure. Can you beat the house?", stakes: 5000, difficulty: "HARD", isLocked: true, reward: 10000, image: "https://picsum.photos/seed/bj3/800/600" },
];

const CRASH_LEVELS: Level[] = [
  { id: 1, title: "Orbital Launch", description: "Standard velocity protocol.", stakes: 100, difficulty: "EASY", isLocked: false, reward: 1000, image: "https://picsum.photos/seed/crash1/800/600" },
  { id: 2, title: "Deep Space", description: "Unstable gravity fields.", stakes: 1000, difficulty: "MEDIUM", isLocked: false, reward: 10000, image: "https://picsum.photos/seed/crash2/800/600" },
];

const MINES_LEVELS: Level[] = [
  { id: 1, title: "Surface Scan", description: "Low density minefield.", stakes: 100, difficulty: "EASY", isLocked: false, reward: 500, image: "https://picsum.photos/seed/mines1/800/600" },
  { id: 2, title: "Core Extraction", description: "High density mineral zone.", stakes: 1000, difficulty: "HARD", isLocked: false, reward: 5000, image: "https://picsum.photos/seed/mines2/800/600" },
];

export default function CardRealm() {
  const [activeGame, setActiveGame] = useState<GameType>('HUB');
  const [selectedLevel, setSelectedLevel] = useState<Level | null>(null);
  const [credits, setCredits] = useState(5000);
  const [activeTab, setActiveTab] = useState('GAMES');

  const handleStartGame = (level: Level) => {
    if (level.isLocked) return;
    setSelectedLevel(level);
    // Game type is determined by context (e.g., if we are in Poker section)
  };

  const SidebarItem = ({ icon: Icon, label, id, active }: { icon: any; label: string; id: string; active: boolean }) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${
        active 
          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shadow-[0_0_20px_rgba(6,182,212,0.1)]" 
          : "text-white/40 hover:text-white hover:bg-white/5"
      }`}
    >
      <Icon size={20} />
      <span className="text-sm font-black uppercase tracking-tighter">{label}</span>
    </button>
  );

  const HubView = () => (
    <div className="flex flex-col gap-12">
      {/* Hero Section */}
      <div className="relative h-[450px] rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl group">
        <motion.img 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 20, repeat: Infinity, repeatType: 'reverse' }}
          src="https://picsum.photos/seed/casino_hero/1920/1080" 
          alt="Casino Hero" 
          className="w-full h-full object-cover opacity-60"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#010103] via-[#010103]/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#010103] via-transparent to-transparent" />
        
        <div className="absolute bottom-12 left-12 max-w-2xl z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 mb-6"
          >
            <div className="px-4 py-1.5 bg-cyan-500 text-black text-[10px] font-black rounded-full uppercase tracking-[0.2em] shadow-[0_0_20px_rgba(6,182,212,0.4)]">Featured Game</div>
            <div className="text-white/40 text-[10px] font-mono uppercase tracking-[0.4em]">Node_Omega // Velocity_Protocol</div>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-7xl lg:text-9xl font-black text-white tracking-tighter uppercase italic leading-[0.85] mb-8"
          >
            Nexus <span className="text-purple-400">Solitaire</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-white/60 font-serif italic mb-10 max-w-lg leading-relaxed"
          >
            Master the art of sorting in the digital void. Complete daily goals and earn massive rewards in our most popular card game.
          </motion.p>
          <motion.button 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            onClick={() => {
              setActiveGame('SOLITAIRE');
              setSelectedLevel(SOLITAIRE_LEVELS[0]);
            }}
            className="px-12 py-5 bg-purple-500 text-white font-black rounded-2xl hover:bg-white hover:text-purple-600 transition-all uppercase tracking-[0.2em] text-sm shadow-[0_0_50px_rgba(168,85,247,0.4)] hover:scale-105 active:scale-95"
          >
            Start Sorting
          </motion.button>
        </div>

        {/* Floating Decorative Elements */}
        <div className="absolute top-12 right-12 flex flex-col gap-4">
          <div className="bg-black/60 backdrop-blur-xl p-6 rounded-3xl border border-white/10 flex items-center gap-4">
            <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center border border-emerald-500/30">
              <TrendingUp className="text-emerald-400" size={20} />
            </div>
            <div>
              <span className="text-[8px] font-black text-white/30 uppercase tracking-widest block">Highest Multiplier</span>
              <span className="text-xl font-black text-emerald-400">1,245.50x</span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats & Ticker Row */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 backdrop-blur-xl flex items-center gap-6 group hover:bg-white/10 transition-all">
            <div className="w-16 h-16 bg-amber-500/10 rounded-2xl border border-amber-500/30 flex items-center justify-center shadow-lg shadow-amber-500/20 group-hover:scale-110 transition-transform">
              <Coins className="text-amber-400 w-8 h-8" />
            </div>
            <div>
              <span className="text-[10px] font-black text-white/30 uppercase tracking-widest block mb-1">Total Balance</span>
              <span className="text-3xl font-black tabular-nums">${credits.toLocaleString()}</span>
            </div>
          </div>
          <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 backdrop-blur-xl flex items-center gap-6 group hover:bg-white/10 transition-all">
            <div className="w-16 h-16 bg-cyan-500/10 rounded-2xl border border-cyan-500/30 flex items-center justify-center shadow-lg shadow-cyan-500/20 group-hover:scale-110 transition-transform">
              <Trophy className="text-cyan-400 w-8 h-8" />
            </div>
            <div>
              <span className="text-[10px] font-black text-white/30 uppercase tracking-widest block mb-1">Rank Level</span>
              <span className="text-3xl font-black tabular-nums">Diamond IV</span>
            </div>
          </div>
          <div className="bg-white/5 p-8 rounded-[2.5rem] border border-white/10 backdrop-blur-xl flex items-center gap-6 group hover:bg-white/10 transition-all">
            <div className="w-16 h-16 bg-purple-500/10 rounded-2xl border border-purple-500/30 flex items-center justify-center shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-transform">
              <Star className="text-purple-400 w-8 h-8" />
            </div>
            <div>
              <span className="text-[10px] font-black text-white/30 uppercase tracking-widest block mb-1">VIP Points</span>
              <span className="text-3xl font-black tabular-nums">12,450</span>
            </div>
          </div>
        </div>
        <div className="bg-cyan-500/5 p-8 rounded-[2.5rem] border border-cyan-500/20 backdrop-blur-xl flex flex-col justify-center">
          <div className="flex items-center gap-2 mb-4">
            <History className="text-cyan-400" size={14} />
            <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">Live Ticker</span>
          </div>
          <div className="space-y-3">
            {[
              { user: "Whisper", win: "$1,200", game: "Crash" },
              { user: "Jacob.Null", win: "$450", game: "Poker" },
            ].map((win, i) => (
              <div key={i} className="flex justify-between items-center text-[10px]">
                <span className="text-white/40 uppercase font-mono">{win.user}</span>
                <span className="text-emerald-400 font-black">{win.win}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Sections - Bento Grid Style */}
      <div className="flex flex-col gap-24">
        {/* Main Games Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {/* Crash Card - Large */}
          <motion.div 
            whileHover={{ y: -10 }}
            className="lg:col-span-2 group relative h-[500px] rounded-[3.5rem] overflow-hidden border border-white/10 cursor-pointer"
            onClick={() => {
              setActiveGame('CRASH');
              setSelectedLevel(CRASH_LEVELS[0]);
            }}
          >
            <img src="https://picsum.photos/seed/crash_main/1200/800" className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-all duration-700" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#010103] via-transparent to-transparent" />
            <div className="absolute bottom-12 left-12">
              <div className="flex items-center gap-3 mb-4">
                <Rocket className="text-cyan-400" size={24} />
                <h3 className="text-5xl font-black uppercase tracking-tighter italic">Nexus Crash</h3>
              </div>
              <p className="text-white/40 text-sm font-mono uppercase tracking-widest mb-8">High Velocity // Instant Payouts</p>
              <div className="flex gap-4">
                <div className="px-6 py-3 bg-white/5 rounded-2xl border border-white/10 text-xs font-black uppercase tracking-widest">2 Levels</div>
                <div className="px-6 py-3 bg-cyan-500 text-black rounded-2xl text-xs font-black uppercase tracking-widest shadow-[0_0_30px_rgba(6,182,212,0.3)]">Play Now</div>
              </div>
            </div>
          </motion.div>

          {/* Mines Card */}
          <motion.div 
            whileHover={{ y: -10 }}
            className="group relative h-[500px] rounded-[3.5rem] overflow-hidden border border-white/10 cursor-pointer"
            onClick={() => {
              setActiveGame('MINES');
              setSelectedLevel(MINES_LEVELS[0]);
            }}
          >
            <img src="https://picsum.photos/seed/mines_main/800/1200" className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-all duration-700" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#010103] via-transparent to-transparent" />
            <div className="absolute bottom-12 left-12">
              <div className="flex items-center gap-3 mb-4">
                <Gem className="text-emerald-400" size={24} />
                <h3 className="text-4xl font-black uppercase tracking-tighter italic">Nexus Mines</h3>
              </div>
              <p className="text-white/40 text-sm font-mono uppercase tracking-widest mb-8">Grid Extraction // Risk Protocol</p>
              <div className="flex gap-4">
                <div className="px-6 py-3 bg-emerald-500 text-black rounded-2xl text-xs font-black uppercase tracking-widest shadow-[0_0_30px_rgba(16,185,129,0.3)]">Play Now</div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Card Games Section */}
        <div>
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-6xl font-black uppercase tracking-tighter italic">Card Realm</h2>
              <p className="text-white/40 text-sm font-mono uppercase tracking-[0.4em] mt-4">Premium_Table_Games // Neural_AI_Dealers</p>
            </div>
            <div className="flex gap-4">
              <button className="px-8 py-3 bg-white/5 rounded-2xl border border-white/10 text-xs font-black uppercase tracking-widest hover:bg-white/10 transition-all">All Games</button>
              <button className="px-8 py-3 bg-cyan-500 text-black rounded-2xl text-xs font-black uppercase tracking-widest shadow-[0_0_30px_rgba(6,182,212,0.3)]">New Releases</button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Poker Card */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group relative h-[600px] rounded-[3.5rem] overflow-hidden border border-white/10 cursor-pointer"
              onClick={() => {
                setActiveGame('POKER');
                setSelectedLevel(POKER_LEVELS[0]);
              }}
            >
              <img src="https://picsum.photos/seed/poker_hub/800/1200" className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-all duration-700" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#010103] via-transparent to-transparent" />
              <div className="absolute top-8 right-8 px-4 py-2 bg-black/60 backdrop-blur-xl rounded-2xl border border-white/10 text-[10px] font-black uppercase tracking-widest text-cyan-400">4 Levels</div>
              <div className="absolute bottom-12 left-12">
                <h3 className="text-4xl font-black uppercase tracking-tighter italic mb-4">Classic Poker</h3>
                <p className="text-white/40 text-sm font-mono uppercase tracking-widest mb-8">Probabilistic Betting // AI Opponents</p>
                <div className="flex items-center gap-4">
                  <div className="flex -space-x-3">
                    {[1,2,3].map(i => (
                      <div key={i} className="w-10 h-10 rounded-full border-2 border-[#010103] bg-white/10 flex items-center justify-center">
                        <User size={16} className="text-white/40" />
                      </div>
                    ))}
                  </div>
                  <span className="text-[10px] font-black text-white/30 uppercase tracking-widest">124 Players Online</span>
                </div>
              </div>
            </motion.div>

            {/* Blackjack Card */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group relative h-[600px] rounded-[3.5rem] overflow-hidden border border-white/10 cursor-pointer"
              onClick={() => {
                setActiveGame('BLACKJACK');
                setSelectedLevel(BLACKJACK_LEVELS[0]);
              }}
            >
              <img src="https://picsum.photos/seed/bj_hub/800/1200" className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-all duration-700" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#010103] via-transparent to-transparent" />
              <div className="absolute top-8 right-8 px-4 py-2 bg-black/60 backdrop-blur-xl rounded-2xl border border-white/10 text-[10px] font-black uppercase tracking-widest text-emerald-400">3 Levels</div>
              <div className="absolute bottom-12 left-12">
                <h3 className="text-4xl font-black uppercase tracking-tighter italic mb-4">Cyber Blackjack</h3>
                <p className="text-white/40 text-sm font-mono uppercase tracking-widest mb-8">Neural 21 // High Stakes</p>
                <button className="w-full py-4 bg-emerald-500 text-black font-black rounded-2xl uppercase tracking-widest text-xs shadow-[0_0_30px_rgba(16,185,129,0.3)]">Enter Table</button>
              </div>
            </motion.div>

            {/* Solitaire Card */}
            <motion.div 
              whileHover={{ y: -10 }}
              className="group relative h-[600px] rounded-[3.5rem] overflow-hidden border border-white/10 cursor-pointer"
              onClick={() => {
                setActiveGame('SOLITAIRE');
                setSelectedLevel(SOLITAIRE_LEVELS[0]);
              }}
            >
              <img src="https://picsum.photos/seed/sol_hub/800/1200" className="w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-all duration-700" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-gradient-to-t from-[#010103] via-transparent to-transparent" />
              <div className="absolute top-8 right-8 px-4 py-2 bg-black/60 backdrop-blur-xl rounded-2xl border border-white/10 text-[10px] font-black uppercase tracking-widest text-purple-400">3 Levels</div>
              <div className="absolute bottom-12 left-12">
                <h3 className="text-4xl font-black uppercase tracking-tighter italic mb-4">Solitaire Realm</h3>
                <p className="text-white/40 text-sm font-mono uppercase tracking-widest mb-8">Classic Sorting // High Entropy</p>
                <button className="w-full py-4 bg-purple-500 text-black font-black rounded-2xl uppercase tracking-widest text-xs shadow-[0_0_30px_rgba(168,85,247,0.3)]">Start Sorting</button>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-[800px] h-full bg-[#010103] lg:rounded-[3rem] border border-white/10 overflow-hidden shadow-2xl relative">
      {/* Sidebar - Hidden when game is active for immersive feel */}
      <AnimatePresence>
        {activeGame === 'HUB' && (
          <motion.div 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 320, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className="border-r border-white/10 bg-black/40 backdrop-blur-3xl p-8 flex flex-col gap-12 overflow-hidden whitespace-nowrap"
          >
            <div className="flex items-center gap-4 px-4">
              <div className="w-12 h-12 bg-cyan-500 rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(6,182,212,0.4)]">
                <Zap className="text-black" />
              </div>
              <div>
                <h2 className="text-2xl font-black uppercase tracking-tighter italic">Nexus Casino</h2>
                <p className="text-[8px] font-mono text-white/30 uppercase tracking-[0.4em]">v2.5.0 // Card_Realm</p>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <SidebarItem icon={Home} label="Home Page" id="HOME" active={activeTab === 'HOME'} />
              <SidebarItem icon={LayoutDashboard} label="Casino Hub" id="GAMES" active={activeTab === 'GAMES'} />
              <SidebarItem icon={History} label="History" id="HISTORY" active={activeTab === 'HISTORY'} />
              <SidebarItem icon={Users} label="Friends" id="FRIENDS" active={activeTab === 'FRIENDS'} />
              <SidebarItem icon={Gift} label="Promotions" id="PROMO" active={activeTab === 'PROMO'} />
            </div>

            <div className="mt-auto flex flex-col gap-4">
              <div className="bg-white/5 p-6 rounded-3xl border border-white/10">
                <div className="flex items-center gap-3 mb-4">
                  <Shield className="text-cyan-400" size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">VIP Program</span>
                </div>
                <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden mb-2">
                  <div className="bg-cyan-500 h-full w-[65%]" />
                </div>
                <p className="text-[8px] text-white/40 uppercase tracking-widest">65% to next level</p>
              </div>
              <button className="w-full py-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/10 text-xs font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2">
                <HelpCircle size={14} /> Live Support
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-6 lg:p-12 bg-gradient-to-br from-black via-[#010103] to-cyan-950/20 flex flex-col">
        <AnimatePresence mode="wait">
          {activeGame === 'HUB' ? (
            <motion.div 
              key="hub"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="w-full"
            >
              <HubView />
            </motion.div>
          ) : (
            <motion.div 
              key="game"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex-1 flex flex-col w-full"
            >
              <div className="flex items-center justify-between mb-8">
                <button 
                  onClick={() => {
                    setActiveGame('HUB');
                    setSelectedLevel(null);
                  }}
                  className="flex items-center gap-3 text-white/40 hover:text-white transition-all group"
                >
                  <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center border border-white/10 group-hover:border-cyan-500/50">
                    <ChevronRight className="rotate-180" size={16} />
                  </div>
                  <span className="text-xs font-black uppercase tracking-widest">Back to Hub</span>
                </button>
                
                {selectedLevel && (
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <h3 className="text-xl font-black uppercase tracking-tighter italic">{selectedLevel.title}</h3>
                      <p className="text-[10px] text-white/40 uppercase tracking-widest">Difficulty: {selectedLevel.difficulty}</p>
                    </div>
                    <div className="w-[1px] h-10 bg-white/10" />
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-amber-500/10 rounded-xl border border-amber-500/30 flex items-center justify-center">
                        <Coins className="text-amber-400" size={20} />
                      </div>
                      <div>
                        <span className="text-[8px] text-white/30 uppercase tracking-widest block">Pot</span>
                        <span className="text-xl font-black tabular-nums">${selectedLevel.stakes.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-black/40 backdrop-blur-3xl rounded-[3rem] border border-white/10 p-4 lg:p-8 flex-1 w-full overflow-hidden flex flex-col">
                <div className="flex-1 w-full overflow-y-auto custom-scrollbar">
                  {activeGame === 'POKER' && <QuantumPoker difficulty={selectedLevel?.difficulty} />}
                  {activeGame === 'SOLITAIRE' && <Solitaire />}
                  {activeGame === 'BLACKJACK' && <Blackjack />}
                  {activeGame === 'CRASH' && <CrashGame />}
                  {activeGame === 'MINES' && <MinesGame />}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Right Panel: Social / Friends - Hidden when game is active */}
      <AnimatePresence>
        {activeGame === 'HUB' && (
          <motion.div 
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 320, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className="border-l border-white/10 bg-black/40 backdrop-blur-3xl p-8 flex flex-col gap-8 overflow-hidden whitespace-nowrap"
          >
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-black uppercase tracking-tighter italic">Social Node</h3>
              <div className="flex gap-2">
                <button className="p-2 bg-white/5 rounded-lg border border-white/10"><MessageSquare size={14} /></button>
                <button className="p-2 bg-white/5 rounded-lg border border-white/10"><Users size={14} /></button>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              <div className="bg-cyan-500/10 p-6 rounded-3xl border border-cyan-500/20">
                <div className="flex items-center gap-3 mb-4">
                  <Gift className="text-cyan-400" size={16} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Free Bonus</span>
                </div>
                <p className="text-xs text-white/60 mb-4">Claim your daily credits to keep the game going.</p>
                <button className="w-full py-3 bg-cyan-500 text-black text-[10px] font-black uppercase tracking-widest rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.3)]">
                  Claim $500
                </button>
              </div>

              <div className="flex flex-col gap-4">
                <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.4em] px-2">Online Friends</span>
                {[
                  { name: "Whisper", status: "In Poker", color: "bg-emerald-500" },
                  { name: "Jacob.Null", status: "In Solitaire", color: "bg-cyan-500" },
                  { name: "Cyber.Vibe", status: "Idle", color: "bg-white/20" },
                ].map((friend, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/5 transition-all cursor-pointer group">
                    <div className="relative">
                      <div className="w-10 h-10 bg-white/10 rounded-xl border border-white/10 flex items-center justify-center">
                        <User size={20} className="text-white/40" />
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-[#010103] ${friend.color}`} />
                    </div>
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-tighter group-hover:text-cyan-400 transition-colors">{friend.name}</h4>
                      <p className="text-[10px] text-white/30 uppercase tracking-widest">{friend.status}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
