import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { getGameContent, generateRiddleImage } from '../services/aiService';
import { Brain, Sparkles, HelpCircle, Send, CheckCircle, XCircle, Globe, Languages, Image as ImageIcon, RefreshCw } from 'lucide-react';

const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' },
  { code: 'hi', name: 'हिन्दी' },
  { code: 'te', name: 'తెలుగు' },
  { code: 'ja', name: '日本語' },
  { code: 'zh', name: '中文' }
];

export default function RiddleSphinx({ difficulty = "MEDIUM" }: { difficulty?: string }) {
  const [riddle, setRiddle] = useState("");
  const [answer, setAnswer] = useState("");
  const [userAnswer, setUserAnswer] = useState("");
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState<"PLAYING" | "WON" | "LOST">("PLAYING");
  const [attempts, setAttempts] = useState(3);
  const [language, setLanguage] = useState('en');
  const [location, setLocation] = useState<{ city?: string, country?: string } | null>(null);
  const [mode, setMode] = useState<'TEXT' | 'IMAGE'>('TEXT');
  const [riddleImage, setRiddleImage] = useState<string | null>(null);

  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${position.coords.latitude}&lon=${position.coords.longitude}`);
          const data = await res.json();
          setLocation({
            city: data.address.city || data.address.town || data.address.village,
            country: data.address.country
          });
        } catch (e) {
          console.error("Location fetch error:", e);
        }
      });
    }
  }, []);

  const initGame = async () => {
    setLoading(true);
    setRiddleImage(null);
    
    const langName = LANGUAGES.find(l => l.code === language)?.name || 'English';
    const content = await getGameContent("Riddle", { 
      theme: "Futuristic", 
      difficulty: difficulty,
      language: langName,
      location: location ? `${location.city}, ${location.country}` : "Unknown",
      mode: mode
    });

    if (content) {
      setRiddle(content.riddle || "No riddle available.");
      setAnswer((content.answer || "").toUpperCase());
      
      if (mode === 'IMAGE') {
        const img = await generateRiddleImage(content.answer || content.riddle);
        setRiddleImage(img);
      }
      
      setAttempts(3);
      setStatus("PLAYING");
    }
    setLoading(false);
  };

  useEffect(() => {
    initGame();
  }, [language, mode]);

  const handleSubmit = () => {
    if (!userAnswer || status !== "PLAYING") return;
    
    if (userAnswer.toUpperCase() === (answer || "").toUpperCase()) {
      setStatus("WON");
    } else {
      setAttempts(a => a - 1);
      if (attempts <= 1) setStatus("LOST");
    }
    setUserAnswer("");
  };

  return (
    <div className="max-w-2xl mx-auto p-8 bg-black/60 backdrop-blur-xl rounded-[2rem] border border-indigo-500/30 shadow-[0_0_50px_rgba(99,102,241,0.1)] relative overflow-hidden">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
        <div className="flex items-center gap-3">
          <HelpCircle className="w-6 h-6 text-indigo-400" />
          <div>
            <h2 className="text-2xl font-black text-white tracking-tighter uppercase italic">Riddle of the Sphinx</h2>
            {location && (
              <div className="flex items-center gap-1 text-[10px] text-indigo-400/60 font-mono uppercase">
                <Globe className="w-3 h-3" />
                <span>{location.city}, {location.country}</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-2">
            <Languages className="w-4 h-4 text-indigo-400" />
            <select 
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="bg-transparent text-[10px] font-bold text-white uppercase outline-none cursor-pointer"
            >
              {LANGUAGES.map(l => (
                <option key={l.code} value={l.code} className="bg-slate-900">{l.name}</option>
              ))}
            </select>
          </div>

          <button 
            onClick={() => setMode(mode === 'TEXT' ? 'IMAGE' : 'TEXT')}
            className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition-all ${
              mode === 'IMAGE' ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-400' : 'bg-white/5 border-white/10 text-white/40'
            }`}
          >
            <ImageIcon className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase">{mode === 'IMAGE' ? 'Visual' : 'Text'}</span>
          </button>

          <div className="flex gap-2 ml-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className={`w-8 h-2 rounded-full ${i < attempts ? 'bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]' : 'bg-white/10'}`} />
            ))}
          </div>
        </div>
      </div>

      <div className="bg-indigo-500/5 border border-indigo-500/20 p-8 rounded-2xl mb-8 min-h-[240px] flex flex-col items-center justify-center text-center relative overflow-hidden">
        {loading ? (
          <div className="flex flex-col items-center gap-4">
            <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin" />
            <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-400/50">Consulting the Oracle...</span>
          </div>
        ) : (
          <div className="space-y-6 w-full">
            {mode === 'IMAGE' && riddleImage ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-sm mx-auto aspect-square rounded-2xl overflow-hidden border-2 border-indigo-500/30 shadow-2xl"
              >
                <img src={riddleImage} alt="Visual Riddle" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </motion.div>
            ) : null}
            
            <p className="text-xl lg:text-2xl font-serif italic text-white/90 leading-relaxed max-w-2xl mx-auto">
              "{riddle}"
            </p>
          </div>
        )}
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          value={userAnswer}
          onChange={(e) => setUserAnswer(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
          placeholder="SOLVE THE RIDDLE"
          className="flex-1 bg-white/5 border border-white/10 rounded-xl px-6 py-4 font-mono text-lg focus:outline-none focus:border-indigo-500/50 transition-all uppercase"
        />
        <button
          onClick={handleSubmit}
          className="px-10 py-4 bg-indigo-500 text-white font-black rounded-xl hover:bg-indigo-400 transition-all uppercase tracking-widest flex items-center gap-2"
        >
          <Send className="w-5 h-5" />
          SOLVE
        </button>
      </div>

      {status !== "PLAYING" && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 flex items-center justify-center bg-black/90 backdrop-blur-md rounded-[2rem] z-50 p-8"
        >
          <div className="text-center">
            {status === "WON" ? <CheckCircle className="w-16 h-16 text-emerald-400 mx-auto mb-4" /> : <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />}
            <h3 className="text-4xl font-black text-white mb-2 uppercase italic tracking-tighter">
              {status === "WON" ? "ENLIGHTENED" : "UNWORTHY"}
            </h3>
            <p className="text-white/40 mb-8 uppercase tracking-[0.3em] text-xs">
              THE ANSWER WAS: {answer}
            </p>
            <button onClick={initGame} className="px-12 py-4 bg-indigo-500 text-white font-black rounded-full hover:bg-indigo-400 transition-all uppercase tracking-widest text-sm">
              NEW CHALLENGE
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
