import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { getAIMove } from '../services/aiService';
import { Diamond, Heart, Club, Spade, Brain, Coins, User, Zap, Shield, Trophy, AlertCircle, Sparkles } from 'lucide-react';

export default function QuantumPoker({ difficulty = "MEDIUM" }: { difficulty?: string }) {
  const [userHand, setUserHand] = useState<number[]>([]);
  const [aiHand, setAiHand] = useState<number[]>([]);
  const [pot, setPot] = useState(0);
  const [userChips, setUserChips] = useState(1000);
  const [aiChips, setAiChips] = useState(1000);
  const [status, setStatus] = useState<"IDLE" | "PLAYING" | "REVEAL">("IDLE");
  const [aiComment, setAiComment] = useState("I see your hand...");

  const deal = () => {
    setUserHand([Math.floor(Math.random() * 13) + 1, Math.floor(Math.random() * 13) + 1]);
    setAiHand([Math.floor(Math.random() * 13) + 1, Math.floor(Math.random() * 13) + 1]);
    setPot(100);
    setUserChips(c => c - 50);
    setAiChips(c => c - 50);
    setStatus("PLAYING");
  };

  const handleAction = async (action: string) => {
    if (status !== "PLAYING") return;

    const aiRes = await getAIMove({
      gameType: "Classic Poker",
      board: { userHand, pot, userChips, aiChips },
      history: [action],
      difficulty: difficulty
    });

    if (aiRes) {
      setAiComment(aiRes.commentary || "I'll take that bet.");
      if (aiRes.move === "FOLD") {
        setUserChips(c => c + pot);
        setPot(0);
        setStatus("IDLE");
      } else {
        setStatus("REVEAL");
      }
    }
  };

  return (
    <div className="flex flex-col h-full gap-12 p-8 items-center justify-center relative overflow-hidden bg-[#050505]">
      {/* High-Tech Table Environment */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" 
        style={{ 
          backgroundImage: 'radial-gradient(circle at 50% 50%, #ef4444 0%, transparent 70%)',
          backgroundSize: '100% 100%'
        }} 
      />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] border-[40px] border-white/5 rounded-full blur-3xl pointer-events-none" />
      
      {/* Decorative Table Lines */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] border-2 border-red-500/10 rounded-[250px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] border border-red-500/5 rounded-[175px] pointer-events-none" />

      {/* AI Opponent Area */}
      <div className="flex flex-col items-center gap-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 bg-black/60 backdrop-blur-xl px-8 py-3 rounded-2xl border border-white/10 shadow-2xl"
        >
          <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center border border-red-500/30">
            <Brain className="text-red-400" size={20} />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 block">AI Opponent</span>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-white uppercase italic tracking-tighter">Nexus AI</span>
              <span className="px-2 py-0.5 bg-red-500 text-white text-[10px] font-black rounded-md ml-2">${aiChips}</span>
            </div>
          </div>
        </motion.div>
        
        <div className="flex gap-6">
          {aiHand.length > 0 ? aiHand.map((val, i) => (
            <motion.div 
              key={i} 
              initial={{ rotateY: 0, y: -20, opacity: 0 }}
              animate={{ 
                rotateY: status === "REVEAL" ? 180 : 0,
                y: 0,
                opacity: 1
              }}
              transition={{ delay: i * 0.2, type: "spring", stiffness: 100 }}
              className="w-24 h-36 lg:w-32 lg:h-48 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center relative preserve-3d transition-all duration-700 shadow-2xl"
            >
              {status === "REVEAL" ? (
                <div className="flex flex-col items-center [transform:rotateY(180deg)]">
                  <span className="text-4xl lg:text-6xl font-black text-red-400 mb-2">{val}</span>
                  <Spade className="w-6 h-6 lg:w-8 lg:h-8 text-red-400/30" />
                </div>
              ) : (
                <div className="flex flex-col items-center gap-4">
                  <Brain className="w-12 h-12 text-white/5 animate-pulse" />
                  <div className="w-8 h-1 bg-white/10 rounded-full" />
                </div>
              )}
            </motion.div>
          )) : (
            <div className="flex gap-6">
              {[1, 2].map(i => (
                <div key={i} className="w-24 h-36 lg:w-32 lg:h-48 bg-white/5 border border-white/5 rounded-2xl border-dashed flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full border-2 border-white/5" />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Center Pot & Commentary */}
      <div className="flex flex-col items-center gap-8 text-center relative z-10 max-w-2xl">
        <div className="flex flex-col items-center gap-3">
          <motion.div 
            animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
            transition={{ repeat: Infinity, duration: 4 }}
            className="w-20 h-20 rounded-full bg-amber-400/10 flex items-center justify-center border-2 border-amber-400/30 shadow-[0_0_40px_rgba(245,158,11,0.2)]"
          >
            <Coins className="w-10 h-10 text-amber-400" />
          </motion.div>
          <div className="text-center">
            <span className="text-6xl lg:text-8xl font-black text-white tracking-tighter tabular-nums leading-none">${pot}</span>
            <p className="text-[10px] uppercase font-black tracking-[0.6em] text-white/20 italic mt-2">Current_Pot</p>
          </div>
        </div>

        <div className="bg-red-500/5 border border-red-500/20 p-6 rounded-2xl backdrop-blur-xl w-full">
          <div className="flex items-center gap-2 mb-2 justify-center">
            <Brain className="w-4 h-4 text-red-400" />
            <span className="text-[8px] font-black text-red-400/50 uppercase tracking-[0.4em]">AI_Commentary</span>
          </div>
          <p className="text-xl lg:text-2xl font-serif italic text-red-400/90 leading-relaxed">"{aiComment}"</p>
        </div>
      </div>

      {/* Player Area */}
      <div className="flex flex-col items-center gap-8 relative z-10">
        <div className="flex gap-6">
          {userHand.length > 0 ? userHand.map((val, i) => (
            <motion.div 
              key={i} 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: i * 0.2 }}
              whileHover={{ scale: 1.05, y: -20, rotate: i === 0 ? -5 : 5 }}
              className="w-24 h-36 lg:w-32 lg:h-48 bg-white/10 border-2 border-red-500/50 rounded-2xl flex items-center justify-center shadow-[0_0_50px_rgba(239,68,68,0.25)] cursor-pointer relative group"
            >
              <div className="absolute top-2 left-2 text-white/20 font-black text-lg">{val}</div>
              <div className="flex flex-col items-center">
                <span className="text-4xl lg:text-6xl font-black text-white mb-2">{val}</span>
                <Heart className="w-6 h-6 text-red-500/50" />
              </div>
              <div className="absolute bottom-2 right-2 text-white/20 font-black text-lg rotate-180">{val}</div>
            </motion.div>
          )) : (
            <div className="flex gap-6">
              {[1, 2].map(i => (
                <div key={i} className="w-24 h-36 lg:w-32 lg:h-48 bg-white/5 border border-white/5 rounded-2xl border-dashed flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full border-2 border-white/5" />
                </div>
              ))}
            </div>
          )}
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 bg-black/60 backdrop-blur-xl px-8 py-3 rounded-2xl border border-white/10 shadow-2xl"
        >
          <div className="w-10 h-10 bg-emerald-500/20 rounded-xl flex items-center justify-center border border-emerald-500/30">
            <User className="text-emerald-400" size={20} />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30 block">Player Node</span>
            <div className="flex items-center gap-2">
              <span className="text-xl font-black text-white uppercase italic tracking-tighter">You</span>
              <span className="px-2 py-0.5 bg-emerald-500 text-black text-[10px] font-black rounded-md ml-2">${userChips}</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Controls */}
      <div className="flex gap-6 w-full max-w-xl relative z-10">
        {status === "IDLE" ? (
          <button 
            onClick={deal} 
            className="w-full py-7 bg-red-500 text-white font-black rounded-[2rem] hover:bg-white hover:text-red-500 transition-all uppercase tracking-[0.2em] text-sm shadow-[0_0_50px_rgba(239,68,68,0.4)] active:scale-95"
          >
            DEAL_CARDS
          </button>
        ) : (
          <>
            <button 
              onClick={() => handleAction("CALL")} 
              className="flex-1 py-7 bg-white/5 text-white font-black rounded-[2rem] hover:bg-white/10 transition-all uppercase tracking-[0.2em] border border-white/10 text-sm active:scale-95"
            >
              CALL
            </button>
            <button 
              onClick={() => handleAction("FOLD")} 
              className="flex-1 py-7 bg-red-500 text-white font-black rounded-[2rem] hover:bg-white hover:text-red-500 transition-all uppercase tracking-[0.2em] text-sm shadow-[0_0_50px_rgba(239,68,68,0.4)] active:scale-95"
            >
              FOLD
            </button>
          </>
        )}
      </div>
    </div>
  );
}
