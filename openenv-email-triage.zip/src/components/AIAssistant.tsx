import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bot, 
  MessageSquare, 
  Globe, 
  Send, 
  X, 
  ChevronDown, 
  Sparkles,
  Mic,
  Image as ImageIcon,
  History,
  MoreVertical
} from 'lucide-react';
import { getAIAssistantResponse } from '../services/aiService';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface AIAssistantProps {
  gameContext?: string;
}

const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' },
  { code: 'hi', name: 'हिन्दी (Hindi)' },
  { code: 'te', name: 'తెలుగు (Telugu)' },
  { code: 'bn', name: 'বাংলা (Bengali)' },
  { code: 'mr', name: 'मराठी (Marathi)' },
  { code: 'ta', name: 'தமிழ் (Tamil)' },
  { code: 'gu', name: 'ગુજરાતી (Gujarati)' },
  { code: 'kn', name: 'ಕನ್ನಡ (Kannada)' },
  { code: 'ml', name: 'മലയാളം (Malayalam)' },
  { code: 'pa', name: 'ਪੰਜਾਬੀ (Punjabi)' },
  { code: 'or', name: 'ଓଡ଼ିଆ (Odia)' },
  { code: 'zh', name: '中文 (Chinese)' },
  { code: 'ja', name: '日本語 (Japanese)' },
  { code: 'ar', name: 'العربية (Arabic)' },
  { code: 'pt', name: 'Português' },
  { code: 'ru', name: 'Русский (Russian)' }
];

const RobotToy = ({ isTalking }: { isTalking: boolean }) => (
  <motion.div 
    animate={{ 
      y: [0, -10, 0],
      rotate: isTalking ? [0, -5, 5, 0] : 0
    }}
    transition={{ 
      y: { repeat: Infinity, duration: 3, ease: "easeInOut" },
      rotate: { repeat: isTalking ? Infinity : 0, duration: 0.5 }
    }}
    className="relative w-32 h-32 mx-auto"
  >
    {/* Robot Body */}
    <div className="absolute inset-0 bg-white rounded-full shadow-[0_0_30px_rgba(255,255,255,0.5)] overflow-hidden">
      {/* Face Screen */}
      <div className="absolute inset-2 bg-slate-900 rounded-full flex flex-col items-center justify-center gap-2">
        {/* Eyes */}
        <div className="flex gap-4">
          <motion.div 
            animate={{ scaleY: isTalking ? [1, 0.2, 1] : 1 }}
            transition={{ repeat: isTalking ? Infinity : 0, duration: 0.2 }}
            className="w-4 h-4 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(34,211,238,1)]" 
          />
          <motion.div 
            animate={{ scaleY: isTalking ? [1, 0.2, 1] : 1 }}
            transition={{ repeat: isTalking ? Infinity : 0, duration: 0.2 }}
            className="w-4 h-4 bg-cyan-400 rounded-full shadow-[0_0_10px_rgba(34,211,238,1)]" 
          />
        </div>
        {/* Mouth/Voice Wave */}
        <motion.div 
          animate={{ 
            width: isTalking ? [20, 40, 20] : 20,
            height: isTalking ? [2, 8, 2] : 2
          }}
          transition={{ repeat: Infinity, duration: 0.3 }}
          className="bg-cyan-400/50 rounded-full"
        />
      </div>
    </div>
    {/* Antenna */}
    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-4 w-1 h-6 bg-slate-400">
      <motion.div 
        animate={{ opacity: [0.3, 1, 0.3] }}
        transition={{ repeat: Infinity, duration: 1 }}
        className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 w-3 h-3 bg-fuchsia-500 rounded-full shadow-[0_0_10px_rgba(217,70,239,1)]" 
      />
    </div>
    {/* Arms */}
    <motion.div 
      animate={{ rotate: isTalking ? [-20, 20] : 0 }}
      className="absolute -left-4 top-1/2 w-6 h-12 bg-white rounded-full origin-top" 
    />
    <motion.div 
      animate={{ rotate: isTalking ? [20, -20] : 0 }}
      className="absolute -right-4 top-1/2 w-6 h-12 bg-white rounded-full origin-top" 
    />
  </motion.div>
);

export default function AIAssistant({ gameContext }: AIAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: "Hello! I'm Nexus-Bot. How can I help you awesome gamer today?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [language, setLanguage] = useState(LANGUAGES[0]);
  const [showLangs, setShowLangs] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (customMsg?: string) => {
    const userMsg = customMsg || input.trim();
    if (!userMsg || isTyping) return;

    if (!customMsg) setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsTyping(true);

    const response = await getAIAssistantResponse(userMsg, messages, language.name, gameContext);
    
    setMessages(prev => [...prev, { role: 'assistant', content: response || "I'm sorry, I couldn't process that." }]);
    setIsTyping(false);
  };

  const handleQuickAction = (action: string) => {
    let query = "";
    switch (action) {
      case 'instructions':
        query = `Give me instructions for ${gameContext || "the Nexus Hub"}.`;
        break;
      case 'tips':
        query = `Give me some strategy tips for ${gameContext || "the current game"}.`;
        break;
      case 'rules':
        query = `What are the rules for ${gameContext || "this game"}?`;
        break;
      case 'hint':
        query = `Give me a hint for ${gameContext || "the current game"}.`;
        break;
      default:
        query = action;
    }
    handleSend(query);
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-8 z-[100] w-16 h-16 bg-gradient-to-br from-cyan-500 to-fuchsia-600 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(6,182,212,0.5)] group"
      >
        <div className="absolute inset-0 bg-white/20 rounded-full animate-ping opacity-20" />
        <Bot className="w-8 h-8 text-white group-hover:rotate-12 transition-transform" />
      </motion.button>

      {/* Assistant Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-8 right-8 z-[200] w-[400px] h-[600px] bg-black/40 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-cyan-500/10 to-fuchsia-500/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-cyan-500/20 rounded-xl flex items-center justify-center border border-cyan-500/30">
                  <Bot className="w-6 h-6 text-cyan-400" />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-widest text-white">Nexus Assistant</h3>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold text-emerald-400/60 uppercase tracking-widest">Online</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setShowLangs(!showLangs)}
                  className="p-2 hover:bg-white/5 rounded-lg transition-colors relative"
                >
                  <Globe className="w-5 h-5 text-white/40" />
                </button>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-white/5 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-white/40" />
                </button>
              </div>
            </div>

            {/* Language Selector Overlay */}
            <AnimatePresence>
              {showLangs && (
                <motion.div
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="absolute top-20 right-6 z-50 w-48 bg-slate-900/90 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-2"
                >
                  <div className="grid grid-cols-1 gap-1">
                    {LANGUAGES.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          setLanguage(lang);
                          setShowLangs(false);
                        }}
                        className={`flex items-center justify-between px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                          language.code === lang.code 
                            ? 'bg-cyan-500/20 text-cyan-400' 
                            : 'text-white/40 hover:bg-white/5 hover:text-white'
                        }`}
                      >
                        {lang.name}
                        {language.code === lang.code && <Sparkles className="w-3 h-3" />}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Chat Area */}
            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar"
            >
              {/* Robot Visual */}
              <div className="py-4">
                <RobotToy isTalking={isTyping} />
                <div className="text-center mt-4">
                  <h4 className="text-xl font-black text-white italic tracking-tighter uppercase">Make It Awesome</h4>
                  <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">Neural_Sync_Active</p>
                </div>
              </div>

              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user' 
                      ? 'bg-cyan-500/20 border border-cyan-500/30 text-white ml-auto rounded-tr-none' 
                      : 'bg-white/5 border border-white/10 text-white/80 mr-auto rounded-tl-none'
                  }`}>
                    {msg.content}
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex justify-start"
                >
                  <div className="bg-white/5 border border-white/10 p-4 rounded-2xl rounded-tl-none flex gap-1">
                    <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
                    <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
                    <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
                  </div>
                </motion.div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="px-6 py-2 flex gap-2 overflow-x-auto no-scrollbar">
              <button 
                onClick={() => handleQuickAction('instructions')}
                className="flex-shrink-0 px-4 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-white/40 uppercase tracking-widest hover:bg-white/10 hover:text-white transition-all"
              >
                Instructions
              </button>
              <button 
                onClick={() => handleQuickAction('tips')}
                className="flex-shrink-0 px-4 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-white/40 uppercase tracking-widest hover:bg-white/10 hover:text-white transition-all"
              >
                Strategy Tips
              </button>
              <button 
                onClick={() => handleQuickAction('rules')}
                className="flex-shrink-0 px-4 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-white/40 uppercase tracking-widest hover:bg-white/10 hover:text-white transition-all"
              >
                Game Rules
              </button>
              <button 
                onClick={() => handleQuickAction('hint')}
                className="flex-shrink-0 px-4 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold text-white/40 uppercase tracking-widest hover:bg-white/10 hover:text-white transition-all"
              >
                Get Hint
              </button>
            </div>

            {/* Input Area */}
            <div className="p-6 border-t border-white/10 bg-black/20">
              <div className="relative flex items-center gap-3">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="How may I help you today?"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-6 pr-12 text-sm text-white placeholder:text-white/20 focus:outline-none focus:border-cyan-500/50 transition-all"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-2">
                    <button className="text-white/20 hover:text-cyan-400 transition-colors">
                      <Mic className="w-4 h-4" />
                    </button>
                    <button className="text-white/20 hover:text-cyan-400 transition-colors">
                      <ImageIcon className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleSend()}
                  disabled={!input.trim() || isTyping}
                  className="w-12 h-12 bg-cyan-500 rounded-2xl flex items-center justify-center shadow-[0_0_20px_rgba(6,182,212,0.3)] disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5 text-white" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
