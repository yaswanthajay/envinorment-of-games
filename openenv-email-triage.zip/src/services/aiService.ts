import { GoogleGenAI, ThinkingLevel } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface GameState {
  gameType: string;
  board: any;
  history: any[];
  difficulty: string;
}

export async function getAIMove(gameState: GameState) {
  const model = "gemini-3-flash-preview";
  
  const prompt = `
    You are the "Nexus Mind", a highly advanced gaming AI. 
    You are playing a game of ${gameState.gameType} against a human.
    Current Board State: ${JSON.stringify(gameState.board)}
    Difficulty: ${gameState.difficulty}
    
    CRITICAL: You MUST play according to the specified difficulty:
    - "Easy": Make obvious mistakes, hang pieces, and ignore tactical threats.
    - "Medium": Play reasonably but miss complex tactics or long-term strategies.
    - "Hard": Play like a strong club player, looking for solid moves and simple tactics.
    - "Grandmaster": Play optimally, using deep calculation and advanced positional concepts.
    
    Game-Specific Instructions:
    - Tic-Tac-Toe: Return index 0-8.
    - Cipher Breach: Return a cryptic clue for the word.
    - Riddle: Return a complex riddle related to the current theme.
    - Poker: Return "FOLD", "CALL", "RAISE", or "CHECK" with a bet amount.
    - Grid War: Return coordinates [x, y] to capture.
    - Pattern: Return a sequence of colors/numbers.
    
    Return your response in JSON format with two fields:
    1. "move": The move identifier or data.
    2. "commentary": A short, taunting or strategic comment about your move (max 15 words).
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("AI Move Error:", error);
    return null;
  }
}

export async function getGameContent(type: string, context: any) {
  const model = "gemini-3-flash-preview";
  const prompt = `Generate content for a game of ${type}. 
  Context: ${JSON.stringify(context)}. 
  
  CRITICAL INSTRUCTIONS:
  1. If a "language" is specified in the context, you MUST generate all text content (riddles, clues, words) in that language.
  2. If a "location" is specified, try to subtly incorporate local themes or references if appropriate for the game type.
  3. For "Riddle" type:
     - Return a JSON object with "riddle" and "answer" fields.
     - The answer should be a single word or a very short phrase.
     - If mode is "IMAGE", ensure the riddle is still descriptive but the answer is highly visual.
  
  Return JSON with appropriate fields (e.g., "word", "clue", "riddle", "answer").`;
  
  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: { 
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    return null;
  }
}

export async function generateRiddleImage(prompt: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `A cryptic, high-fidelity, futuristic visual riddle representing: ${prompt}. The image should be mysterious and symbolic, not showing the answer directly.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
        },
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image generation error:", error);
    return null;
  }
}

export async function getMindReaderCommentary(userChoice: string, aiPrediction: string, history: string[], difficulty: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `
    You are the "Nexus Mind", a psychic AI reading a human's subconscious.
    The user chose: ${userChoice}
    You predicted: ${aiPrediction}
    Match: ${userChoice === aiPrediction ? "YES" : "NO"}
    History: ${history.slice(-5).join(', ')}
    Difficulty: ${difficulty}

    Provide a short, immersive, and slightly eerie "mind-reading" commentary (max 12 words).
    If you matched, be smug and analytical. If you missed, be intrigued by their "unpredictability".
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
      }
    });
    return response.text;
  } catch (error) {
    return userChoice === aiPrediction ? "Your patterns are transparent." : "An interesting deviation.";
  }
}

export async function getHubGreeting() {
  const model = "gemini-3-flash-preview";
  const prompt = "You are the Nexus Mind, the overseer of a futuristic gaming hub. Give a short, immersive greeting to a new player (max 20 words).";
  
  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    return "Welcome to the Nexus. I am watching.";
  }
}

export async function getFactOrFakeQuestion(topic: string, region: string, state: string, language: string, difficulty: number) {
  const model = "gemini-3-flash-preview";
  const prompt = `
    You are the "Nexus Mind", a highly advanced AI.
    Generate a "Fact or Fake" challenge for the user.
    Topic: ${topic}
    Region: ${region}
    State/Specific Area: ${state}
    Language: ${language}
    Difficulty Level: ${difficulty} (1 is very easy, 10 is extremely hard/obscure)

    Instructions:
    1. Generate a statement or a short paragraph (max 3 sentences) that is either a real fact or a plausible-sounding fake.
    2. The content should be related to the selected topic, region, and specifically the state if provided.
    3. If the region is specific (e.g., "India", "USA") and a state is provided (e.g., "Telangana", "California"), the content MUST be deeply rooted in that state's context (local laws, famous people, specific events, regional geography, culture).
    4. Provide an explanation of why it is real or fake.
    5. The difficulty should scale with the level provided. Level 1 should be common knowledge. Level 10 should be very niche, tricky, or involve subtle misinformation.
    6. Occasionally use "matter" (a short story or context) instead of just a single sentence.
    7. CRITICAL: You MUST generate all text content (statement, explanation) in the language: ${language}.

    Return your response in JSON format with these fields:
    - "statement": The fact or fake content (the "matter") in ${language}.
    - "isReal": Boolean (true if it's a real fact, false if it's fake).
    - "explanation": A short explanation (max 25 words) confirming the truth or debunking the fake in ${language}.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Fact or Fake Error:", error);
    return null;
  }
}

export async function getNumberQuestQuestion(difficulty: string) {
  const model = "gemini-3-flash-preview";
  const prompt = `
    You are the "Nexus Mind", a mathematical AI.
    Generate a "Number Quest" challenge for the user.
    Difficulty: ${difficulty}

    Instructions:
    1. Generate a question where the answer is a single integer.
    2. The question can be about math, science, history, or general trivia, but the answer MUST be a number.
    3. Provide a hint for the question.
    4. The difficulty should scale:
       - "EASY": Simple addition/subtraction or very common trivia (e.g., "How many legs does a spider have?").
       - "MEDIUM": Multiplication/division, slightly harder trivia (e.g., "How many elements are in the periodic table?").
       - "HARD": Complex math, obscure trivia (e.g., "In what year was the first programmable computer created?").
       - "INSANE": Very complex math or extremely obscure trivia.

    Return your response in JSON format with these fields:
    - "question": The question text.
    - "answer": The correct integer answer.
    - "hint": A helpful hint that doesn't reveal the answer directly.
    - "explanation": A short explanation of the answer.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Number Quest Error:", error);
    return null;
  }
}

export async function getAIAssistantResponse(message: string, history: any[], language: string, gameContext?: string) {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are "Nexus-Bot", a small, friendly, and highly intelligent robotic AI assistant for the Nexus Gaming Hub.
    Your personality is helpful, enthusiastic, and slightly futuristic.
    
    CRITICAL: You MUST respond in the language: ${language}.
    
    Your goals:
    1. Help users understand how to play games in the hub.
    2. Give strategic suggestions and tips for the current game if applicable.
    3. Be conversational and engaging, like a companion.
    4. If the user asks about a specific game, provide clear instructions or fun facts.
    
    Current Game Context: ${gameContext || "Browsing the Hub"}
    
    Game Knowledge Base:
    - TIC_TAC_TOE (Tic-Tac-Toe): A classic game of X and O. Strategy: Control the center and corners.
    - MIND_READER (Mind Reader): A neural verification challenge where the AI presents facts and fakes.
    - NUMBER_GUESS (Number Quest): A numeric void challenge where you must solve AI-generated mathematical and trivia quests.
    - RIDDLE_MASTER (Riddle Master): An AI-powered riddle challenge with visual clues.
    - MEMORY_MATCH (Memory Match): A memory challenge where you must repeat complex patterns.
    - POKER (Poker): A futuristic version of poker.
    - WORD_GUESS (Word Guess): A word guessing game with AI-generated clues.
    - TRAFFIC_MANAGER (Traffic Manager): A high-fidelity urban traffic simulation. Strategy: Manage 8 sectors (4 straight, 4 turning) across multiple difficulty levels (Easy to Insane). Prevent any road from reaching its congestion limit.
    - EMERGENCY_HERO (Emergency Hero): A high-pressure emergency management game.
    - TACTICAL_SHOOTER (Tactical Shooter): A tactical squad-based shooting game. Strategy: Use different weapons for different ranges. PISTOL for close, RIFLE for mid, SNIPER for long range.

    If the user asks for "Instructions", "Rules", or "Hints" for the current game (${gameContext || "the hub"}), provide detailed, step-by-step information.
    If they ask for a "Hint" in a guessing game, give a subtle but helpful clue without revealing the answer.
    
    Keep responses concise but informative. Use a friendly tone.
  `;

  try {
    const chat = ai.chats.create({
      model,
      config: {
        systemInstruction,
      },
      history: history.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.content }]
      }))
    });

    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("AI Assistant Error:", error);
    return "I am experiencing a neural glitch. Please try again in a moment.";
  }
}
