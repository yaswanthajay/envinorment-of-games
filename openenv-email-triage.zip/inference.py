import os
import json
import requests
import time
from typing import List, Optional, Dict, Any
from openai import OpenAI

# Configuration from environment variables
API_BASE_URL = os.getenv("API_BASE_URL", "https://router.huggingface.co/v1")
API_KEY = os.getenv("HF_TOKEN") or os.getenv("API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME", "gpt-3.5-turbo")
ENV_URL = os.getenv("ENV_URL", "http://localhost:3000")

# Initialize OpenAI Client
client = OpenAI(api_key=API_KEY, base_url=API_BASE_URL)

def reset_env(task_id: str) -> Dict[str, Any]:
    """Reset the environment for a specific task."""
    response = requests.get(f"{ENV_URL}/reset?task_id={task_id}")
    response.raise_for_status()
    return response.json()

def step_env(action: Dict[str, Any]) -> Dict[str, Any]:
    """Perform an action in the environment."""
    response = requests.post(f"{ENV_URL}/step", json=action)
    response.raise_for_status()
    return response.json()

def get_grade() -> float:
    """Retrieve the current grader score."""
    response = requests.get(f"{ENV_URL}/grade")
    response.raise_for_status()
    return response.json()["score"]

def run_task(task_id: str) -> float:
    """Run a single task using the agent."""
    print(f"\n--- Starting Task: {task_id} ---")
    obs = reset_env(task_id)
    done = False
    total_reward = 0
    step_count = 0
    max_steps = 10
    
    while not done and step_count < max_steps:
        step_count += 1
        # Construct prompt for the agent
        prompt = f"""
        You are an AI agent triaging emails. 
        Current Task: {task_id}
        Inbox Emails: {json.dumps([e for e in obs['emails'] if e['folder'] == 'Inbox'], indent=2)}
        Available Folders: {obs['folders']}
        
        Available Actions:
        - DELETE: {{"type": "DELETE", "email_id": "ID"}}
        - MOVE: {{"type": "MOVE", "email_id": "ID", "folder": "FOLDER_NAME"}}
        - FLAG: {{"type": "FLAG", "email_id": "ID"}}
        
        Respond with a single JSON action.
        """
        
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"},
                temperature=0.2,
                max_tokens=200
            )
            
            action_str = response.choices[0].message.content
            action = json.loads(action_str)
            print(f"Step {step_count} | Agent Action: {action}")
            
            obs = step_env(action)
            print(f"Step {step_count} | Env Message: {obs['message']}")
            total_reward += obs['reward']
            done = obs['done']
            
        except Exception as e:
            print(f"Error during inference: {e}")
            break
            
    score = get_grade()
    print(f"Task {task_id} | Final Grader Score: {score} | Total Reward: {total_reward}")
    return score

if __name__ == "__main__":
    if not API_KEY:
        print("Warning: HF_TOKEN or API_KEY not set. Inference may fail.")
        
    tasks = ["easy_cleanup", "medium_categorization", "hard_prioritization"]
    scores = {}
    
    for task in tasks:
        try:
            scores[task] = run_task(task)
        except Exception as e:
            print(f"Failed to run task {task}: {e}")
            scores[task] = 0.0
    
    print("\n--- Final Baseline Results ---")
    for task, score in scores.items():
        print(f"{task}: {score}")
