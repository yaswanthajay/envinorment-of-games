from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from enum import Enum

class ActionType(str, Enum):
    DELETE = "DELETE"
    MOVE = "MOVE"
    FLAG = "FLAG"
    REPLY = "REPLY"
    READ = "READ"

class Action(BaseModel):
    type: ActionType
    email_id: str
    folder: Optional[str] = None
    reply_text: Optional[str] = None

class Email(BaseModel):
    id: str
    sender: str
    subject: str
    body: str
    category: str
    is_flagged: bool
    is_read: bool
    folder: str

class Observation(BaseModel):
    emails: List[Email]
    folders: List[str]
    message: str
    reward: float
    done: bool
    info: Dict[str, Any]

class State(BaseModel):
    emails: List[Email]
    folders: List[str]
    step_count: int
    task_id: str
    score: float
