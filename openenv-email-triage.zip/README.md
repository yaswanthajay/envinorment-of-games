# Email Triage Environment (OpenEnv)

A real-world simulation of an email triage task where an agent must categorize, delete spam, and prioritize urgent emails. This environment adheres to the OpenEnv specification.

## Environment Description

The agent is presented with an inbox of emails from various senders with different subjects and bodies. Each email belongs to a category: `SPAM`, `INVOICE`, `URGENT`, or `GENERAL`. The agent's goal is to perform specific triage tasks based on the current `task_id`.

### Action Space

The agent can perform the following actions:
- `DELETE`: Move an email to the 'Trash' folder.
- `MOVE`: Move an email to a specific folder (e.g., 'Finance').
- `FLAG`: Mark an email as flagged.
- `REPLY`: (Future) Draft a reply to an email.

**Action Format (JSON):**
```json
{
  "type": "DELETE" | "MOVE" | "FLAG",
  "email_id": "string",
  "folder": "string" (optional, for MOVE),
  "reply_text": "string" (optional, for REPLY)
}
```

### Observation Space

The agent receives the current state of the inbox and folders.

**Observation Format (JSON):**
```json
{
  "emails": [
    {
      "id": "string",
      "sender": "string",
      "subject": "string",
      "body": "string",
      "category": "string",
      "is_flagged": "boolean",
      "folder": "string"
    }
  ],
  "folders": ["string"],
  "message": "string",
  "reward": "number",
  "done": "boolean",
  "info": {
    "step_count": "number",
    "task_id": "string",
    "score": "number"
  }
}
```

## Tasks

The environment supports three tasks of increasing difficulty:

1.  **easy_cleanup**: Delete all emails marked as `[SPAM]`.
2.  **medium_categorization**: Move all `[INVOICE]` emails to the 'Finance' folder.
3.  **hard_prioritization**: Identify and flag all `[URGENT]` emails from 'CEO' or 'Client'.

## Reward Function

The reward function provides partial progress signals:
- `+0.5`: Correct action (e.g., deleting spam, moving invoice to finance).
- `-0.5`: Incorrect action (e.g., deleting non-spam).
- `-0.2`: Suboptimal action (e.g., moving to wrong folder).
- `-0.1`: Invalid or unknown action.

## Baseline Scores

| Task | Baseline Score (0.0 - 1.0) |
|------|----------------------------|
| easy_cleanup | 1.0 |
| medium_categorization | 0.8 |
| hard_prioritization | 0.6 |

## Setup Instructions

1.  **Install Dependencies:**
    ```bash
    npm install
    ```
2.  **Start the Environment:**
    ```bash
    npm run dev
    ```
3.  **Run Baseline Inference:**
    ```bash
    export OPENAI_API_KEY=your_key
    python inference.py
    ```

## Deployment

This project is ready for deployment to Hugging Face Spaces using the provided `Dockerfile`.
